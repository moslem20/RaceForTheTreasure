# Race for the Treasure - Human vs AI

## Overview

This is an interactive grid-based strategy game called "Race for the Treasure" where a human player competes against an intelligent AI agent to reach a treasure first. The game demonstrates advanced AI algorithms (UCS, A*) in a competitive gaming environment with strategic tools including walls, ladders, and various terrain types. Players must navigate a 10x10 grid while using limited strategic resources to gain advantages or block their opponent.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with custom configuration
- **Styling**: Tailwind CSS with custom component library
- **3D Graphics**: Three.js ecosystem (@react-three/fiber, @react-three/drei, @react-three/postprocessing)
- **State Management**: Zustand for global state (game state, audio)
- **UI Components**: Radix UI primitives with custom shadcn/ui components

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Development**: TypeScript with tsx for development server
- **Build Process**: ESBuild for server bundling, Vite for client bundling
- **Database**: PostgreSQL with Drizzle ORM
- **Session Management**: Basic session storage interface (currently in-memory)

### Project Structure
```
├── client/          # Frontend React application
│   ├── src/
│   │   ├── components/  # UI components (pathfinding, ui)
│   │   ├── hooks/       # Custom React hooks
│   │   ├── lib/         # Utilities, stores, algorithms
│   │   └── pages/       # Page components
│   └── public/      # Static assets (fonts, 3D models)
├── server/          # Backend Express application
├── shared/          # Shared types and schemas
└── migrations/      # Database migrations
```

## Key Components

### Game System
- **Advanced Turn-Based Strategy**: Human and AI take turns with energy-based movement system
- **Multiple Treasures**: Players must collect 2 out of 3 treasures to win, adding strategic depth
- **Energy/Stamina System**: Each player has 10 energy points, terrain costs vary, energy regenerates per turn
- **Enhanced Terrain**: Empty tiles, walls, water (2x cost), mud (2x cost), sand (3x cost), trap tiles (stun effect), power-up tiles
- **Keys and Gates**: Unlockable barriers requiring key collection for access to new areas
- **Moving Guards**: Autonomous guard units that patrol and block paths every few turns
- **Fog of War**: Limited 3x3 visibility around each player, encouraging exploration
- **Power-Up System**: Collect power-ups for extra movement, water immunity, bonus walls/ladders
- **Status Effects**: Trap tiles stun players for 2 turns, affecting strategy significantly
- **Random Events**: Every 5 turns, events like floods, lightning strikes, or bonus spawns occur
- **Difficulty Scaling**: Easy (BFS), Normal (A*), Hard (predictive AI with strategic placement)
- **Win Condition**: First player to collect 2 treasures wins, or draw if simultaneous

### Interactive Features
- **Real-time AI**: Watch AI decision-making with reasoning explanations across difficulty levels
- **Advanced Strategic Planning**: Choose between movement, wall/ladder placement, key collection, gate unlocking
- **Live Performance Analytics**: Track steps taken, tiles explored, energy usage, tool utilization, and turn statistics
- **Fog of War Visualization**: Limited visibility system encouraging exploration and strategic planning
- **Random Events System**: Dynamic events every 5 turns including floods, lightning strikes, earthquakes, and bonuses
- **Energy Management**: Visual energy bars and cost indicators for terrain traversal
- **Multiple Win Conditions**: Collect 2 out of 3 treasures with strategic route planning
- **Guard Avoidance**: Navigate around moving patrol units that block paths
- **Heatmap Analysis**: Post-game visualization of explored areas and movement patterns

### UI/UX Components
- **Canvas Rendering**: HTML5 Canvas for efficient grid visualization
- **Responsive Design**: Mobile-friendly interface with touch support
- **Accessibility**: Keyboard navigation and screen reader support
- **Audio System**: Sound effects with mute/unmute functionality

## Data Flow

1. **User Interaction**: User modifies grid through canvas click/drag events
2. **State Updates**: Grid state updates trigger re-renders of visualization
3. **Algorithm Execution**: Selected algorithms run with step-by-step callbacks
4. **Visualization**: Each algorithm step updates the visual representation
5. **Results Collection**: Performance metrics are gathered and displayed
6. **Comparison**: Multiple algorithm results are compared side-by-side

## External Dependencies

### Core Libraries
- **React Ecosystem**: React, React DOM, React Three Fiber
- **Database**: Drizzle ORM with PostgreSQL driver (@neondatabase/serverless)
- **UI Framework**: Radix UI primitives, Tailwind CSS
- **Development**: Vite, TypeScript, ESBuild

### Optional Integrations
- **3D Graphics**: Three.js for potential 3D visualizations
- **Audio**: Web Audio API for sound effects
- **Query Management**: TanStack Query for data fetching (prepared for future API integration)

## Deployment Strategy

### Development Environment
- **Dev Server**: Vite development server with hot module replacement
- **Backend**: tsx with automatic restart on file changes
- **Database**: Local PostgreSQL or Neon serverless database

### Production Deployment
- **Platform**: Replit with autoscale deployment target
- **Build Process**: 
  1. Vite builds client to `dist/public`
  2. ESBuild bundles server to `dist/index.js`
- **Runtime**: Node.js production server serving static files and API
- **Database**: Neon PostgreSQL serverless database

### Configuration
- **Port**: 5000 (mapped to external port 80)
- **Environment**: Configured via `DATABASE_URL` environment variable
- **Assets**: Support for large 3D models and audio files

## Changelog

- June 24, 2025: Initial pathfinding visualizer setup
- June 24, 2025: Complete transformation to strategy game - Added human vs AI gameplay, strategic tools (walls/ladders), terrain variety, turn-based mechanics, and intelligent AI agent with A* pathfinding
- June 27, 2025: Enhanced gameplay with LoveableApp integration - Added movement control buttons, power-up system, trap tiles, enhanced player status display, and improved game mechanics
- June 27, 2025: Advanced gameplay mechanics implementation - Added energy/stamina system, multiple treasures (collect 2/3 to win), keys and unlockable gates, moving guard units, random events every 5 turns, difficulty scaling (Easy/Normal/Hard AI), live statistics tracking, smooth transition effects for game state changes, and comprehensive visual enhancements
- June 27, 2025: Fog of War feature removed - All game areas now permanently visible for better strategic gameplay
- July 5, 2025: Laptop optimization for 1366×768 resolution - Complete layout refactor to 2-8-2 column grid, responsive CSS media queries for different laptop sizes, scrollable sidebar panels, fullscreen toggle feature, and optimized cell sizes (14x14 pixels) for perfect laptop screen fit without scrolling
- July 5, 2025: Personalized Game Difficulty AI Advisor implementation - Advanced performance tracking system with detailed metrics (win rate, tool usage, exploration patterns, decision speed, time-based performance), intelligent difficulty recommendations with confidence scoring, actionable strategy insights, and comprehensive performance analysis dashboard with expandable categories
- July 5, 2025: PC-style scrollable interface implementation - Transformed layout from fixed-height viewport to traditional scrollable web page design with sticky header, natural content flow, additional content sections (game instructions, statistics), and footer for enhanced PC-like user experience
- July 5, 2025: Advanced AI Agent System implementation - Comprehensive competitive AI with A* pathfinding, strategic decision-making, human behavior prediction, tool optimization, energy management, confidence scoring, and multiple AI personalities (aggressive, defensive, balanced) specifically for Hard difficulty mode
- July 5, 2025: Enhanced AI Agent System upgrade - Added multi-turn planning (3-5 moves ahead), bluffing strategies, tactical feints, adaptive learning with behavior pattern recognition, 5 AI personalities (balanced, aggressive, defensive, adaptive, tactical), strategic memory system, and enhanced decision trees with future game state simulation
- July 5, 2025: AI Difficulty Selector System implementation - Added three distinct AI difficulty modes (Easy/Normal/Hard) with different algorithms (BFS, A*, Strategic), real-time difficulty switching capabilities, enhanced AI behaviors for each mode, and integrated difficulty controls in game sidebar
- July 7, 2025: AI Personality System with Memory - Implemented four distinct AI opponents (The Rusher, The Blocker, The Collector, The Strategist) with unique behaviors, AI memory system that remembers failures and adapts strategies, human pattern recognition, and personality-specific decision making with memory retention capabilities
- July 7, 2025: Enhanced AI Algorithms for Maximum Challenge - Advanced A* pathfinding for all AI personalities, strategic blocking analysis with chokepoint detection, multi-turn lookahead planning (6 moves ahead for Strategist), route prediction and human behavior analysis, terrain-aware movement costs, and failure memory integration. AI now uses sophisticated algorithms to make it extremely challenging to beat.
- July 7, 2025: Strategic Wall Placement System - Implemented sophisticated wall placement logic with path prediction, chokepoint analysis, timing strategies (save walls for critical moments), bluffing capabilities, success probability prediction, wall placement analytics and learning system, urgent situation detection, and human counter-strategy tracking. AI can now strategically block, delay, and reroute human players with maximum effectiveness.
- July 7, 2025: Comprehensive AI Search Algorithms Implementation - Added complete suite of AI search algorithms including State Space Representation (game board state tracking), Blind Search algorithms (BFS for completeness, DFS for speed), Cost-Based Search (UCS for optimal paths, A* with multiple heuristics), Heuristic Functions (Manhattan, Euclidean, Strategic, Chebyshev distances), Performance Comparison system for algorithm analysis, and Strategic Decision-Making for wall/ladder placement optimization. Each AI personality now uses different search algorithms: Rusher (A* Manhattan), Blocker (UCS Strategic), Collector (BFS Euclidean), Strategist (Auto-select). Added real-time algorithm performance tracking, state space analysis panel, and algorithm selection interface for experimentation.

## User Preferences

Preferred communication style: Simple, everyday language.