export interface Position {
  row: number;
  col: number;
}

export interface GameState {
  players: {
    human: Position;
    ai: Position;
  };
  treasures: Position[]; // Multiple treasures for advanced gameplay
  walls: Position[];
  ladders: Position[];
  highCostTiles: Position[]; // Water/mud tiles that cost more to traverse
  trapTiles: Position[]; // Trap tiles that stun players
  powerUps: Position[]; // Power-up tiles that grant bonuses
  keys: Position[]; // Keys to unlock gates
  gates: Position[]; // Unlockable gates
  guards: Guard[]; // Moving guard units
  fogOfWar: boolean; // Fog of war enabled
  visibleTiles: {
    human: Position[];
    ai: Position[];
  };
  playerResources: {
    human: {
      walls: number;
      ladders: number;
      energy: number; // Energy/stamina system
      maxEnergy: number;
      keysCollected: number;
      treasuresCollected: number;
      powerUps: {
        extraMovement: number; // Extra movement turns
        ignoreWaterCost: number; // Ignore water cost uses
        extraWalls: number; // Extra walls to place
        extraLadders: number; // Extra ladders to place
      };
      stunned: number; // Number of turns player is stunned
    };
    ai: {
      walls: number;
      ladders: number;
      energy: number;
      maxEnergy: number;
      keysCollected: number;
      treasuresCollected: number;
      powerUps: {
        extraMovement: number;
        ignoreWaterCost: number;
        extraWalls: number;
        extraLadders: number;
      };
      stunned: number;
    };
  };
  gameStats: {
    stepsHuman: number;
    stepsAI: number;
    tilesExplored: number;
    toolsUsed: number;
    turnCount: number;
  };
  difficulty: 'easy' | 'normal' | 'hard';
  theme: 'default' | 'jungle' | 'ice' | 'cyber' | 'volcano';
  lastEvent?: RandomEvent;
}

export type GameStatus = 'playing' | 'human-won' | 'ai-won' | 'draw';

export type PlayerType = 'human' | 'ai';

export type ActionType = 'move' | 'place-wall' | 'place-ladder';

export interface Move {
  from: Position;
  to: Position;
  player: PlayerType;
  type: 'move' | 'place-wall' | 'place-ladder';
}

export type PowerUpType = 'extraMovement' | 'ignoreWaterCost' | 'extraWalls' | 'extraLadders';

export interface Guard {
  id: string;
  position: Position;
  direction: 'up' | 'down' | 'left' | 'right';
  speed: number; // moves every X turns
  lastMoveTime: number;
}

export interface RandomEvent {
  type: 'flood' | 'lightning' | 'earthquake' | 'bonus';
  description: string;
  affectedTiles?: Position[];
  turnTriggered: number;
}

export interface GameTheme {
  name: string;
  colors: {
    empty: string;
    wall: string;
    water: string;
    treasure: string;
    human: string;
    ai: string;
    trap: string;
    powerUp: string;
    key: string;
    gate: string;
    guard: string;
  };
  sounds?: {
    move: string;
    treasure: string;
    wall: string;
    trap: string;
  };
}

export interface VisibilityRange {
  range: number; // 3x3 around player
  exploredTiles: Position[]; // Previously seen tiles
}