import { GameState, Position, ActionType, PowerUpType } from '../types/game';

// ===== STATE SPACE REPRESENTATION =====
export interface GameStateNode {
  gameState: GameState;
  position: Position;
  cost: number;
  depth: number;
  parent: GameStateNode | null;
  action: ActionType | null;
  heuristicValue: number;
  pathCost: number;
  evaluation: number; // f(n) = g(n) + h(n)
}

export interface SearchResult {
  algorithm: string;
  path: Position[];
  totalCost: number;
  nodesExplored: number;
  executionTime: number;
  memoryUsed: number;
  optimal: boolean;
  reasoning: string;
  steps: SearchStep[];
}

export interface SearchStep {
  position: Position;
  action: string;
  cost: number;
  heuristic: number;
  evaluation: number;
  nodesInQueue: number;
  timestamp: number;
}

export interface PerformanceMetrics {
  timeComplexity: number;
  spaceComplexity: number;
  optimalityGuarantee: boolean;
  completenessGuarantee: boolean;
  branchingFactor: number;
}

// ===== HEURISTIC FUNCTIONS =====
export class HeuristicFunctions {
  // Manhattan Distance Heuristic
  static manhattanDistance(pos1: Position, pos2: Position): number {
    return Math.abs(pos1.row - pos2.row) + Math.abs(pos1.col - pos2.col);
  }

  // Euclidean Distance Heuristic
  static euclideanDistance(pos1: Position, pos2: Position): number {
    const dx = pos1.row - pos2.row;
    const dy = pos1.col - pos2.col;
    return Math.sqrt(dx * dx + dy * dy);
  }

  // Chebyshev Distance Heuristic
  static chebyshevDistance(pos1: Position, pos2: Position): number {
    return Math.max(Math.abs(pos1.row - pos2.row), Math.abs(pos1.col - pos2.col));
  }

  // Weighted Manhattan with Terrain Cost
  static weightedManhattan(pos1: Position, pos2: Position, gameState: GameState): number {
    const baseDist = this.manhattanDistance(pos1, pos2);
    const terrainWeight = this.getTerrainWeight(pos2, gameState);
    return baseDist * terrainWeight;
  }

  // Multi-Treasure Heuristic
  static multiTreasureHeuristic(currentPos: Position, gameState: GameState): number {
    const treasurePositions = gameState.treasures.filter(t => !t.collected);
    if (treasurePositions.length === 0) return 0;

    // Find minimum distance to any treasure
    let minDistance = Infinity;
    treasurePositions.forEach(treasure => {
      const distance = this.manhattanDistance(currentPos, treasure.position);
      minDistance = Math.min(minDistance, distance);
    });

    return minDistance;
  }

  // Strategic Heuristic (considers obstacles and opponent)
  static strategicHeuristic(currentPos: Position, gameState: GameState, opponentPos: Position): number {
    const treasureHeuristic = this.multiTreasureHeuristic(currentPos, gameState);
    const opponentDistance = this.manhattanDistance(currentPos, opponentPos);
    
    // Penalize being too close to opponent
    const opponentPenalty = opponentDistance < 3 ? 5 : 0;
    
    // Bonus for being on power-up tiles
    const powerUpBonus = gameState.powerUps.some(p => 
      p.position.row === currentPos.row && p.position.col === currentPos.col && !p.collected
    ) ? -2 : 0;

    return treasureHeuristic + opponentPenalty + powerUpBonus;
  }

  private static getTerrainWeight(pos: Position, gameState: GameState): number {
    const cell = gameState.grid[pos.row]?.[pos.col];
    if (!cell) return 1;

    switch (cell.type) {
      case 'water': return 2;
      case 'mud': return 2;
      case 'sand': return 3;
      case 'trap': return 5;
      default: return 1;
    }
  }
}

// ===== BLIND SEARCH ALGORITHMS =====
export class BlindSearchAlgorithms {
  // Breadth-First Search (BFS)
  static breadthFirstSearch(
    startPos: Position, 
    goalPos: Position, 
    gameState: GameState
  ): SearchResult {
    const startTime = performance.now();
    const queue: GameStateNode[] = [];
    const visited = new Set<string>();
    const steps: SearchStep[] = [];
    let nodesExplored = 0;

    const startNode: GameStateNode = {
      gameState,
      position: startPos,
      cost: 0,
      depth: 0,
      parent: null,
      action: null,
      heuristicValue: 0,
      pathCost: 0,
      evaluation: 0
    };

    queue.push(startNode);
    visited.add(`${startPos.row},${startPos.col}`);

    while (queue.length > 0) {
      const current = queue.shift()!;
      nodesExplored++;

      // Record search step
      steps.push({
        position: current.position,
        action: current.action || 'start',
        cost: current.cost,
        heuristic: 0,
        evaluation: current.cost,
        nodesInQueue: queue.length,
        timestamp: performance.now() - startTime
      });

      // Goal test
      if (current.position.row === goalPos.row && current.position.col === goalPos.col) {
        const path = this.reconstructPath(current);
        return {
          algorithm: 'BFS',
          path,
          totalCost: current.cost,
          nodesExplored,
          executionTime: performance.now() - startTime,
          memoryUsed: queue.length + visited.size,
          optimal: true,
          reasoning: 'BFS guarantees shortest path in unweighted graphs',
          steps
        };
      }

      // Expand neighbors
      const neighbors = this.getValidNeighbors(current.position, gameState);
      for (const neighbor of neighbors) {
        const key = `${neighbor.row},${neighbor.col}`;
        if (!visited.has(key)) {
          visited.add(key);
          const neighborNode: GameStateNode = {
            gameState,
            position: neighbor,
            cost: current.cost + 1,
            depth: current.depth + 1,
            parent: current,
            action: this.getActionType(current.position, neighbor),
            heuristicValue: 0,
            pathCost: current.cost + 1,
            evaluation: current.cost + 1
          };
          queue.push(neighborNode);
        }
      }
    }

    return {
      algorithm: 'BFS',
      path: [],
      totalCost: Infinity,
      nodesExplored,
      executionTime: performance.now() - startTime,
      memoryUsed: visited.size,
      optimal: false,
      reasoning: 'No path found',
      steps
    };
  }

  // Depth-First Search (DFS)
  static depthFirstSearch(
    startPos: Position, 
    goalPos: Position, 
    gameState: GameState,
    maxDepth: number = 50
  ): SearchResult {
    const startTime = performance.now();
    const stack: GameStateNode[] = [];
    const visited = new Set<string>();
    const steps: SearchStep[] = [];
    let nodesExplored = 0;

    const startNode: GameStateNode = {
      gameState,
      position: startPos,
      cost: 0,
      depth: 0,
      parent: null,
      action: null,
      heuristicValue: 0,
      pathCost: 0,
      evaluation: 0
    };

    stack.push(startNode);

    while (stack.length > 0) {
      const current = stack.pop()!;
      const key = `${current.position.row},${current.position.col}`;
      
      if (visited.has(key) || current.depth > maxDepth) continue;
      
      visited.add(key);
      nodesExplored++;

      steps.push({
        position: current.position,
        action: current.action || 'start',
        cost: current.cost,
        heuristic: 0,
        evaluation: current.cost,
        nodesInQueue: stack.length,
        timestamp: performance.now() - startTime
      });

      // Goal test
      if (current.position.row === goalPos.row && current.position.col === goalPos.col) {
        const path = this.reconstructPath(current);
        return {
          algorithm: 'DFS',
          path,
          totalCost: current.cost,
          nodesExplored,
          executionTime: performance.now() - startTime,
          memoryUsed: stack.length + visited.size,
          optimal: false,
          reasoning: 'DFS found a path but not guaranteed optimal',
          steps
        };
      }

      // Expand neighbors (reverse order for stack)
      const neighbors = this.getValidNeighbors(current.position, gameState).reverse();
      for (const neighbor of neighbors) {
        const neighborKey = `${neighbor.row},${neighbor.col}`;
        if (!visited.has(neighborKey)) {
          const neighborNode: GameStateNode = {
            gameState,
            position: neighbor,
            cost: current.cost + 1,
            depth: current.depth + 1,
            parent: current,
            action: this.getActionType(current.position, neighbor),
            heuristicValue: 0,
            pathCost: current.cost + 1,
            evaluation: current.cost + 1
          };
          stack.push(neighborNode);
        }
      }
    }

    return {
      algorithm: 'DFS',
      path: [],
      totalCost: Infinity,
      nodesExplored,
      executionTime: performance.now() - startTime,
      memoryUsed: visited.size,
      optimal: false,
      reasoning: 'No path found within depth limit',
      steps
    };
  }

  private static getValidNeighbors(pos: Position, gameState: GameState): Position[] {
    const neighbors: Position[] = [];
    const directions = [
      { row: -1, col: 0 }, // up
      { row: 1, col: 0 },  // down
      { row: 0, col: -1 }, // left
      { row: 0, col: 1 }   // right
    ];

    for (const dir of directions) {
      const newPos = {
        row: pos.row + dir.row,
        col: pos.col + dir.col
      };

      if (this.isValidPosition(newPos, gameState)) {
        neighbors.push(newPos);
      }
    }

    return neighbors;
  }

  private static isValidPosition(pos: Position, gameState: GameState): boolean {
    const { row, col } = pos;
    const gridSize = gameState.grid.length;
    
    // Check bounds
    if (row < 0 || row >= gridSize || col < 0 || col >= gridSize) {
      return false;
    }

    // Check for walls
    const cell = gameState.grid[row][col];
    return cell.type !== 'wall';
  }

  private static getActionType(from: Position, to: Position): ActionType {
    if (from.row > to.row) return 'move';
    if (from.row < to.row) return 'move';
    if (from.col > to.col) return 'move';
    if (from.col < to.col) return 'move';
    return 'move';
  }

  private static reconstructPath(node: GameStateNode): Position[] {
    const path: Position[] = [];
    let current = node;
    
    while (current) {
      path.unshift(current.position);
      current = current.parent!;
    }
    
    return path;
  }
}

// ===== COST-BASED SEARCH ALGORITHMS =====
export class CostBasedSearchAlgorithms {
  // Uniform Cost Search (UCS)
  static uniformCostSearch(
    startPos: Position, 
    goalPos: Position, 
    gameState: GameState
  ): SearchResult {
    const startTime = performance.now();
    const priorityQueue: GameStateNode[] = [];
    const visited = new Map<string, number>();
    const steps: SearchStep[] = [];
    let nodesExplored = 0;

    const startNode: GameStateNode = {
      gameState,
      position: startPos,
      cost: 0,
      depth: 0,
      parent: null,
      action: null,
      heuristicValue: 0,
      pathCost: 0,
      evaluation: 0
    };

    priorityQueue.push(startNode);

    while (priorityQueue.length > 0) {
      // Sort by cost (UCS characteristic)
      priorityQueue.sort((a, b) => a.cost - b.cost);
      const current = priorityQueue.shift()!;
      const key = `${current.position.row},${current.position.col}`;
      
      // Skip if we've found a better path to this state
      if (visited.has(key) && visited.get(key)! < current.cost) {
        continue;
      }
      
      visited.set(key, current.cost);
      nodesExplored++;

      steps.push({
        position: current.position,
        action: current.action || 'start',
        cost: current.cost,
        heuristic: 0,
        evaluation: current.cost,
        nodesInQueue: priorityQueue.length,
        timestamp: performance.now() - startTime
      });

      // Goal test
      if (current.position.row === goalPos.row && current.position.col === goalPos.col) {
        const path = BlindSearchAlgorithms['reconstructPath'](current);
        return {
          algorithm: 'UCS',
          path,
          totalCost: current.cost,
          nodesExplored,
          executionTime: performance.now() - startTime,
          memoryUsed: priorityQueue.length + visited.size,
          optimal: true,
          reasoning: 'UCS guarantees optimal solution by exploring lowest cost paths first',
          steps
        };
      }

      // Expand neighbors
      const neighbors = BlindSearchAlgorithms['getValidNeighbors'](current.position, gameState);
      for (const neighbor of neighbors) {
        const neighborKey = `${neighbor.row},${neighbor.col}`;
        const stepCost = this.getStepCost(current.position, neighbor, gameState);
        const newCost = current.cost + stepCost;
        
        if (!visited.has(neighborKey) || visited.get(neighborKey)! > newCost) {
          const neighborNode: GameStateNode = {
            gameState,
            position: neighbor,
            cost: newCost,
            depth: current.depth + 1,
            parent: current,
            action: BlindSearchAlgorithms['getActionType'](current.position, neighbor),
            heuristicValue: 0,
            pathCost: newCost,
            evaluation: newCost
          };
          priorityQueue.push(neighborNode);
        }
      }
    }

    return {
      algorithm: 'UCS',
      path: [],
      totalCost: Infinity,
      nodesExplored,
      executionTime: performance.now() - startTime,
      memoryUsed: visited.size,
      optimal: false,
      reasoning: 'No path found',
      steps
    };
  }

  // A* Search Algorithm
  static aStarSearch(
    startPos: Position, 
    goalPos: Position, 
    gameState: GameState,
    heuristicType: 'manhattan' | 'euclidean' | 'strategic' = 'manhattan'
  ): SearchResult {
    const startTime = performance.now();
    const openSet: GameStateNode[] = [];
    const closedSet = new Set<string>();
    const gScore = new Map<string, number>();
    const steps: SearchStep[] = [];
    let nodesExplored = 0;

    const startNode: GameStateNode = {
      gameState,
      position: startPos,
      cost: 0,
      depth: 0,
      parent: null,
      action: null,
      heuristicValue: this.calculateHeuristic(startPos, goalPos, gameState, heuristicType),
      pathCost: 0,
      evaluation: this.calculateHeuristic(startPos, goalPos, gameState, heuristicType)
    };

    openSet.push(startNode);
    gScore.set(`${startPos.row},${startPos.col}`, 0);

    while (openSet.length > 0) {
      // Sort by f(n) = g(n) + h(n)
      openSet.sort((a, b) => a.evaluation - b.evaluation);
      const current = openSet.shift()!;
      const currentKey = `${current.position.row},${current.position.col}`;
      
      if (closedSet.has(currentKey)) continue;
      
      closedSet.add(currentKey);
      nodesExplored++;

      steps.push({
        position: current.position,
        action: current.action || 'start',
        cost: current.cost,
        heuristic: current.heuristicValue,
        evaluation: current.evaluation,
        nodesInQueue: openSet.length,
        timestamp: performance.now() - startTime
      });

      // Goal test
      if (current.position.row === goalPos.row && current.position.col === goalPos.col) {
        const path = BlindSearchAlgorithms['reconstructPath'](current);
        return {
          algorithm: `A* (${heuristicType})`,
          path,
          totalCost: current.cost,
          nodesExplored,
          executionTime: performance.now() - startTime,
          memoryUsed: openSet.length + closedSet.size,
          optimal: true,
          reasoning: `A* with ${heuristicType} heuristic guarantees optimal solution`,
          steps
        };
      }

      // Expand neighbors
      const neighbors = BlindSearchAlgorithms['getValidNeighbors'](current.position, gameState);
      for (const neighbor of neighbors) {
        const neighborKey = `${neighbor.row},${neighbor.col}`;
        if (closedSet.has(neighborKey)) continue;

        const stepCost = this.getStepCost(current.position, neighbor, gameState);
        const tentativeG = current.cost + stepCost;
        
        if (!gScore.has(neighborKey) || tentativeG < gScore.get(neighborKey)!) {
          gScore.set(neighborKey, tentativeG);
          const heuristic = this.calculateHeuristic(neighbor, goalPos, gameState, heuristicType);
          
          const neighborNode: GameStateNode = {
            gameState,
            position: neighbor,
            cost: tentativeG,
            depth: current.depth + 1,
            parent: current,
            action: BlindSearchAlgorithms['getActionType'](current.position, neighbor),
            heuristicValue: heuristic,
            pathCost: tentativeG,
            evaluation: tentativeG + heuristic
          };
          
          openSet.push(neighborNode);
        }
      }
    }

    return {
      algorithm: `A* (${heuristicType})`,
      path: [],
      totalCost: Infinity,
      nodesExplored,
      executionTime: performance.now() - startTime,
      memoryUsed: closedSet.size,
      optimal: false,
      reasoning: 'No path found',
      steps
    };
  }

  private static getStepCost(from: Position, to: Position, gameState: GameState): number {
    const cell = gameState.grid[to.row][to.col];
    
    switch (cell.type) {
      case 'water': return 2;
      case 'mud': return 2;
      case 'sand': return 3;
      case 'trap': return 5;
      case 'ladder': return 0.5;
      default: return 1;
    }
  }

  private static calculateHeuristic(
    pos: Position, 
    goal: Position, 
    gameState: GameState, 
    type: string
  ): number {
    switch (type) {
      case 'euclidean':
        return HeuristicFunctions.euclideanDistance(pos, goal);
      case 'strategic':
        return HeuristicFunctions.strategicHeuristic(pos, gameState, goal);
      case 'manhattan':
      default:
        return HeuristicFunctions.manhattanDistance(pos, goal);
    }
  }
}

// ===== PERFORMANCE COMPARISON SYSTEM =====
export class PerformanceComparison {
  static async compareAlgorithms(
    startPos: Position,
    goalPos: Position,
    gameState: GameState
  ): Promise<{
    results: SearchResult[];
    comparison: AlgorithmComparison;
    recommendation: string;
  }> {
    const algorithms = [
      () => BlindSearchAlgorithms.breadthFirstSearch(startPos, goalPos, gameState),
      () => BlindSearchAlgorithms.depthFirstSearch(startPos, goalPos, gameState),
      () => CostBasedSearchAlgorithms.uniformCostSearch(startPos, goalPos, gameState),
      () => CostBasedSearchAlgorithms.aStarSearch(startPos, goalPos, gameState, 'manhattan'),
      () => CostBasedSearchAlgorithms.aStarSearch(startPos, goalPos, gameState, 'euclidean'),
      () => CostBasedSearchAlgorithms.aStarSearch(startPos, goalPos, gameState, 'strategic')
    ];

    const results: SearchResult[] = [];
    
    for (const algorithm of algorithms) {
      try {
        const result = algorithm();
        results.push(result);
      } catch (error) {
        console.error('Algorithm failed:', error);
      }
    }

    const comparison = this.analyzeResults(results);
    const recommendation = this.generateRecommendation(results, comparison);

    return { results, comparison, recommendation };
  }

  private static analyzeResults(results: SearchResult[]): AlgorithmComparison {
    const validResults = results.filter(r => r.path.length > 0);
    
    if (validResults.length === 0) {
      return {
        fastest: null,
        mostMemoryEfficient: null,
        mostOptimal: null,
        averageTime: 0,
        averageMemory: 0,
        averageNodes: 0
      };
    }

    const fastest = validResults.reduce((min, curr) => 
      curr.executionTime < min.executionTime ? curr : min
    );

    const mostMemoryEfficient = validResults.reduce((min, curr) => 
      curr.memoryUsed < min.memoryUsed ? curr : min
    );

    const mostOptimal = validResults.reduce((min, curr) => 
      curr.totalCost < min.totalCost ? curr : min
    );

    const averageTime = validResults.reduce((sum, r) => sum + r.executionTime, 0) / validResults.length;
    const averageMemory = validResults.reduce((sum, r) => sum + r.memoryUsed, 0) / validResults.length;
    const averageNodes = validResults.reduce((sum, r) => sum + r.nodesExplored, 0) / validResults.length;

    return {
      fastest,
      mostMemoryEfficient,
      mostOptimal,
      averageTime,
      averageMemory,
      averageNodes
    };
  }

  private static generateRecommendation(results: SearchResult[], comparison: AlgorithmComparison): string {
    const validResults = results.filter(r => r.path.length > 0);
    
    if (validResults.length === 0) {
      return "No algorithms found a valid path. Consider revising the game state or start/goal positions.";
    }

    let recommendation = "Algorithm Performance Analysis:\n\n";

    if (comparison.fastest) {
      recommendation += `⚡ Fastest: ${comparison.fastest.algorithm} (${comparison.fastest.executionTime.toFixed(2)}ms)\n`;
    }

    if (comparison.mostMemoryEfficient) {
      recommendation += `🧠 Most Memory Efficient: ${comparison.mostMemoryEfficient.algorithm} (${comparison.mostMemoryEfficient.memoryUsed} nodes)\n`;
    }

    if (comparison.mostOptimal) {
      recommendation += `🎯 Most Optimal: ${comparison.mostOptimal.algorithm} (cost: ${comparison.mostOptimal.totalCost})\n`;
    }

    recommendation += `\n📊 Averages:\n`;
    recommendation += `- Time: ${comparison.averageTime.toFixed(2)}ms\n`;
    recommendation += `- Memory: ${comparison.averageMemory.toFixed(0)} nodes\n`;
    recommendation += `- Nodes Explored: ${comparison.averageNodes.toFixed(0)}\n`;

    recommendation += `\n🏆 Recommendation: A* with Manhattan heuristic provides the best balance of optimality and efficiency for this game.`;

    return recommendation;
  }
}

export interface AlgorithmComparison {
  fastest: SearchResult | null;
  mostMemoryEfficient: SearchResult | null;
  mostOptimal: SearchResult | null;
  averageTime: number;
  averageMemory: number;
  averageNodes: number;
}

// ===== STRATEGIC DECISION-MAKING =====
export class StrategicDecisionMaking {
  static evaluateWallPlacement(
    position: Position,
    gameState: GameState,
    humanPos: Position,
    aiPos: Position
  ): {
    effectiveness: number;
    reasoning: string;
    impactAnalysis: string;
  } {
    // Analyze multiple factors for wall placement
    const humanToTreasureBlocking = this.analyzePathBlocking(humanPos, gameState.treasures[0].position, position, gameState);
    const aiPathOptimization = this.analyzePathOptimization(aiPos, gameState.treasures[0].position, position, gameState);
    const chokePointValue = this.analyzeChokePoints(position, gameState);
    const timing = this.analyzeWallTiming(gameState);

    const effectiveness = (humanToTreasureBlocking * 0.4 + aiPathOptimization * 0.3 + chokePointValue * 0.2 + timing * 0.1);

    const reasoning = this.generateWallPlacementReasoning(
      humanToTreasureBlocking,
      aiPathOptimization,
      chokePointValue,
      timing
    );

    const impactAnalysis = this.generateImpactAnalysis(position, gameState, humanPos, aiPos);

    return { effectiveness, reasoning, impactAnalysis };
  }

  static evaluateLadderPlacement(
    position: Position,
    gameState: GameState,
    aiPos: Position
  ): {
    effectiveness: number;
    reasoning: string;
    shortcutValue: number;
  } {
    const shortcutValue = this.analyzeLadderShortcut(aiPos, gameState.treasures[0].position, position, gameState);
    const terrainAdvantage = this.analyzeLadderTerrainAdvantage(position, gameState);
    const strategicValue = this.analyzeLadderStrategicValue(position, gameState, aiPos);

    const effectiveness = (shortcutValue * 0.5 + terrainAdvantage * 0.3 + strategicValue * 0.2);

    const reasoning = `Ladder placement analysis: Shortcut value (${shortcutValue.toFixed(2)}), Terrain advantage (${terrainAdvantage.toFixed(2)}), Strategic value (${strategicValue.toFixed(2)})`;

    return { effectiveness, reasoning, shortcutValue };
  }

  private static analyzePathBlocking(
    start: Position,
    goal: Position,
    wallPos: Position,
    gameState: GameState
  ): number {
    // Simulate path with and without wall
    const originalPath = CostBasedSearchAlgorithms.aStarSearch(start, goal, gameState);
    
    // Create temporary game state with wall
    const tempGameState = JSON.parse(JSON.stringify(gameState));
    tempGameState.grid[wallPos.row][wallPos.col].type = 'wall';
    
    const blockedPath = CostBasedSearchAlgorithms.aStarSearch(start, goal, tempGameState);
    
    if (blockedPath.path.length === 0) {
      return 1.0; // Complete blocking
    }
    
    return Math.min(1.0, (blockedPath.totalCost - originalPath.totalCost) / originalPath.totalCost);
  }

  private static analyzePathOptimization(
    start: Position,
    goal: Position,
    wallPos: Position,
    gameState: GameState
  ): number {
    // Similar to blocking but for AI optimization
    const originalPath = CostBasedSearchAlgorithms.aStarSearch(start, goal, gameState);
    
    const tempGameState = JSON.parse(JSON.stringify(gameState));
    tempGameState.grid[wallPos.row][wallPos.col].type = 'wall';
    
    const newPath = CostBasedSearchAlgorithms.aStarSearch(start, goal, tempGameState);
    
    if (newPath.path.length === 0) {
      return 0; // Wall blocks AI too
    }
    
    return Math.max(0, (originalPath.totalCost - newPath.totalCost) / originalPath.totalCost);
  }

  private static analyzeChokePoints(position: Position, gameState: GameState): number {
    // Analyze how critical this position is for path navigation
    const neighbors = this.getNeighborPositions(position);
    const wallCount = neighbors.filter(pos => 
      gameState.grid[pos.row]?.[pos.col]?.type === 'wall'
    ).length;
    
    return wallCount / 4; // Normalized by max possible walls
  }

  private static analyzeWallTiming(gameState: GameState): number {
    // Later in game = more valuable walls
    const gameProgress = gameState.turnCount / 100; // Assuming max 100 turns
    return Math.min(1.0, gameProgress);
  }

  private static generateWallPlacementReasoning(
    blocking: number,
    optimization: number,
    chokePoint: number,
    timing: number
  ): string {
    let reasoning = "Wall placement analysis: ";
    
    if (blocking > 0.7) {
      reasoning += "Excellent blocking potential. ";
    } else if (blocking > 0.4) {
      reasoning += "Good blocking potential. ";
    } else {
      reasoning += "Limited blocking effect. ";
    }
    
    if (optimization > 0.5) {
      reasoning += "Provides AI path optimization. ";
    }
    
    if (chokePoint > 0.5) {
      reasoning += "Strategic chokepoint location. ";
    }
    
    if (timing > 0.6) {
      reasoning += "Good timing for wall placement.";
    } else {
      reasoning += "Early for wall placement.";
    }
    
    return reasoning;
  }

  private static generateImpactAnalysis(
    position: Position,
    gameState: GameState,
    humanPos: Position,
    aiPos: Position
  ): string {
    const humanDistance = HeuristicFunctions.manhattanDistance(position, humanPos);
    const aiDistance = HeuristicFunctions.manhattanDistance(position, aiPos);
    
    let analysis = `Impact Analysis:\n`;
    analysis += `- Distance from Human: ${humanDistance}\n`;
    analysis += `- Distance from AI: ${aiDistance}\n`;
    analysis += `- Affects Human more: ${humanDistance < aiDistance ? 'Yes' : 'No'}\n`;
    
    return analysis;
  }

  private static analyzeLadderShortcut(
    start: Position,
    goal: Position,
    ladderPos: Position,
    gameState: GameState
  ): number {
    const originalPath = CostBasedSearchAlgorithms.aStarSearch(start, goal, gameState);
    
    const tempGameState = JSON.parse(JSON.stringify(gameState));
    tempGameState.grid[ladderPos.row][ladderPos.col].type = 'ladder';
    
    const ladderPath = CostBasedSearchAlgorithms.aStarSearch(start, goal, tempGameState);
    
    if (ladderPath.path.length === 0) {
      return 0;
    }
    
    return Math.max(0, (originalPath.totalCost - ladderPath.totalCost) / originalPath.totalCost);
  }

  private static analyzeLadderTerrainAdvantage(position: Position, gameState: GameState): number {
    const cell = gameState.grid[position.row][position.col];
    
    switch (cell.type) {
      case 'water':
      case 'mud':
      case 'sand':
        return 0.8; // High value on difficult terrain
      case 'trap':
        return 0.9; // Very high value on trap
      default:
        return 0.3; // Lower value on normal terrain
    }
  }

  private static analyzeLadderStrategicValue(
    position: Position,
    gameState: GameState,
    aiPos: Position
  ): number {
    const distanceToAI = HeuristicFunctions.manhattanDistance(position, aiPos);
    const treasureDistance = Math.min(
      ...gameState.treasures.map(t => HeuristicFunctions.manhattanDistance(position, t.position))
    );
    
    // Closer to AI and further from treasure = less valuable
    return Math.max(0, (distanceToAI - treasureDistance) / 10);
  }

  private static getNeighborPositions(position: Position): Position[] {
    return [
      { row: position.row - 1, col: position.col },
      { row: position.row + 1, col: position.col },
      { row: position.row, col: position.col - 1 },
      { row: position.row, col: position.col + 1 }
    ];
  }
}