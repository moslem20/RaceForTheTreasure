import { Position, Cell, AlgorithmResult, AlgorithmStep, AlgorithmType } from './types';
import { getNeighbors, getDistance, reconstructPath } from './utils';

export class PathfindingAlgorithms {
  
  static async bfs(
    grid: Cell[][],
    start: Position,
    goal: Position,
    onStep?: (step: AlgorithmStep) => void
  ): Promise<AlgorithmResult> {
    const startTime = performance.now();
    const queue: Cell[] = [];
    const explored: Set<string> = new Set();
    const steps: AlgorithmStep[] = [];
    
    const startCell = grid[start.y][start.x];
    queue.push(startCell);
    
    let nodesExplored = 0;
    
    while (queue.length > 0) {
      const current = queue.shift()!;
      const currentKey = `${current.x},${current.y}`;
      
      if (explored.has(currentKey)) continue;
      explored.add(currentKey);
      nodesExplored++;
      
      // Create step for visualization
      const step: AlgorithmStep = {
        current: { x: current.x, y: current.y },
        queue: queue.map(cell => ({ x: cell.x, y: cell.y })),
        explored: Array.from(explored).map(key => {
          const [x, y] = key.split(',').map(Number);
          return { x, y };
        }),
        path: [],
        message: `BFS: Exploring node (${current.x}, ${current.y})`
      };
      
      if (onStep) onStep(step);
      
      // Check if we reached the goal
      if (current.x === goal.x && current.y === goal.y) {
        const path = reconstructPath(current);
        const endTime = performance.now();
        
        return {
          path,
          exploredNodes: Array.from(explored).map(key => {
            const [x, y] = key.split(',').map(Number);
            return { x, y };
          }),
          totalCost: path.reduce((sum, pos, index) => {
            if (index === 0) return 0;
            return sum + grid[pos.y][pos.x].cost;
          }, 0),
          nodesExplored,
          executionTime: endTime - startTime,
          pathLength: path.length - 1,
          found: true
        };
      }
      
      // Add neighbors to queue
      const neighbors = getNeighbors(current, grid);
      for (const neighbor of neighbors) {
        const neighborKey = `${neighbor.x},${neighbor.y}`;
        if (!neighbor.isWall && !explored.has(neighborKey)) {
          neighbor.parent = current;
          if (!queue.some(cell => cell.x === neighbor.x && cell.y === neighbor.y)) {
            queue.push(neighbor);
          }
        }
      }
    }
    
    const endTime = performance.now();
    return {
      path: [],
      exploredNodes: Array.from(explored).map(key => {
        const [x, y] = key.split(',').map(Number);
        return { x, y };
      }),
      totalCost: 0,
      nodesExplored,
      executionTime: endTime - startTime,
      pathLength: 0,
      found: false
    };
  }
  
  static async dfs(
    grid: Cell[][],
    start: Position,
    goal: Position,
    onStep?: (step: AlgorithmStep) => void
  ): Promise<AlgorithmResult> {
    const startTime = performance.now();
    const stack: Cell[] = [];
    const explored: Set<string> = new Set();
    
    const startCell = grid[start.y][start.x];
    stack.push(startCell);
    
    let nodesExplored = 0;
    
    while (stack.length > 0) {
      const current = stack.pop()!;
      const currentKey = `${current.x},${current.y}`;
      
      if (explored.has(currentKey)) continue;
      explored.add(currentKey);
      nodesExplored++;
      
      const step: AlgorithmStep = {
        current: { x: current.x, y: current.y },
        queue: stack.map(cell => ({ x: cell.x, y: cell.y })),
        explored: Array.from(explored).map(key => {
          const [x, y] = key.split(',').map(Number);
          return { x, y };
        }),
        path: [],
        message: `DFS: Exploring node (${current.x}, ${current.y})`
      };
      
      if (onStep) onStep(step);
      
      if (current.x === goal.x && current.y === goal.y) {
        const path = reconstructPath(current);
        const endTime = performance.now();
        
        return {
          path,
          exploredNodes: Array.from(explored).map(key => {
            const [x, y] = key.split(',').map(Number);
            return { x, y };
          }),
          totalCost: path.reduce((sum, pos, index) => {
            if (index === 0) return 0;
            return sum + grid[pos.y][pos.x].cost;
          }, 0),
          nodesExplored,
          executionTime: endTime - startTime,
          pathLength: path.length - 1,
          found: true
        };
      }
      
      const neighbors = getNeighbors(current, grid);
      for (const neighbor of neighbors) {
        const neighborKey = `${neighbor.x},${neighbor.y}`;
        if (!neighbor.isWall && !explored.has(neighborKey)) {
          neighbor.parent = current;
          stack.push(neighbor);
        }
      }
    }
    
    const endTime = performance.now();
    return {
      path: [],
      exploredNodes: Array.from(explored).map(key => {
        const [x, y] = key.split(',').map(Number);
        return { x, y };
      }),
      totalCost: 0,
      nodesExplored,
      executionTime: endTime - startTime,
      pathLength: 0,
      found: false
    };
  }
  
  static async ucs(
    grid: Cell[][],
    start: Position,
    goal: Position,
    onStep?: (step: AlgorithmStep) => void
  ): Promise<AlgorithmResult> {
    const startTime = performance.now();
    const openSet: Cell[] = [];
    const closedSet: Set<string> = new Set();
    
    const startCell = grid[start.y][start.x];
    startCell.gCost = 0;
    openSet.push(startCell);
    
    let nodesExplored = 0;
    
    while (openSet.length > 0) {
      // Sort by gCost (total path cost)
      openSet.sort((a, b) => a.gCost - b.gCost);
      const current = openSet.shift()!;
      const currentKey = `${current.x},${current.y}`;
      
      if (closedSet.has(currentKey)) continue;
      closedSet.add(currentKey);
      nodesExplored++;
      
      const step: AlgorithmStep = {
        current: { x: current.x, y: current.y },
        queue: openSet.map(cell => ({ x: cell.x, y: cell.y })),
        explored: Array.from(closedSet).map(key => {
          const [x, y] = key.split(',').map(Number);
          return { x, y };
        }),
        path: [],
        message: `UCS: Exploring node (${current.x}, ${current.y}), cost: ${current.gCost}`
      };
      
      if (onStep) onStep(step);
      
      if (current.x === goal.x && current.y === goal.y) {
        const path = reconstructPath(current);
        const endTime = performance.now();
        
        return {
          path,
          exploredNodes: Array.from(closedSet).map(key => {
            const [x, y] = key.split(',').map(Number);
            return { x, y };
          }),
          totalCost: current.gCost,
          nodesExplored,
          executionTime: endTime - startTime,
          pathLength: path.length - 1,
          found: true
        };
      }
      
      const neighbors = getNeighbors(current, grid);
      for (const neighbor of neighbors) {
        const neighborKey = `${neighbor.x},${neighbor.y}`;
        if (neighbor.isWall || closedSet.has(neighborKey)) continue;
        
        const tentativeG = current.gCost + neighbor.cost;
        
        const existingInOpen = openSet.find(cell => cell.x === neighbor.x && cell.y === neighbor.y);
        if (!existingInOpen || tentativeG < neighbor.gCost) {
          neighbor.gCost = tentativeG;
          neighbor.parent = current;
          
          if (!existingInOpen) {
            openSet.push(neighbor);
          }
        }
      }
    }
    
    const endTime = performance.now();
    return {
      path: [],
      exploredNodes: Array.from(closedSet).map(key => {
        const [x, y] = key.split(',').map(Number);
        return { x, y };
      }),
      totalCost: 0,
      nodesExplored,
      executionTime: endTime - startTime,
      pathLength: 0,
      found: false
    };
  }
  
  static async aStar(
    grid: Cell[][],
    start: Position,
    goal: Position,
    onStep?: (step: AlgorithmStep) => void
  ): Promise<AlgorithmResult> {
    const startTime = performance.now();
    const openSet: Cell[] = [];
    const closedSet: Set<string> = new Set();
    
    const startCell = grid[start.y][start.x];
    startCell.gCost = 0;
    startCell.hCost = getDistance(start, goal);
    startCell.fCost = startCell.gCost + startCell.hCost;
    openSet.push(startCell);
    
    let nodesExplored = 0;
    
    while (openSet.length > 0) {
      // Sort by fCost (g + h)
      openSet.sort((a, b) => a.fCost - b.fCost);
      const current = openSet.shift()!;
      const currentKey = `${current.x},${current.y}`;
      
      if (closedSet.has(currentKey)) continue;
      closedSet.add(currentKey);
      nodesExplored++;
      
      const step: AlgorithmStep = {
        current: { x: current.x, y: current.y },
        queue: openSet.map(cell => ({ x: cell.x, y: cell.y })),
        explored: Array.from(closedSet).map(key => {
          const [x, y] = key.split(',').map(Number);
          return { x, y };
        }),
        path: [],
        message: `A*: Exploring node (${current.x}, ${current.y}), f=${current.fCost}, g=${current.gCost}, h=${current.hCost}`
      };
      
      if (onStep) onStep(step);
      
      if (current.x === goal.x && current.y === goal.y) {
        const path = reconstructPath(current);
        const endTime = performance.now();
        
        return {
          path,
          exploredNodes: Array.from(closedSet).map(key => {
            const [x, y] = key.split(',').map(Number);
            return { x, y };
          }),
          totalCost: current.gCost,
          nodesExplored,
          executionTime: endTime - startTime,
          pathLength: path.length - 1,
          found: true
        };
      }
      
      const neighbors = getNeighbors(current, grid);
      for (const neighbor of neighbors) {
        const neighborKey = `${neighbor.x},${neighbor.y}`;
        if (neighbor.isWall || closedSet.has(neighborKey)) continue;
        
        const tentativeG = current.gCost + neighbor.cost;
        
        const existingInOpen = openSet.find(cell => cell.x === neighbor.x && cell.y === neighbor.y);
        if (!existingInOpen || tentativeG < neighbor.gCost) {
          neighbor.gCost = tentativeG;
          neighbor.hCost = getDistance({ x: neighbor.x, y: neighbor.y }, goal);
          neighbor.fCost = neighbor.gCost + neighbor.hCost;
          neighbor.parent = current;
          
          if (!existingInOpen) {
            openSet.push(neighbor);
          }
        }
      }
    }
    
    const endTime = performance.now();
    return {
      path: [],
      exploredNodes: Array.from(closedSet).map(key => {
        const [x, y] = key.split(',').map(Number);
        return { x, y };
      }),
      totalCost: 0,
      nodesExplored,
      executionTime: endTime - startTime,
      pathLength: 0,
      found: false
    };
  }
}
