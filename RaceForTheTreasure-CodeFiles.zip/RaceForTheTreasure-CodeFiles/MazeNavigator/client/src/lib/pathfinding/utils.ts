import { Position, Cell, CellType } from './types';

export const getDistance = (a: Position, b: Position): number => {
  return Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
};

export const getEuclideanDistance = (a: Position, b: Position): number => {
  return Math.sqrt(Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2));
};

export const getNeighbors = (position: Position, grid: Cell[][]): Cell[] => {
  const neighbors: Cell[] = [];
  const directions = [
    { x: 0, y: -1 }, // up
    { x: 1, y: 0 },  // right
    { x: 0, y: 1 },  // down
    { x: -1, y: 0 }  // left
  ];

  for (const dir of directions) {
    const newX = position.x + dir.x;
    const newY = position.y + dir.y;

    if (newX >= 0 && newX < grid[0].length && newY >= 0 && newY < grid.length) {
      neighbors.push(grid[newY][newX]);
    }
  }

  return neighbors;
};

export const createEmptyGrid = (size: number): Cell[][] => {
  const grid: Cell[][] = [];
  
  for (let y = 0; y < size; y++) {
    const row: Cell[] = [];
    for (let x = 0; x < size; x++) {
      row.push({
        x,
        y,
        type: CellType.EMPTY,
        cost: 1,
        isStart: false,
        isGoal: false,
        isWall: false,
        isPath: false,
        isExplored: false,
        isInQueue: false,
        gCost: 0,
        hCost: 0,
        fCost: 0,
        parent: null
      });
    }
    grid.push(row);
  }
  
  return grid;
};

export const resetGridVisualization = (grid: Cell[][]): Cell[][] => {
  return grid.map(row =>
    row.map(cell => ({
      ...cell,
      isPath: false,
      isExplored: false,
      isInQueue: false,
      gCost: 0,
      hCost: 0,
      fCost: 0,
      parent: null
    }))
  );
};

export const getCellCost = (cellType: CellType): number => {
  switch (cellType) {
    case CellType.EMPTY:
    case CellType.START:
    case CellType.GOAL:
      return 1;
    case CellType.MUD:
      return 3;
    case CellType.SAND:
      return 2;
    case CellType.WATER:
      return 5;
    default:
      return 1;
  }
};

export const getCellColor = (cell: Cell): string => {
  if (cell.isStart) return '#22c55e'; // green
  if (cell.isGoal) return '#ef4444'; // red
  if (cell.isWall) return '#1f2937'; // dark gray
  if (cell.isPath) return '#ff6b35'; // bright orange for highlighted path
  if (cell.isExplored) return '#93c5fd'; // light blue
  if (cell.isInQueue) return '#c084fc'; // light purple
  
  switch (cell.type) {
    case CellType.MUD:
      return '#92400e'; // brown
    case CellType.SAND:
      return '#f59e0b'; // orange
    case CellType.WATER:
      return '#3b82f6'; // blue
    default:
      return '#f3f4f6'; // light gray
  }
};

export const reconstructPath = (goalCell: Cell): Position[] => {
  const path: Position[] = [];
  let current: Cell | null = goalCell;
  
  while (current) {
    path.unshift({ x: current.x, y: current.y });
    current = current.parent;
  }
  
  return path;
};

export const generateRandomMaze = (size: number, wallProbability: number = 0.3): Cell[][] => {
  const grid = createEmptyGrid(size);
  
  // Add random walls
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      if (Math.random() < wallProbability) {
        grid[y][x].type = CellType.WALL;
        grid[y][x].isWall = true;
      }
    }
  }
  
  // Add random terrain types
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      if (!grid[y][x].isWall) {
        const rand = Math.random();
        if (rand < 0.1) {
          grid[y][x].type = CellType.MUD;
          grid[y][x].cost = getCellCost(CellType.MUD);
        } else if (rand < 0.15) {
          grid[y][x].type = CellType.SAND;
          grid[y][x].cost = getCellCost(CellType.SAND);
        } else if (rand < 0.2) {
          grid[y][x].type = CellType.WATER;
          grid[y][x].cost = getCellCost(CellType.WATER);
        }
      }
    }
  }
  
  return grid;
};
