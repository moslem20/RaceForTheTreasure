export interface Position {
  x: number;
  y: number;
}

export interface Cell {
  x: number;
  y: number;
  type: CellType;
  cost: number;
  isStart: boolean;
  isGoal: boolean;
  isWall: boolean;
  isPath: boolean;
  isExplored: boolean;
  isInQueue: boolean;
  gCost: number;
  hCost: number;
  fCost: number;
  parent: Cell | null;
}

export enum CellType {
  EMPTY = 'empty',
  WALL = 'wall',
  START = 'start',
  GOAL = 'goal',
  PATH = 'path',
  EXPLORED = 'explored',
  QUEUE = 'queue',
  MUD = 'mud',
  SAND = 'sand',
  WATER = 'water'
}

export enum AlgorithmType {
  BFS = 'BFS',
  DFS = 'DFS',
  UCS = 'UCS',
  ASTAR = 'A*'
}

export interface AlgorithmResult {
  path: Position[];
  exploredNodes: Position[];
  totalCost: number;
  nodesExplored: number;
  executionTime: number;
  pathLength: number;
  found: boolean;
}

export interface AlgorithmStep {
  current: Position;
  queue: Position[];
  explored: Position[];
  path: Position[];
  message: string;
}

export enum EditMode {
  WALL = 'wall',
  START = 'start',
  GOAL = 'goal',
  MUD = 'mud',
  SAND = 'sand',
  WATER = 'water',
  ERASE = 'erase'
}

export interface GridState {
  grid: Cell[][];
  size: number;
  start: Position | null;
  goal: Position | null;
}

export interface ComparisonData {
  winner: AlgorithmType;
  winnerTime: number;
  totalComparisonTime: number;
}

export interface VisualizationState {
  isRunning: boolean;
  currentAlgorithm: AlgorithmType | null;
  currentStep: number;
  steps: AlgorithmStep[];
  results: Map<AlgorithmType, AlgorithmResult>;
  speed: number;
  comparisonData?: ComparisonData | null;
}
