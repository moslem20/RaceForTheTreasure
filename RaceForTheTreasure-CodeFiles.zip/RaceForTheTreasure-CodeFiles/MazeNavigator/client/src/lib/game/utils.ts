import { Position, Cell, TerrainType, Player, GameState } from './types';

export const getTerrainCost = (terrain: TerrainType): number => {
  switch (terrain) {
    case TerrainType.EMPTY:
    case TerrainType.TREASURE:
    case TerrainType.POWER_UP:
      return 1;
    case TerrainType.WATER:
    case TerrainType.MUD:
      return 2;
    case TerrainType.SAND:
      return 3;
    case TerrainType.LADDER:
      return 0.5; // Ladder provides advantage
    case TerrainType.TRAP:
      return 1; // Normal cost but with stun effect
    case TerrainType.WALL:
    case TerrainType.PLAYER_WALL:
      return Infinity; // Impassable
    default:
      return 1;
  }
};

export const getTerrainColor = (cell: Cell): string => {
  if (cell.playerId === 'human') {
    return '#3b82f6'; // Blue for human player
  }
  if (cell.playerId === 'ai') {
    return '#ef4444'; // Red for AI player
  }
  
  switch (cell.terrain) {
    case TerrainType.EMPTY:
      return '#f8fafc';
    case TerrainType.WALL:
      return '#1e293b';
    case TerrainType.PLAYER_WALL:
      return '#7c3aed'; // Purple for player-placed walls
    case TerrainType.WATER:
      return '#0ea5e9';
    case TerrainType.MUD:
      return '#a16207';
    case TerrainType.SAND:
      return '#eab308';
    case TerrainType.TREASURE:
      return '#fbbf24'; // Gold
    case TerrainType.LADDER:
      return '#10b981'; // Green
    case TerrainType.TRAP:
      return '#dc2626'; // Red for traps
    case TerrainType.POWER_UP:
      return '#8b5cf6'; // Purple for power-ups
    default:
      return '#f8fafc';
  }
};

export const getManhattanDistance = (a: Position, b: Position): number => {
  return Math.abs(a.x - b.x) + Math.abs(a.y - b.y);
};

export const getChebyshevDistance = (a: Position, b: Position): number => {
  return Math.max(Math.abs(a.x - b.x), Math.abs(a.y - b.y));
};

export const isValidPosition = (pos: Position, gridSize: number): boolean => {
  return pos.x >= 0 && pos.x < gridSize && pos.y >= 0 && pos.y < gridSize;
};

export const getNeighbors = (position: Position, grid: Cell[][]): Position[] => {
  const neighbors: Position[] = [];
  const directions = [
    { x: 0, y: -1 }, // Up
    { x: 1, y: 0 },  // Right
    { x: 0, y: 1 },  // Down
    { x: -1, y: 0 }  // Left
  ];

  for (const dir of directions) {
    const newPos = { x: position.x + dir.x, y: position.y + dir.y };
    if (isValidPosition(newPos, grid.length)) {
      const cell = grid[newPos.y][newPos.x];
      if (getTerrainCost(cell.terrain) !== Infinity) {
        neighbors.push(newPos);
      }
    }
  }

  return neighbors;
};

export const createEmptyGrid = (size: number): Cell[][] => {
  const grid: Cell[][] = [];
  for (let y = 0; y < size; y++) {
    const row: Cell[] = [];
    for (let x = 0; x < size; x++) {
      row.push({
        x,
        y,
        terrain: TerrainType.EMPTY,
        cost: getTerrainCost(TerrainType.EMPTY)
      });
    }
    grid.push(row);
  }
  return grid;
};

export const generateRandomObstacles = (grid: Cell[][], density: number = 0.15): Cell[][] => {
  const newGrid = grid.map(row => row.map(cell => ({ ...cell })));
  const terrainTypes = [TerrainType.WATER, TerrainType.MUD, TerrainType.SAND, TerrainType.WALL, TerrainType.TRAP, TerrainType.POWER_UP];
  
  for (let y = 0; y < newGrid.length; y++) {
    for (let x = 0; x < newGrid[y].length; x++) {
      // Skip corners and center areas for player spawns
      if ((x === 0 && y === 0) || (x === newGrid.length - 1 && y === newGrid.length - 1) ||
          (x === newGrid.length - 1 && y === 0) || (x === 0 && y === newGrid.length - 1)) {
        continue;
      }
      
      if (Math.random() < density) {
        // Weight the terrain types - make power-ups and traps rarer
        const rand = Math.random();
        let randomTerrain: TerrainType;
        
        if (rand < 0.03) { // 3% chance for power-up
          randomTerrain = TerrainType.POWER_UP;
        } else if (rand < 0.08) { // 5% chance for trap
          randomTerrain = TerrainType.TRAP;
        } else { // 92% chance for regular terrain
          const regularTerrains = [TerrainType.WATER, TerrainType.MUD, TerrainType.SAND, TerrainType.WALL];
          randomTerrain = regularTerrains[Math.floor(Math.random() * regularTerrains.length)];
        }
        
        newGrid[y][x].terrain = randomTerrain;
        newGrid[y][x].cost = getTerrainCost(randomTerrain);
      }
    }
  }
  
  return newGrid;
};

export const canPlaceWall = (grid: Cell[][], positions: Position[], players: { human: Player; ai: Player }, treasure: Position): boolean => {
  // Check if all positions are valid and empty
  for (const pos of positions) {
    if (!isValidPosition(pos, grid.length)) return false;
    
    const cell = grid[pos.y][pos.x];
    if (cell.terrain !== TerrainType.EMPTY) return false;
    
    // Cannot place on players or treasure
    if ((pos.x === players.human.position.x && pos.y === players.human.position.y) ||
        (pos.x === players.ai.position.x && pos.y === players.ai.position.y) ||
        (pos.x === treasure.x && pos.y === treasure.y)) {
      return false;
    }
  }
  
  return true;
};

export const canPlaceLadder = (grid: Cell[][], position: Position, players: { human: Player; ai: Player }, treasure: Position): boolean => {
  if (!isValidPosition(position, grid.length)) return false;
  
  const cell = grid[position.y][position.x];
  if (cell.terrain !== TerrainType.EMPTY) return false;
  
  // Cannot place on players or treasure
  if ((position.x === players.human.position.x && position.y === players.human.position.y) ||
      (position.x === players.ai.position.x && position.y === players.ai.position.y) ||
      (position.x === treasure.x && position.y === treasure.y)) {
    return false;
  }
  
  return true;
};

export const checkWinCondition = (gameState: GameState): 'human' | 'ai' | 'draw' | null => {
  const humanAtTreasure = gameState.players.human.position.x === gameState.treasure.x && 
                          gameState.players.human.position.y === gameState.treasure.y;
  const aiAtTreasure = gameState.players.ai.position.x === gameState.treasure.x && 
                       gameState.players.ai.position.y === gameState.treasure.y;

  if (humanAtTreasure && aiAtTreasure) {
    return 'draw';
  } else if (humanAtTreasure) {
    return 'human';
  } else if (aiAtTreasure) {
    return 'ai';
  }
  
  return null;
};

const findEqualDistancePositions = (treasure: Position, size: number): { human: Position; ai: Position } => {
  const allPositions: Position[] = [];
  
  // Generate all valid positions
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      if (x !== treasure.x || y !== treasure.y) { // Don't include treasure position
        allPositions.push({ x, y });
      }
    }
  }
  
  // Group positions by Manhattan distance to treasure
  const distanceGroups = new Map<number, Position[]>();
  for (const pos of allPositions) {
    const distance = getManhattanDistance(pos, treasure);
    if (!distanceGroups.has(distance)) {
      distanceGroups.set(distance, []);
    }
    distanceGroups.get(distance)!.push(pos);
  }
  
  // Find the largest distance group with at least 2 positions
  const sortedDistances = Array.from(distanceGroups.keys()).sort((a, b) => b - a);
  
  for (const distance of sortedDistances) {
    const positions = distanceGroups.get(distance)!;
    if (positions.length >= 2) {
      // Select two positions that are reasonably far apart
      const selected = [];
      selected.push(positions[0]);
      
      // Find position farthest from first selection
      let maxDist = 0;
      let farthest = positions[1];
      for (let i = 1; i < positions.length; i++) {
        const dist = getManhattanDistance(positions[0], positions[i]);
        if (dist > maxDist) {
          maxDist = dist;
          farthest = positions[i];
        }
      }
      selected.push(farthest);
      
      return {
        human: selected[0],
        ai: selected[1]
      };
    }
  }
  
  // Fallback: use corners if no suitable positions found
  return {
    human: { x: 0, y: 0 },
    ai: { x: size - 1, y: size - 1 }
  };
};

export const initializeGame = (size: number = 10): GameState => {
  const grid = createEmptyGrid(size);
  const obstacleGrid = generateRandomObstacles(grid, 0.1);
  
  // Place treasure at center or strategic position
  const treasurePositions = [
    { x: Math.floor(size / 2), y: Math.floor(size / 2) }, // Center
    { x: Math.floor(size / 2) + 1, y: Math.floor(size / 2) }, // Near center
    { x: Math.floor(size / 2), y: Math.floor(size / 2) + 1 }, // Near center
    { x: Math.floor(size * 0.7), y: Math.floor(size * 0.3) }, // Off-center strategic
  ];
  const treasure = treasurePositions[Math.floor(Math.random() * treasurePositions.length)];
  obstacleGrid[treasure.y][treasure.x].terrain = TerrainType.TREASURE;
  
  // Find equal distance starting positions
  const startPositions = findEqualDistancePositions(treasure, size);
  
  // Ensure starting positions are clear of obstacles
  obstacleGrid[startPositions.human.y][startPositions.human.x].terrain = TerrainType.EMPTY;
  obstacleGrid[startPositions.ai.y][startPositions.ai.x].terrain = TerrainType.EMPTY;
  
  // Set player positions on grid
  obstacleGrid[startPositions.human.y][startPositions.human.x].playerId = 'human';
  obstacleGrid[startPositions.ai.y][startPositions.ai.x].playerId = 'ai';
  
  const gameState: GameState = {
    grid: obstacleGrid,
    size,
    players: {
      human: {
        id: 'human',
        position: startPositions.human,
        wallUsed: false,
        ladderUsed: false,
        movesThisTurn: 0,
        maxMovesPerTurn: 2,
        color: '#3b82f6',
        name: 'Human Player',
        stunned: 0,
        powerUps: {
          extraMovement: 0,
          ignoreWaterCost: 0,
          extraWalls: 0,
          extraLadders: 0
        }
      },
      ai: {
        id: 'ai',
        position: startPositions.ai,
        wallUsed: false,
        ladderUsed: false,
        movesThisTurn: 0,
        maxMovesPerTurn: 2,
        color: '#ef4444',
        name: 'AI Agent',
        stunned: 0,
        powerUps: {
          extraMovement: 0,
          ignoreWaterCost: 0,
          extraWalls: 0,
          extraLadders: 0
        }
      }
    },
    treasure,
    currentPlayer: 'human',
    gameStatus: 'playing',
    turnNumber: 1,
    gameHistory: [],
    aiThinking: false
  };
  
  console.log('Game initialized:', {
    humanPos: startPositions.human,
    aiPos: startPositions.ai,
    treasure: treasure,
    humanDistance: getManhattanDistance(startPositions.human, treasure),
    aiDistance: getManhattanDistance(startPositions.ai, treasure)
  });
  
  return gameState;
};