export interface Position {
  x: number;
  y: number;
}

export interface Player {
  id: 'human' | 'ai';
  position: Position;
  wallUsed: boolean;
  ladderUsed: boolean;
  movesThisTurn: number;
  maxMovesPerTurn: number;
  color: string;
  name: string;
  stunned: number;
  powerUps: {
    extraMovement: number;
    ignoreWaterCost: number;
    extraWalls: number;
    extraLadders: number;
  };
}

export enum TerrainType {
  EMPTY = 'empty',
  WALL = 'wall',
  WATER = 'water',
  MUD = 'mud',
  SAND = 'sand',
  TREASURE = 'treasure',
  PLAYER_WALL = 'player_wall',
  LADDER = 'ladder',
  TRAP = 'trap',
  POWER_UP = 'power_up'
}

export interface Cell {
  x: number;
  y: number;
  terrain: TerrainType;
  cost: number;
  playerId?: 'human' | 'ai';
  isHighlighted?: boolean;
  isPath?: boolean;
}

export enum ActionType {
  MOVE = 'move',
  PLACE_WALL = 'place_wall',
  PLACE_LADDER = 'place_ladder',
  END_TURN = 'end_turn'
}

export interface GameAction {
  type: ActionType;
  playerId: 'human' | 'ai';
  position?: Position;
  wallPositions?: Position[]; // For 2-tile wall placement
  direction?: 'horizontal' | 'vertical';
}

export interface GameState {
  grid: Cell[][];
  size: number;
  players: {
    human: Player;
    ai: Player;
  };
  treasure: Position;
  currentPlayer: 'human' | 'ai';
  gameStatus: 'setup' | 'playing' | 'ended';
  winner?: 'human' | 'ai' | 'draw';
  turnNumber: number;
  gameHistory: GameAction[];
  aiThinking: boolean;
}

export enum GameMode {
  WALL_PLACEMENT = 'wall_placement',
  LADDER_PLACEMENT = 'ladder_placement',
  MOVE = 'move'
}

export interface AIResult {
  action: GameAction;
  path?: Position[];
  reasoning: string;
  statesExplored: number;
  executionTime: number;
}

// Algorithm types for AI
export enum AIAlgorithm {
  UCS = 'UCS',
  ASTAR = 'A*',
  MINIMAX = 'Minimax'
}

export interface PathfindingResult {
  path: Position[];
  cost: number;
  statesExplored: number;
  found: boolean;
}