import { Position, GameState, AIResult, ActionType, GameAction, AIAlgorithm, PathfindingResult, TerrainType } from './types';
import { getManhattanDistance, getChebyshevDistance, getTerrainCost, canPlaceWall, canPlaceLadder } from './utils';

interface SearchNode {
  position: Position;
  gCost: number;
  hCost: number;
  fCost: number;
  parent: SearchNode | null;
}

export class AIAgent {
  private algorithm: AIAlgorithm;
  
  constructor(algorithm: AIAlgorithm = AIAlgorithm.ASTAR) {
    this.algorithm = algorithm;
  }

  async makeDecision(gameState: GameState): Promise<AIResult> {
    const startTime = Date.now();
    const aiPlayer = gameState.players.ai;
    
    // If we've used both moves, end turn
    if (aiPlayer.movesThisTurn >= aiPlayer.maxMovesPerTurn) {
      return {
        action: { type: ActionType.END_TURN, playerId: 'ai' },
        reasoning: 'Used maximum moves for this turn',
        statesExplored: 1,
        executionTime: Date.now() - startTime
      };
    }

    // Strategic decision making (only if we haven't moved yet this turn)
    if (aiPlayer.movesThisTurn === 0) {
      const strategicAction = this.evaluateStrategicOptions(gameState);
      if (strategicAction) {
        return {
          action: strategicAction,
          reasoning: this.getStrategicReasoning(strategicAction, gameState),
          statesExplored: 1,
          executionTime: Date.now() - startTime
        };
      }
    }

    // Pathfinding to treasure
    const pathResult = this.findPathToTreasure(gameState);
    
    if (pathResult.found && pathResult.path.length > 1) {
      const nextPosition = pathResult.path[1]; // Skip current position
      
      const action: GameAction = {
        type: ActionType.MOVE,
        playerId: 'ai',
        position: nextPosition
      };

      return {
        action,
        path: pathResult.path,
        reasoning: `Moving towards treasure using ${this.algorithm}. Distance remaining: ${pathResult.path.length - 1} steps. Moves used: ${aiPlayer.movesThisTurn + 1}/${aiPlayer.maxMovesPerTurn}`,
        statesExplored: pathResult.statesExplored,
        executionTime: Date.now() - startTime
      };
    }

    // Fallback: end turn
    return {
      action: { type: ActionType.END_TURN, playerId: 'ai' },
      reasoning: 'No valid moves available, ending turn',
      statesExplored: 1,
      executionTime: Date.now() - startTime
    };
  }

  private evaluateStrategicOptions(gameState: GameState): GameAction | null {
    const aiPlayer = gameState.players.ai;
    const humanPlayer = gameState.players.human;
    
    const aiDistanceToTreasure = getManhattanDistance(aiPlayer.position, gameState.treasure);
    const humanDistanceToTreasure = getManhattanDistance(humanPlayer.position, gameState.treasure);
    
    // If human is significantly closer and we haven't used wall, consider blocking
    if (!aiPlayer.wallUsed && humanDistanceToTreasure < aiDistanceToTreasure - 2) {
      const blockingWall = this.findBlockingWallPosition(gameState);
      if (blockingWall) {
        return {
          type: ActionType.PLACE_WALL,
          playerId: 'ai',
          wallPositions: blockingWall.positions,
          direction: blockingWall.direction
        };
      }
    }

    // Consider using ladder if it provides significant advantage
    if (!aiPlayer.ladderUsed && aiDistanceToTreasure > 3) {
      const ladderPosition = this.findOptimalLadderPosition(gameState);
      if (ladderPosition) {
        return {
          type: ActionType.PLACE_LADDER,
          playerId: 'ai',
          position: ladderPosition
        };
      }
    }

    return null;
  }

  private findBlockingWallPosition(gameState: GameState): { positions: Position[], direction: 'horizontal' | 'vertical' } | null {
    const humanPlayer = gameState.players.human;
    const treasure = gameState.treasure;
    
    // Try to block the most direct path from human to treasure
    const directions: { positions: Position[], direction: 'horizontal' | 'vertical' }[] = [];
    
    // Horizontal walls
    for (let x = 0; x < gameState.size - 1; x++) {
      for (let y = 0; y < gameState.size; y++) {
        const positions = [{ x, y }, { x: x + 1, y }];
        if (canPlaceWall(gameState.grid, positions, gameState.players, treasure)) {
          directions.push({ positions, direction: 'horizontal' });
        }
      }
    }
    
    // Vertical walls
    for (let x = 0; x < gameState.size; x++) {
      for (let y = 0; y < gameState.size - 1; y++) {
        const positions = [{ x, y }, { x, y: y + 1 }];
        if (canPlaceWall(gameState.grid, positions, gameState.players, treasure)) {
          directions.push({ positions, direction: 'vertical' });
        }
      }
    }
    
    // Find wall that maximizes human's path length
    let bestWall: { positions: Position[], direction: 'horizontal' | 'vertical' } | null = null;
    let bestImpact = 0;
    
    for (const wall of directions) {
      // Simulate placing wall and check impact on human's path
      const tempGrid = gameState.grid.map(row => row.map(cell => ({ ...cell })));
      wall.positions.forEach(pos => {
        tempGrid[pos.y][pos.x].terrain = gameState.grid[pos.y][pos.x].terrain;
        tempGrid[pos.y][pos.x].cost = Infinity;
      });
      
      const impact = this.calculatePathImpact(tempGrid, humanPlayer.position, treasure);
      if (impact > bestImpact) {
        bestImpact = impact;
        bestWall = wall;
      }
    }
    
    return bestWall;
  }

  private findOptimalLadderPosition(gameState: GameState): Position | null {
    const aiPlayer = gameState.players.ai;
    const treasure = gameState.treasure;
    
    // Find position that reduces our path length most effectively
    let bestPosition: Position | null = null;
    let bestImprovement = 0;
    
    for (let x = 0; x < gameState.size; x++) {
      for (let y = 0; y < gameState.size; y++) {
        const position = { x, y };
        if (canPlaceLadder(gameState.grid, position, gameState.players, treasure)) {
          const improvement = this.calculateLadderBenefit(gameState, position);
          if (improvement > bestImprovement) {
            bestImprovement = improvement;
            bestPosition = position;
          }
        }
      }
    }
    
    return bestPosition;
  }

  private calculatePathImpact(grid: any[][], start: Position, goal: Position): number {
    // Simple heuristic: return negative impact if path becomes impossible
    const pathResult = this.runUCS(grid, start, goal);
    return pathResult.found ? pathResult.cost : 100; // High impact if blocks path
  }

  private calculateLadderBenefit(gameState: GameState, ladderPos: Position): number {
    const aiPos = gameState.players.ai.position;
    const treasure = gameState.treasure;
    
    // Calculate if ladder reduces path length
    const currentDistance = getManhattanDistance(aiPos, treasure);
    const ladderDistance = getManhattanDistance(aiPos, ladderPos) + getManhattanDistance(ladderPos, treasure) * 0.5;
    
    return Math.max(0, currentDistance - ladderDistance);
  }

  private findPathToTreasure(gameState: GameState): PathfindingResult {
    const start = gameState.players.ai.position;
    const goal = gameState.treasure;
    
    switch (this.algorithm) {
      case AIAlgorithm.UCS:
        return this.runUCS(gameState.grid, start, goal);
      case AIAlgorithm.ASTAR:
        return this.runAStar(gameState.grid, start, goal);
      default:
        return this.runAStar(gameState.grid, start, goal);
    }
  }

  private runUCS(grid: any[][], start: Position, goal: Position): PathfindingResult {
    const openSet: SearchNode[] = [];
    const closedSet = new Set<string>();
    let statesExplored = 0;
    
    const startNode: SearchNode = {
      position: start,
      gCost: 0,
      hCost: 0,
      fCost: 0,
      parent: null
    };
    
    openSet.push(startNode);
    
    while (openSet.length > 0) {
      statesExplored++;
      
      // Sort by gCost for UCS
      openSet.sort((a, b) => a.gCost - b.gCost);
      const current = openSet.shift()!;
      
      const posKey = `${current.position.x},${current.position.y}`;
      if (closedSet.has(posKey)) continue;
      closedSet.add(posKey);
      
      if (current.position.x === goal.x && current.position.y === goal.y) {
        return {
          path: this.reconstructPath(current),
          cost: current.gCost,
          statesExplored,
          found: true
        };
      }
      
      const neighbors = getNeighbors(current.position, grid);
      for (const neighborPos of neighbors) {
        const neighborKey = `${neighborPos.x},${neighborPos.y}`;
        if (closedSet.has(neighborKey)) continue;
        
        const cell = grid[neighborPos.y][neighborPos.x];
        const tentativeGCost = current.gCost + getTerrainCost(cell.terrain);
        
        const existingNode = openSet.find(n => n.position.x === neighborPos.x && n.position.y === neighborPos.y);
        
        if (!existingNode || tentativeGCost < existingNode.gCost) {
          const neighborNode: SearchNode = {
            position: neighborPos,
            gCost: tentativeGCost,
            hCost: 0,
            fCost: tentativeGCost,
            parent: current
          };
          
          if (existingNode) {
            const index = openSet.indexOf(existingNode);
            openSet[index] = neighborNode;
          } else {
            openSet.push(neighborNode);
          }
        }
      }
    }
    
    return { path: [], cost: Infinity, statesExplored, found: false };
  }

  private runAStar(grid: any[][], start: Position, goal: Position): PathfindingResult {
    const openSet: SearchNode[] = [];
    const closedSet = new Set<string>();
    let statesExplored = 0;
    
    const startNode: SearchNode = {
      position: start,
      gCost: 0,
      hCost: getManhattanDistance(start, goal),
      fCost: getManhattanDistance(start, goal),
      parent: null
    };
    
    openSet.push(startNode);
    
    while (openSet.length > 0) {
      statesExplored++;
      
      // Sort by fCost for A*
      openSet.sort((a, b) => a.fCost - b.fCost);
      const current = openSet.shift()!;
      
      const posKey = `${current.position.x},${current.position.y}`;
      if (closedSet.has(posKey)) continue;
      closedSet.add(posKey);
      
      if (current.position.x === goal.x && current.position.y === goal.y) {
        return {
          path: this.reconstructPath(current),
          cost: current.gCost,
          statesExplored,
          found: true
        };
      }
      
      const neighbors = getNeighbors(current.position, grid);
      for (const neighborPos of neighbors) {
        const neighborKey = `${neighborPos.x},${neighborPos.y}`;
        if (closedSet.has(neighborKey)) continue;
        
        const cell = grid[neighborPos.y][neighborPos.x];
        const tentativeGCost = current.gCost + getTerrainCost(cell.terrain);
        
        const existingNode = openSet.find(n => n.position.x === neighborPos.x && n.position.y === neighborPos.y);
        
        if (!existingNode || tentativeGCost < existingNode.gCost) {
          const hCost = getManhattanDistance(neighborPos, goal);
          const neighborNode: SearchNode = {
            position: neighborPos,
            gCost: tentativeGCost,
            hCost,
            fCost: tentativeGCost + hCost,
            parent: current
          };
          
          if (existingNode) {
            const index = openSet.indexOf(existingNode);
            openSet[index] = neighborNode;
          } else {
            openSet.push(neighborNode);
          }
        }
      }
    }
    
    return { path: [], cost: Infinity, statesExplored, found: false };
  }

  private getTerrainMoveCost(terrain: TerrainType): number {
    const baseCost = getTerrainCost(terrain);
    if (baseCost === Infinity) return Infinity; // Walls are impassable
    if (baseCost === 0.5) return 1; // Ladders are beneficial but still cost 1 for pathfinding
    return baseCost; // Water=2, Mud=2, Sand=3, Empty=1
  }

  private getAIValidNeighbors(position: Position, grid: any[][]): Position[] {
    const neighbors: Position[] = [];
    const directions = [
      { x: 0, y: -1 }, // Up
      { x: 1, y: 0 },  // Right
      { x: 0, y: 1 },  // Down
      { x: -1, y: 0 }  // Left
    ];

    for (const dir of directions) {
      const newPos = { x: position.x + dir.x, y: position.y + dir.y };
      if (newPos.x >= 0 && newPos.x < grid.length && newPos.y >= 0 && newPos.y < grid[0].length) {
        const cell = grid[newPos.y][newPos.x];
        // AI cannot move through walls or cells occupied by human player
        if (cell.terrain !== TerrainType.WALL && 
            cell.terrain !== TerrainType.PLAYER_WALL &&
            cell.playerId !== 'human') {
          neighbors.push(newPos);
        }
      }
    }

    return neighbors;
  }

  private reconstructPath(node: SearchNode): Position[] {
    const path: Position[] = [];
    let current: SearchNode | null = node;
    
    while (current) {
      path.unshift(current.position);
      current = current.parent;
    }
    
    return path;
  }

  private getStrategicReasoning(action: GameAction, gameState: GameState): string {
    switch (action.type) {
      case ActionType.PLACE_WALL:
        return 'Placing wall to block opponent\'s path to treasure';
      case ActionType.PLACE_LADDER:
        return 'Placing ladder to gain movement advantage';
      default:
        return 'Strategic move';
    }
  }
}