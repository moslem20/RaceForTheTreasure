import React, { useEffect, useRef, useState } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  opacity: number;
  color: string;
  life: number;
  maxLife: number;
}

interface ParticleSystemProps {
  theme?: 'default' | 'jungle' | 'ice' | 'cyber' | 'volcano';
  intensity?: 'low' | 'medium' | 'high';
  gameActive?: boolean;
}

export const ParticleSystem: React.FC<ParticleSystemProps> = ({
  theme = 'default',
  intensity = 'medium',
  gameActive = true
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const particlesRef = useRef<Particle[]>([]);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  // Theme configurations
  const themeConfig = {
    default: {
      colors: ['#3b82f6', '#8b5cf6', '#06b6d4', '#10b981'],
      particleCount: { low: 30, medium: 50, high: 80 },
      speed: 0.5,
      size: { min: 1, max: 3 }
    },
    jungle: {
      colors: ['#22c55e', '#16a34a', '#65a30d', '#84cc16'],
      particleCount: { low: 40, medium: 60, high: 100 },
      speed: 0.3,
      size: { min: 1, max: 4 }
    },
    ice: {
      colors: ['#06b6d4', '#0891b2', '#0369a1', '#1e40af'],
      particleCount: { low: 35, medium: 55, high: 90 },
      speed: 0.2,
      size: { min: 1, max: 2 }
    },
    cyber: {
      colors: ['#8b5cf6', '#a855f7', '#ec4899', '#f59e0b'],
      particleCount: { low: 50, medium: 70, high: 120 },
      speed: 0.8,
      size: { min: 1, max: 3 }
    },
    volcano: {
      colors: ['#ef4444', '#f97316', '#eab308', '#dc2626'],
      particleCount: { low: 45, medium: 65, high: 110 },
      speed: 0.6,
      size: { min: 2, max: 5 }
    }
  };

  const config = themeConfig[theme];

  // Update canvas dimensions
  useEffect(() => {
    const updateDimensions = () => {
      setDimensions({
        width: window.innerWidth,
        height: window.innerHeight
      });
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, []);

  // Create particle
  const createParticle = (): Particle => {
    const maxLife = 200 + Math.random() * 300;
    return {
      x: Math.random() * dimensions.width,
      y: Math.random() * dimensions.height,
      vx: (Math.random() - 0.5) * config.speed,
      vy: (Math.random() - 0.5) * config.speed,
      size: config.size.min + Math.random() * (config.size.max - config.size.min),
      opacity: 0.1 + Math.random() * 0.3,
      color: config.colors[Math.floor(Math.random() * config.colors.length)],
      life: 0,
      maxLife
    };
  };

  // Initialize particles
  useEffect(() => {
    if (dimensions.width && dimensions.height) {
      const particleCount = config.particleCount[intensity];
      particlesRef.current = Array.from({ length: particleCount }, createParticle);
    }
  }, [dimensions, theme, intensity]);

  // Animation loop
  useEffect(() => {
    if (!gameActive) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const animate = () => {
      ctx.clearRect(0, 0, dimensions.width, dimensions.height);

      particlesRef.current.forEach((particle, index) => {
        // Update particle position
        particle.x += particle.vx;
        particle.y += particle.vy;
        particle.life++;

        // Boundary wrap
        if (particle.x < 0) particle.x = dimensions.width;
        if (particle.x > dimensions.width) particle.x = 0;
        if (particle.y < 0) particle.y = dimensions.height;
        if (particle.y > dimensions.height) particle.y = 0;

        // Calculate opacity based on life
        const lifeRatio = particle.life / particle.maxLife;
        const currentOpacity = particle.opacity * (1 - lifeRatio);

        // Draw particle
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fillStyle = `${particle.color}${Math.floor(currentOpacity * 255).toString(16).padStart(2, '0')}`;
        ctx.fill();

        // Add glow effect for cyber theme
        if (theme === 'cyber') {
          ctx.shadowBlur = 10;
          ctx.shadowColor = particle.color;
          ctx.fill();
          ctx.shadowBlur = 0;
        }

        // Reset particle when life ends
        if (particle.life >= particle.maxLife) {
          particlesRef.current[index] = createParticle();
        }
      });

      // Draw connections for cyber theme
      if (theme === 'cyber') {
        drawConnections(ctx);
      }

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [dimensions, theme, intensity, gameActive]);

  // Draw connections between nearby particles (cyber theme)
  const drawConnections = (ctx: CanvasRenderingContext2D) => {
    const maxDistance = 100;
    
    for (let i = 0; i < particlesRef.current.length; i++) {
      for (let j = i + 1; j < particlesRef.current.length; j++) {
        const p1 = particlesRef.current[i];
        const p2 = particlesRef.current[j];
        
        const dx = p1.x - p2.x;
        const dy = p1.y - p2.y;
        const distance = Math.sqrt(dx * dx + dy * dy);
        
        if (distance < maxDistance) {
          const opacity = (1 - distance / maxDistance) * 0.1;
          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.strokeStyle = `rgba(139, 92, 246, ${opacity})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }
  };

  return (
    <canvas
      ref={canvasRef}
      width={dimensions.width}
      height={dimensions.height}
      className="fixed inset-0 pointer-events-none z-0"
      style={{ 
        background: 'transparent',
        mixBlendMode: theme === 'cyber' ? 'screen' : 'normal'
      }}
    />
  );
};