import React from 'react';
import { Palette, Leaf, Snowflake, Zap, Flame } from 'lucide-react';
import { Button } from '../ui/button';

interface ThemeSelectorProps {
  currentTheme: 'default' | 'jungle' | 'ice' | 'cyber' | 'volcano';
  onThemeChange: (theme: 'default' | 'jungle' | 'ice' | 'cyber' | 'volcano') => void;
  disabled?: boolean;
}

export const ThemeSelector: React.FC<ThemeSelectorProps> = ({
  currentTheme,
  onThemeChange,
  disabled = false
}) => {
  const themes = [
    {
      id: 'default' as const,
      name: 'Default',
      description: 'Classic blue particles',
      icon: Palette,
      gradient: 'from-blue-500 to-purple-500',
      bgColor: 'bg-blue-50 border-blue-200'
    },
    {
      id: 'jungle' as const,
      name: 'Jungle',
      description: 'Green nature particles',
      icon: Leaf,
      gradient: 'from-green-500 to-emerald-500',
      bgColor: 'bg-green-50 border-green-200'
    },
    {
      id: 'ice' as const,
      name: 'Ice',
      description: 'Cool blue crystalline',
      icon: Snowflake,
      gradient: 'from-cyan-500 to-blue-500',
      bgColor: 'bg-cyan-50 border-cyan-200'
    },
    {
      id: 'cyber' as const,
      name: 'Cyber',
      description: 'Neon connected particles',
      icon: Zap,
      gradient: 'from-purple-500 to-pink-500',
      bgColor: 'bg-purple-50 border-purple-200'
    },
    {
      id: 'volcano' as const,
      name: 'Volcano',
      description: 'Fiery red and orange',
      icon: Flame,
      gradient: 'from-red-500 to-orange-500',
      bgColor: 'bg-red-50 border-red-200'
    }
  ];

  return (
    <div className="p-4 bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl shadow-lg border-2 border-slate-200">
      <h3 className="text-lg font-bold text-slate-700 mb-4 flex items-center gap-2">
        <Palette className="w-5 h-5 text-slate-600" />
        Theme & Effects
      </h3>
      
      <div className="grid grid-cols-5 gap-2">
        {themes.map((theme) => {
          const Icon = theme.icon;
          const isSelected = currentTheme === theme.id;
          
          return (
            <Button
              key={theme.id}
              onClick={() => onThemeChange(theme.id)}
              disabled={disabled}
              variant="ghost"
              className={`h-auto p-3 rounded-lg border-2 transition-all duration-300 transform hover:scale-105 ${
                isSelected 
                  ? `bg-gradient-to-br ${theme.gradient} text-white border-opacity-50 shadow-lg`
                  : `${theme.bgColor} hover:shadow-md`
              }`}
            >
              <div className="flex flex-col items-center gap-1">
                <Icon className={`w-4 h-4 ${isSelected ? 'text-white' : 'text-slate-600'}`} />
                <span className={`text-xs font-medium ${isSelected ? 'text-white' : 'text-slate-700'}`}>
                  {theme.name}
                </span>
              </div>
            </Button>
          );
        })}
      </div>
      
      <div className="mt-3 text-xs text-slate-600 text-center">
        {themes.find(t => t.id === currentTheme)?.description}
      </div>
    </div>
  );
};