import React from 'react';
import { TrendingUp, Zap, Target, Shield, MapPin, Clock, Award } from 'lucide-react';
import { GameState } from '../../types/game';

interface LiveStatsPanelProps {
  gameState: GameState;
  currentPlayer: 'human' | 'ai';
}

export const LiveStatsPanel: React.FC<LiveStatsPanelProps> = ({
  gameState,
  currentPlayer
}) => {
  const humanStats = gameState.playerResources.human;
  const aiStats = gameState.playerResources.ai;
  const stats = gameState.gameStats;

  return (
    <div className="h-full p-2 bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50 rounded-lg shadow border border-purple-200 overflow-hidden">
      <h3 className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-blue-600 mb-2 flex items-center gap-1">
        <TrendingUp className="w-4 h-4 text-purple-500" />
        Live Stats
      </h3>
      
      <div className="grid grid-cols-2 gap-1 mb-2 overflow-y-auto flex-1">
        {/* Human Player Stats */}
        <div className="bg-gradient-to-br from-blue-100 via-blue-50 to-indigo-50 p-2 rounded-lg border border-blue-300">
          <h4 className="font-bold text-blue-800 mb-1 flex items-center gap-1 text-xs">
            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            Human
          </h4>
          <div className="space-y-1 text-xs">
            <div className="flex justify-between items-center bg-blue-200 p-1 rounded">
              <span className="text-blue-700">Steps:</span>
              <span className="font-bold text-blue-900 bg-blue-300 px-1 rounded">{stats.stepsHuman}</span>
            </div>
            <div className="flex justify-between items-center bg-blue-200 p-1 rounded">
              <span className="text-blue-700">Energy:</span>
              <div className="flex items-center gap-1">
                <span className="font-bold text-blue-900 text-xs">{humanStats.energy}/{humanStats.maxEnergy}</span>
                <div className="w-8 h-1 bg-blue-300 rounded overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-blue-500 to-cyan-400 transition-all duration-500"
                    style={{ width: `${(humanStats.energy / humanStats.maxEnergy) * 100}%` }}
                  />
                </div>
              </div>
            </div>
            <div className="flex justify-between items-center bg-blue-200 p-1 rounded">
              <span className="text-blue-700">Treasures:</span>
              <span className="font-bold text-blue-900 bg-amber-300 px-1 rounded">{humanStats.treasuresCollected}/2</span>
            </div>
            <div className="flex justify-between items-center bg-blue-200 p-1 rounded">
              <span className="text-blue-700">Keys:</span>
              <span className="font-bold text-blue-900 bg-green-300 px-1 rounded">{humanStats.keysCollected}</span>
            </div>
          </div>
        </div>

        {/* AI Player Stats */}
        <div className="bg-gradient-to-br from-red-100 via-red-50 to-orange-50 p-2 rounded-lg border border-red-300">
          <h4 className="font-bold text-red-800 mb-1 flex items-center gap-1 text-xs">
            <div className="w-2 h-2 bg-red-500 rounded-full"></div>
            AI
          </h4>
          <div className="space-y-1 text-xs">
            <div className="flex justify-between items-center bg-red-200 p-1 rounded">
              <span className="text-red-700">Steps:</span>
              <span className="font-bold text-red-900 bg-red-300 px-1 rounded">{stats.stepsAI}</span>
            </div>
            <div className="flex justify-between items-center bg-red-200 p-1 rounded">
              <span className="text-red-700">Energy:</span>
              <div className="flex items-center gap-1">
                <span className="font-bold text-red-900 text-xs">{aiStats.energy}/{aiStats.maxEnergy}</span>
                <div className="w-8 h-1 bg-red-300 rounded overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-red-500 to-orange-400 transition-all duration-500"
                    style={{ width: `${(aiStats.energy / aiStats.maxEnergy) * 100}%` }}
                  />
                </div>
              </div>
            </div>
            <div className="flex justify-between items-center bg-red-200 p-1 rounded">
              <span className="text-red-700">Treasures:</span>
              <span className="font-bold text-red-900 bg-amber-300 px-1 rounded">{aiStats.treasuresCollected}/2</span>
            </div>
            <div className="flex justify-between items-center bg-red-200 p-1 rounded">
              <span className="text-red-700">Keys:</span>
              <span className="font-bold text-red-900 bg-green-300 px-1 rounded">{aiStats.keysCollected}</span>
            </div>
          </div>
        </div>
      </div>

      {/* General Game Stats */}
      <div className="bg-slate-50 p-1 rounded text-xs">
        <div className="grid grid-cols-2 gap-1">
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3 text-slate-600" />
            <span>Turn: {stats.turnCount}</span>
          </div>
          <div className="flex items-center gap-1">
            <MapPin className="w-3 h-3 text-slate-600" />
            <span>Explored: {stats.tilesExplored}</span>
          </div>
          <div className="flex items-center gap-1">
            <Shield className="w-3 h-3 text-slate-600" />
            <span>Tools: {stats.toolsUsed}</span>
          </div>
          <div className="flex items-center gap-1">
            <Target className="w-3 h-3 text-slate-600" />
            <span>Difficulty: {gameState.difficulty}</span>
          </div>
        </div>
      </div>


    </div>
  );
};