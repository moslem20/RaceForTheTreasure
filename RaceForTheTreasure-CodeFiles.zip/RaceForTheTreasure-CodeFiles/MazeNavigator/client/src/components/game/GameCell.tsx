import React from 'react';
import { Crown, User, Bot, Hash, Layers, Zap, Bomb } from 'lucide-react';
import { GameState } from '../../types/game';
import { cn } from '../../lib/utils';

interface GameCellProps {
  row: number;
  col: number;
  gameState: GameState;
  onClick: (row: number, col: number) => void;
  isValidMove: boolean;
  isValidPlacement: boolean;
  showValidMoves: boolean;
  currentAction: 'move' | 'place-wall' | 'place-ladder';
}

export const GameCell: React.FC<GameCellProps> = ({
  row,
  col,
  gameState,
  onClick,
  isValidMove,
  isValidPlacement,
  showValidMoves,
  currentAction
}) => {
  const { players, treasures, walls, ladders, highCostTiles, trapTiles, powerUps, keys, gates, guards } = gameState;
  
  const isHumanPlayer = players.human.row === row && players.human.col === col;
  const isAiPlayer = players.ai.row === row && players.ai.col === col;
  const isTreasure = treasures.some(treasure => treasure.row === row && treasure.col === col);
  const isKey = keys.some(key => key.row === row && key.col === col);
  const isGate = gates.some(gate => gate.row === row && gate.col === col);
  const isGuard = guards.some(guard => guard.position.row === row && guard.position.col === col);
  const isWall = walls.some(wall => wall.row === row && wall.col === col);
  const isLadder = ladders.some(ladder => ladder.row === row && ladder.col === col);
  const isHighCost = highCostTiles.some(tile => tile.row === row && tile.col === col);
  const isTrap = trapTiles.some(trap => trap.row === row && trap.col === col);
  const isPowerUp = powerUps.some(powerUp => powerUp.row === row && powerUp.col === col);
  
  const handleClick = () => {
    onClick(row, col);
  };

  const getValidActionIndicator = () => {
    if (!showValidMoves) return null;
    
    if (currentAction === 'move' && isValidMove && !isHumanPlayer && !isAiPlayer && !isTreasure && !isWall) {
      return (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-3 h-3 bg-blue-400 rounded-full opacity-60" />
        </div>
      );
    }
    
    if ((currentAction === 'place-wall' || currentAction === 'place-ladder') && isValidPlacement) {
      const color = currentAction === 'place-wall' ? 'bg-slate-400' : 'bg-purple-400';
      return (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className={`w-4 h-4 ${color} rounded opacity-60 border-2 border-white`} />
        </div>
      );
    }
    
    return null;
  };

  return (
    <div
      className={cn(
        "game-cell w-16 h-16 border border-slate-300 flex items-center justify-center cursor-pointer transition-all duration-200 relative",
        "hover:border-slate-400 hover:shadow-sm",
        {
          // Base cell styling
          "bg-emerald-50": !isHumanPlayer && !isAiPlayer && !isTreasure && !isWall && !isLadder && !isHighCost && !isTrap && !isPowerUp && !isKey && !isGate && !isGuard,
          
          // Valid move highlighting
          "bg-blue-100 border-blue-300 hover:bg-blue-200": isValidMove && showValidMoves && currentAction === 'move' && !isWall,
          
          // Valid placement highlighting
          "bg-slate-100 border-slate-400 hover:bg-slate-200": isValidPlacement && showValidMoves && currentAction === 'place-wall',
          "bg-purple-100 border-purple-400 hover:bg-purple-200": isValidPlacement && showValidMoves && currentAction === 'place-ladder',
          
          // Treasure cell
          "bg-gradient-to-br from-amber-200 to-amber-300 border-amber-400": isTreasure,
          
          // Player cells
          "bg-gradient-to-br from-blue-400 to-blue-500 border-blue-600 text-white": isHumanPlayer,
          "bg-gradient-to-br from-red-400 to-red-500 border-red-600 text-white": isAiPlayer,
          
          // Wall cells
          "bg-gradient-to-br from-slate-600 to-slate-700 border-slate-800 text-white": isWall,
          
          // Ladder cells
          "bg-gradient-to-br from-purple-300 to-purple-400 border-purple-500": isLadder,
          
          // High cost tiles (water/mud)
          "bg-gradient-to-br from-cyan-300 to-cyan-400 border-cyan-500": isHighCost,
          
          // Trap tiles
          "bg-gradient-to-br from-red-200 to-red-300 border-red-400": isTrap,
          
          // Power-up tiles
          "bg-gradient-to-br from-yellow-200 to-yellow-300 border-yellow-400": isPowerUp,
          
          // Key tiles
          "bg-gradient-to-br from-green-200 to-green-300 border-green-400": isKey,
          
          // Gate tiles
          "bg-gradient-to-br from-orange-300 to-orange-400 border-orange-500": isGate,
          
          // Guard tiles
          "bg-gradient-to-br from-purple-500 to-purple-600 border-purple-700 text-white": isGuard,
        }
      )}
      onClick={handleClick}
    >
      {isTreasure && <Crown className="w-8 h-8 text-amber-700" />}
      {isHumanPlayer && <User className="w-7 h-7" />}
      {isAiPlayer && <Bot className="w-7 h-7" />}
      {isWall && <Hash className="w-7 h-7" />}
      {isLadder && (
        <div className="relative">
          <Layers className="w-7 h-7 text-purple-700" />
          <div className="absolute -top-1 -right-1 bg-green-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center font-bold">
            0
          </div>
        </div>
      )}
      {isHighCost && !isHumanPlayer && !isAiPlayer && !isTreasure && (
        <div className="text-xs font-bold text-cyan-700">~</div>
      )}
      {isTrap && !isHumanPlayer && !isAiPlayer && !isTreasure && (
        <Bomb className="w-6 h-6 text-red-700" />
      )}
      {isPowerUp && !isHumanPlayer && !isAiPlayer && !isTreasure && (
        <Zap className="w-6 h-6 text-yellow-700" />
      )}
      {isKey && !isHumanPlayer && !isAiPlayer && !isTreasure && (
        <div className="text-3xl">🗝️</div>
      )}
      {isGate && !isHumanPlayer && !isAiPlayer && !isTreasure && (
        <div className="text-3xl">🚪</div>
      )}
      {isGuard && !isHumanPlayer && !isAiPlayer && !isTreasure && (
        <div className="text-3xl">🛡️</div>
      )}
      
      {getValidActionIndicator()}
    </div>
  );
};