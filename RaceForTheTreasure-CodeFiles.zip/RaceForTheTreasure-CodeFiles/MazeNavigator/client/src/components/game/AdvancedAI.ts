import { GameState, Position, ActionType, PowerUpType } from '../../types/game';
import { 
  BlindSearchAlgorithms, 
  CostBasedSearchAlgorithms, 
  StrategicDecisionMaking, 
  PerformanceComparison,
  SearchResult 
} from '../../lib/AISearchAlgorithms';

export interface AIDecision {
  action: ActionType | 'collect_key' | 'use_powerup';
  position: Position;
  confidence: number;
  reasoning: string;
  alternativeActions?: AIDecision[];
}

export interface AIPersonality {
  name: 'rusher' | 'blocker' | 'collector' | 'strategist';
  riskTolerance: number; // 0-1
  blockingPropensity: number; // 0-1
  treasurePriority: number; // How much AI prioritizes reaching treasure vs other actions
  powerUpPriority: number; // How much AI values collecting power-ups
  memoryRetention: number; // How well AI remembers past failures and successes
  adaptationRate: number; // How quickly AI learns from human behavior
  planningDepth: number; // How many turns ahead AI plans
  routePrediction: number; // How well AI predicts human routes
  searchAlgorithm: 'BFS' | 'DFS' | 'UCS' | 'A*' | 'auto'; // Preferred search algorithm
  heuristicType: 'manhattan' | 'euclidean' | 'strategic'; // Heuristic for A*
}

export interface AIMemory {
  failedPositions: Set<string>; // Positions where AI was blocked or trapped
  successfulRoutes: Array<{ route: Position[], success: boolean, turns: number }>;
  humanPatterns: Map<string, number>; // Track human movement patterns
  powerUpEffectiveness: Map<PowerUpType, number>; // How effective each power-up was
  blockingSuccess: Map<string, boolean>; // Which blocking positions worked
  wallPlacementHistory: Array<{ position: Position, turn: number, impact: number, success: boolean }>; // Wall placement analytics
  humanCounterStrategies: Map<string, number>; // How human responds to different wall placements
}

export class AdvancedAI {
  private personality: AIPersonality;
  private gameHistory: GameState[] = [];
  private memory: AIMemory;
  private turnCount: number = 0;
  private lastHumanPosition: Position | null = null;

  constructor(personalityName: 'rusher' | 'blocker' | 'collector' | 'strategist' = 'rusher') {
    this.personality = this.createPersonality(personalityName);
    this.memory = {
      failedPositions: new Set(),
      successfulRoutes: [],
      humanPatterns: new Map(),
      powerUpEffectiveness: new Map(),
      blockingSuccess: new Map(),
      wallPlacementHistory: [],
      humanCounterStrategies: new Map()
    };
  }

  private createPersonality(name: 'rusher' | 'blocker' | 'collector' | 'strategist'): AIPersonality {
    switch (name) {
      case 'rusher':
        // The Rusher: Extremely aggressive, goes directly to treasure with enhanced memory
        return {
          name: 'rusher',
          riskTolerance: 0.95, // Extremely aggressive
          blockingPropensity: 0.2, // Some blocking when opportunity arises
          treasurePriority: 1.0, // Maximum treasure focus
          powerUpPriority: 0.3, // Will grab nearby power-ups
          memoryRetention: 0.8, // Enhanced memory to avoid past failures
          adaptationRate: 0.6, // Good adaptation to human patterns
          planningDepth: 3, // Plans 3 moves ahead
          routePrediction: 0.5, // Moderate route prediction
          searchAlgorithm: 'A*', // Fast A* for rushing
          heuristicType: 'manhattan' // Simple Manhattan distance
        };
        
      case 'blocker':
        // The Blocker: Master of disruption and path blocking
        return {
          name: 'blocker',
          riskTolerance: 0.2, // Very conservative
          blockingPropensity: 0.95, // Maximum blocking tendency
          treasurePriority: 0.4, // Lower treasure priority, focuses on blocking
          powerUpPriority: 0.5, // Moderate power-up interest for strategic advantage
          memoryRetention: 0.9, // Excellent memory for blocking patterns
          adaptationRate: 0.8, // High adaptation to counter human strategies
          planningDepth: 4, // Deep planning for blocking strategies
          routePrediction: 0.9, // Excellent route prediction for blocking
          searchAlgorithm: 'UCS', // Uniform Cost Search for optimal blocking
          heuristicType: 'strategic' // Strategic heuristic for blocking
        };
        
      case 'collector':
        // The Collector: Resource-focused with strategic patience
        return {
          name: 'collector',
          riskTolerance: 0.5, // Balanced risk for strategic collection
          blockingPropensity: 0.4, // Moderate blocking when strategic
          treasurePriority: 0.6, // Balanced treasure priority
          powerUpPriority: 1.0, // Maximum power-up priority
          memoryRetention: 0.85, // Excellent memory for resource locations
          adaptationRate: 0.7, // High adaptation rate for efficient collection
          planningDepth: 5, // Deep planning for resource optimization
          routePrediction: 0.7, // Good route prediction for efficient collection
          searchAlgorithm: 'BFS', // BFS for thorough exploration
          heuristicType: 'euclidean' // Euclidean distance for collection
        };
        
      case 'strategist':
        // The Strategist: Master AI with maximum intelligence and prediction
        return {
          name: 'strategist',
          riskTolerance: 0.7, // Calculated risks with high confidence
          blockingPropensity: 0.8, // High blocking tendency when strategic
          treasurePriority: 0.8, // High treasure priority
          powerUpPriority: 0.8, // High power-up priority
          memoryRetention: 0.95, // Near-perfect memory
          adaptationRate: 0.9, // Maximum adaptation rate
          planningDepth: 6, // Maximum planning depth (6 moves ahead)
          routePrediction: 0.98, // Near-perfect route prediction
          searchAlgorithm: 'auto', // Auto-selects best algorithm
          heuristicType: 'strategic' // Strategic heuristic for optimal play
        };
    }
  }

  /**
   * AI Memory: Record failed positions and blocked attempts
   */
  public recordFailure(position: Position, reason: string): void {
    const posKey = `${position.row},${position.col}`;
    this.memory.failedPositions.add(posKey);
    
    // Reduce effectiveness of similar strategies
    if (this.personality.memoryRetention > 0.5) {
      console.log(`AI ${this.personality.name} remembers failure at ${posKey}: ${reason}`);
    }
  }

  /**
   * AI Memory: Record successful routes for future reference
   */
  public recordSuccess(route: Position[], turns: number): void {
    this.memory.successfulRoutes.push({ route, success: true, turns });
    
    // Keep only the most recent successful routes
    if (this.memory.successfulRoutes.length > 10) {
      this.memory.successfulRoutes.shift();
    }
  }

  /**
   * AI Memory: Check if a position has previously failed
   */
  private isKnownFailurePosition(position: Position): boolean {
    const posKey = `${position.row},${position.col}`;
    return this.memory.failedPositions.has(posKey);
  }

  /**
   * AI Memory: Track human movement patterns
   */
  private updateHumanPatterns(gameState: GameState): void {
    const humanPos = gameState.players.human;
    
    if (this.lastHumanPosition) {
      const pattern = `${this.lastHumanPosition.row},${this.lastHumanPosition.col}->${humanPos.row},${humanPos.col}`;
      const count = this.memory.humanPatterns.get(pattern) || 0;
      this.memory.humanPatterns.set(pattern, count + 1);
    }
    
    this.lastHumanPosition = { ...humanPos };
  }

  /**
   * AI Memory: Predict human next move based on patterns
   */
  private predictHumanMove(gameState: GameState): Position[] {
    const humanPos = gameState.players.human;
    const predictions: Position[] = [];
    
    // Look for patterns starting from current position
    for (const [pattern, frequency] of this.memory.humanPatterns.entries()) {
      const [start, end] = pattern.split('->');
      const [startRow, startCol] = start.split(',').map(Number);
      
      if (startRow === humanPos.row && startCol === humanPos.col) {
        const [endRow, endCol] = end.split(',').map(Number);
        predictions.push({ row: endRow, col: endCol });
      }
    }
    
    return predictions;
  }

  /**
   * The Rusher: Extremely aggressive with A* pathfinding for optimal speed
   */
  private makeRusherDecision(gameState: GameState, aiPos: Position, treasures: Position[]): AIDecision {
    // Use A* to find optimal path to each treasure
    let bestTreasure = treasures[0];
    let shortestPath: Position[] = [];
    let shortestDistance = Infinity;
    
    for (const treasure of treasures) {
      const pathToTreasure = this.findOptimalPath(aiPos, treasure, gameState);
      if (pathToTreasure.length > 0 && pathToTreasure.length < shortestDistance) {
        shortestDistance = pathToTreasure.length;
        bestTreasure = treasure;
        shortestPath = pathToTreasure;
      }
    }
    
    // If we have an optimal path, take the first step
    if (shortestPath.length > 0) {
      return {
        action: 'move',
        position: shortestPath[0],
        confidence: 0.95,
        reasoning: `A* rush: optimal ${shortestPath.length}-move path to treasure at (${bestTreasure.row}, ${bestTreasure.col})`
      };
    }
    
    // Fallback to direct movement if A* fails
    const nearestTreasure = treasures[0];
    const directions = [
      { row: aiPos.row + (nearestTreasure.row > aiPos.row ? 1 : nearestTreasure.row < aiPos.row ? -1 : 0), col: aiPos.col },
      { row: aiPos.row, col: aiPos.col + (nearestTreasure.col > aiPos.col ? 1 : nearestTreasure.col < aiPos.col ? -1 : 0) }
    ].filter(pos => !this.isKnownFailurePosition(pos));
    
    const targetPos = directions[0] || { row: Math.max(0, Math.min(9, aiPos.row + 1)), col: aiPos.col };
    
    return {
      action: 'move',
      position: targetPos,
      confidence: 0.8,
      reasoning: `Fallback rush to treasure at (${nearestTreasure.row}, ${nearestTreasure.col})`
    };
  }

  /**
   * The Blocker: Master of disruption with advanced path analysis and wall strategy
   */
  private makeBlockerDecision(gameState: GameState, aiPos: Position, humanPos: Position, treasures: Position[]): AIDecision {
    // Note: Wall placement is now handled in main decision flow with highest priority
    // This method focuses on movement when walls aren't the best option
    
    // Use A* to find human's optimal path to each treasure
    let humanTarget = treasures[0];
    let shortestPathLength = Infinity;
    
    for (const treasure of treasures) {
      const pathToTreasure = this.findOptimalPath(humanPos, treasure, gameState);
      if (pathToTreasure.length > 0 && pathToTreasure.length < shortestPathLength) {
        shortestPathLength = pathToTreasure.length;
        humanTarget = treasure;
      }
    }
    
    // Since wall placement is handled separately, focus on positioning for future blocks
    const humanOptimalPath = this.findOptimalPath(humanPos, humanTarget, gameState);
    
    if (humanOptimalPath.length > 2) {
      // Position AI to create future blocking opportunities
      const anticipatedBlockPos = humanOptimalPath[Math.min(2, humanOptimalPath.length - 1)];
      const stagingPositions = [
        { row: anticipatedBlockPos.row - 1, col: anticipatedBlockPos.col },
        { row: anticipatedBlockPos.row + 1, col: anticipatedBlockPos.col },
        { row: anticipatedBlockPos.row, col: anticipatedBlockPos.col - 1 },
        { row: anticipatedBlockPos.row, col: anticipatedBlockPos.col + 1 }
      ].filter(pos => this.isValidPosition(pos, gameState));
      
      // Find best staging position using A*
      let bestStagingPos = null;
      let shortestStagingPath = Infinity;
      
      for (const stagingPos of stagingPositions) {
        const pathToStaging = this.findOptimalPath(aiPos, stagingPos, gameState);
        if (pathToStaging.length > 0 && pathToStaging.length < shortestStagingPath) {
          shortestStagingPath = pathToStaging.length;
          bestStagingPos = stagingPos;
        }
      }
      
      if (bestStagingPos) {
        const pathToStaging = this.findOptimalPath(aiPos, bestStagingPos, gameState);
        if (pathToStaging.length > 0) {
          return {
            action: 'move',
            position: pathToStaging[0],
            confidence: 0.85,
            reasoning: `Positioning for future block: staging near human path at (${bestStagingPos.row}, ${bestStagingPos.col})`
          };
        }
      }
    }
    
    // Fallback to direct interception using A*
    const interceptPath = this.findOptimalPath(aiPos, humanTarget, gameState, true); // Avoid human
    if (interceptPath.length > 0) {
      return {
        action: 'move',
        position: interceptPath[0],
        confidence: 0.8,
        reasoning: `A* interception: racing to treasure while avoiding human`
      };
    }
    
    // Final fallback to direct movement
    const interceptPos = {
      row: Math.max(0, Math.min(9, humanPos.row + (humanTarget.row > humanPos.row ? 1 : -1))),
      col: Math.max(0, Math.min(9, humanPos.col + (humanTarget.col > humanPos.col ? 1 : -1)))
    };
    
    return {
      action: 'move',
      position: interceptPos,
      confidence: 0.6,
      reasoning: 'Fallback direct interception'
    };
  }

  /**
   * The Collector: Strategic resource gathering with A* optimization
   */
  private makeCollectorDecision(gameState: GameState, aiPos: Position): AIDecision {
    // Use A* to find optimal path to power-ups
    if (gameState.powerUps.length > 0) {
      let bestPowerUp = gameState.powerUps[0];
      let shortestPath: Position[] = [];
      let shortestDistance = Infinity;
      
      for (const powerUp of gameState.powerUps) {
        const pathToPowerUp = this.findOptimalPath(aiPos, powerUp, gameState);
        if (pathToPowerUp.length > 0 && pathToPowerUp.length < shortestDistance) {
          shortestDistance = pathToPowerUp.length;
          bestPowerUp = powerUp;
          shortestPath = pathToPowerUp;
        }
      }
      
      // If we have an optimal path to power-up, take the first step
      if (shortestPath.length > 0) {
        return {
          action: 'move',
          position: shortestPath[0],
          confidence: 0.9,
          reasoning: `A* collection: optimal ${shortestPath.length}-move path to power-up at (${bestPowerUp.row}, ${bestPowerUp.col})`
        };
      }
    }
    
    // If no power-ups or can't reach them, use A* to find treasure with strategic positioning
    if (gameState.treasures.length > 0) {
      let bestTreasure = gameState.treasures[0];
      let shortestPath: Position[] = [];
      let shortestDistance = Infinity;
      
      for (const treasure of gameState.treasures) {
        const pathToTreasure = this.findOptimalPath(aiPos, treasure, gameState);
        if (pathToTreasure.length > 0 && pathToTreasure.length < shortestDistance) {
          shortestDistance = pathToTreasure.length;
          bestTreasure = treasure;
          shortestPath = pathToTreasure;
        }
      }
      
      if (shortestPath.length > 0) {
        return {
          action: 'move',
          position: shortestPath[0],
          confidence: 0.8,
          reasoning: `A* treasure path: ${shortestPath.length} moves to treasure at (${bestTreasure.row}, ${bestTreasure.col})`
        };
      }
    }
    
    // Fallback to simple movement
    const treasure = gameState.treasures[0] || { row: 5, col: 5 };
    const targetPos = {
      row: Math.max(0, Math.min(9, aiPos.row + (treasure.row > aiPos.row ? 1 : treasure.row < aiPos.row ? -1 : 0))),
      col: Math.max(0, Math.min(9, aiPos.col + (treasure.col > aiPos.col ? 1 : treasure.col < aiPos.col ? -1 : 0)))
    };
    
    return {
      action: 'move',
      position: targetPos,
      confidence: 0.5,
      reasoning: 'Fallback movement toward treasure'
    };
  }

  /**
   * The Strategist: Advanced AI with prediction and strategic counter-moves
   */
  private makeStrategistDecision(gameState: GameState, aiPos: Position, humanPos: Position, treasures: Position[]): AIDecision {
    // Use advanced pathfinding to predict human route
    const predictedPath = this.predictHumanRoute(gameState, this.personality.planningDepth);
    
    // Analyze which treasure human is likely targeting using A* calculations
    let humanTarget = treasures[0];
    let shortestPathLength = Infinity;
    
    for (const treasure of treasures) {
      const pathToTreasure = this.findOptimalPath(humanPos, treasure, gameState);
      if (pathToTreasure.length > 0 && pathToTreasure.length < shortestPathLength) {
        shortestPathLength = pathToTreasure.length;
        humanTarget = treasure;
      }
    }
    
    // Calculate optimal AI path to same treasure
    const aiOptimalPath = this.findOptimalPath(aiPos, humanTarget, gameState);
    
    // If human has shorter path, use strategic blocking
    if (shortestPathLength < aiOptimalPath.length && gameState.playerResources.ai.walls > 0) {
      const optimalBlockingPos = this.findOptimalBlockingPosition(gameState, humanPos);
      
      if (optimalBlockingPos && !this.isKnownFailurePosition(optimalBlockingPos)) {
        return {
          action: 'place-wall',
          position: optimalBlockingPos,
          confidence: 0.95,
          reasoning: `Strategic blocking at chokepoint - disrupts human path by ${this.calculateBlockingImpact(optimalBlockingPos, gameState, humanPos)} moves`
        };
      }
    }
    
    // Use A* pathfinding for optimal movement
    if (aiOptimalPath.length > 0) {
      const nextMove = aiOptimalPath[0];
      return {
        action: 'move',
        position: nextMove,
        confidence: 0.9,
        reasoning: `A* pathfinding: optimal route to treasure (${aiOptimalPath.length} moves remaining)`
      };
    }
    
    // Fallback to direct movement
    const targetPos = {
      row: Math.max(0, Math.min(9, aiPos.row + (humanTarget.row > aiPos.row ? 1 : humanTarget.row < aiPos.row ? -1 : 0))),
      col: Math.max(0, Math.min(9, aiPos.col + (humanTarget.col > aiPos.col ? 1 : humanTarget.col < aiPos.col ? -1 : 0)))
    };
    
    return {
      action: 'move',
      position: targetPos,
      confidence: 0.7,
      reasoning: 'Fallback direct movement toward treasure'
    };
  }

  /**
   * Advanced pathfinding using comprehensive search algorithms
   * Automatically selects best algorithm based on personality and game state
   */
  private findOptimalPathWithAlgorithms(start: Position, goal: Position, gameState: GameState): Position[] {
    const searchResult = this.executeSearchAlgorithm(start, goal, gameState);
    return searchResult.path;
  }

  /**
   * Execute search algorithm based on AI personality preferences
   */
  private executeSearchAlgorithm(start: Position, goal: Position, gameState: GameState): SearchResult {
    switch (this.personality.searchAlgorithm) {
      case 'BFS':
        return BlindSearchAlgorithms.breadthFirstSearch(start, goal, gameState);
      
      case 'DFS':
        return BlindSearchAlgorithms.depthFirstSearch(start, goal, gameState);
      
      case 'UCS':
        return CostBasedSearchAlgorithms.uniformCostSearch(start, goal, gameState);
      
      case 'A*':
        return CostBasedSearchAlgorithms.aStarSearch(start, goal, gameState, this.personality.heuristicType);
      
      case 'auto':
        return this.selectOptimalAlgorithm(start, goal, gameState);
      
      default:
        return CostBasedSearchAlgorithms.aStarSearch(start, goal, gameState, 'manhattan');
    }
  }

  /**
   * Auto-select optimal algorithm based on game state analysis
   */
  private selectOptimalAlgorithm(start: Position, goal: Position, gameState: GameState): SearchResult {
    // Analyze game state complexity
    const gridSize = gameState.grid.length;
    const wallCount = gameState.grid.flat().filter(cell => cell.type === 'wall').length;
    const complexityScore = (wallCount / (gridSize * gridSize)) + (gameState.turnCount / 100);
    
    // Select algorithm based on complexity and personality
    if (complexityScore < 0.2) {
      // Simple case: use BFS for completeness
      return BlindSearchAlgorithms.breadthFirstSearch(start, goal, gameState);
    } else if (complexityScore < 0.5) {
      // Medium complexity: use A* with Manhattan heuristic
      return CostBasedSearchAlgorithms.aStarSearch(start, goal, gameState, 'manhattan');
    } else {
      // High complexity: use A* with strategic heuristic
      return CostBasedSearchAlgorithms.aStarSearch(start, goal, gameState, 'strategic');
    }
  }

  /**
   * Enhanced wall placement using strategic decision-making algorithms
   */
  private evaluateWallPlacementStrategically(
    position: Position,
    gameState: GameState,
    humanPos: Position,
    aiPos: Position
  ): { effectiveness: number; reasoning: string } {
    const evaluation = StrategicDecisionMaking.evaluateWallPlacement(
      position,
      gameState,
      humanPos,
      aiPos
    );
    
    // Store wall placement analytics in memory
    this.memory.wallPlacementHistory.push({
      position,
      turn: gameState.turnCount,
      impact: evaluation.effectiveness,
      success: evaluation.effectiveness > 0.5
    });
    
    return {
      effectiveness: evaluation.effectiveness,
      reasoning: evaluation.reasoning
    };
  }

  /**
   * Performance comparison for algorithm selection
   */
  private async compareAlgorithmPerformance(
    start: Position,
    goal: Position,
    gameState: GameState
  ): Promise<string> {
    const comparison = await PerformanceComparison.compareAlgorithms(start, goal, gameState);
    return comparison.recommendation;
  }

  /**
   * Advanced A* Pathfinding Algorithm - Enhanced for strategic gameplay
   */
  private findOptimalPath(start: Position, goal: Position, gameState: GameState, avoidHuman: boolean = false): Position[] {
    const openSet = new Map<string, { pos: Position; g: number; h: number; f: number; parent: Position | null }>();
    const closedSet = new Set<string>();
    const humanPos = gameState.players.human;
    
    const heuristic = (pos: Position): number => {
      const manhattan = Math.abs(pos.row - goal.row) + Math.abs(pos.col - goal.col);
      // Add penalty for being near human if avoiding
      const humanDistance = Math.abs(pos.row - humanPos.row) + Math.abs(pos.col - humanPos.col);
      const humanPenalty = avoidHuman && humanDistance < 3 ? (3 - humanDistance) * 2 : 0;
      
      // Add terrain cost consideration
      const terrainCost = this.getTerrainCost(pos, gameState);
      return manhattan + humanPenalty + terrainCost;
    };

    const getNeighbors = (pos: Position): Position[] => {
      const neighbors: Position[] = [];
      const directions = [
        { row: -1, col: 0 }, { row: 1, col: 0 },
        { row: 0, col: -1 }, { row: 0, col: 1 }
      ];
      
      for (const dir of directions) {
        const newPos = { row: pos.row + dir.row, col: pos.col + dir.col };
        if (this.isValidPosition(newPos, gameState)) {
          neighbors.push(newPos);
        }
      }
      return neighbors;
    };

    const startKey = `${start.row},${start.col}`;
    openSet.set(startKey, { pos: start, g: 0, h: heuristic(start), f: heuristic(start), parent: null });

    while (openSet.size > 0) {
      // Find node with lowest f score
      let current = Array.from(openSet.values())[0];
      let currentKey = `${current.pos.row},${current.pos.col}`;
      
      for (const [key, node] of openSet) {
        if (node.f < current.f) {
          current = node;
          currentKey = key;
        }
      }

      if (current.pos.row === goal.row && current.pos.col === goal.col) {
        // Reconstruct path
        const path: Position[] = [];
        let node = current;
        while (node.parent) {
          path.unshift(node.pos);
          const parentKey = `${node.parent.row},${node.parent.col}`;
          node = openSet.get(parentKey) || { pos: node.parent, g: 0, h: 0, f: 0, parent: null };
        }
        return path;
      }

      openSet.delete(currentKey);
      closedSet.add(currentKey);

      for (const neighbor of getNeighbors(current.pos)) {
        const neighborKey = `${neighbor.row},${neighbor.col}`;
        if (closedSet.has(neighborKey)) continue;

        const tentativeG = current.g + this.getMovementCost(current.pos, neighbor, gameState);
        const existingNeighbor = openSet.get(neighborKey);

        if (!existingNeighbor || tentativeG < existingNeighbor.g) {
          const h = heuristic(neighbor);
          openSet.set(neighborKey, {
            pos: neighbor,
            g: tentativeG,
            h: h,
            f: tentativeG + h,
            parent: current.pos
          });
        }
      }
    }

    return []; // No path found
  }

  /**
   * Calculate terrain-based movement cost
   */
  private getMovementCost(from: Position, to: Position, gameState: GameState): number {
    const baseCost = 1;
    const terrainCost = this.getTerrainCost(to, gameState);
    
    // Penalty for moving into previously failed positions
    const failurePenalty = this.isKnownFailurePosition(to) ? 3 : 0;
    
    return baseCost + terrainCost + failurePenalty;
  }

  /**
   * Get terrain cost for position
   */
  private getTerrainCost(pos: Position, gameState: GameState): number {
    const cell = gameState.grid[pos.row]?.[pos.col];
    if (!cell) return 10; // Invalid position
    
    switch (cell.type) {
      case 'water': return 2;
      case 'mud': return 2;
      case 'sand': return 3;
      case 'trap': return 5;
      case 'wall': return 10;
      default: return 0;
    }
  }

  /**
   * Check if position is valid for movement
   */
  private isValidPosition(pos: Position, gameState: GameState): boolean {
    return pos.row >= 0 && pos.row < 10 && pos.col >= 0 && pos.col < 10 &&
           gameState.grid[pos.row]?.[pos.col]?.type !== 'wall';
  }

  /**
   * Predict human's next moves based on behavior patterns
   */
  private predictHumanRoute(gameState: GameState, moves: number = 3): Position[] {
    const humanPos = gameState.players.human;
    const treasures = gameState.treasures;
    
    // Find human's likely target treasure
    let targetTreasure = treasures[0];
    let minDistance = Math.abs(humanPos.row - targetTreasure.row) + Math.abs(humanPos.col - targetTreasure.col);
    
    for (const treasure of treasures) {
      const distance = Math.abs(humanPos.row - treasure.row) + Math.abs(humanPos.col - treasure.col);
      if (distance < minDistance) {
        minDistance = distance;
        targetTreasure = treasure;
      }
    }
    
    // Use A* to predict human's optimal path
    const humanOptimalPath = this.findOptimalPath(humanPos, targetTreasure, gameState);
    
    // Return the next few moves
    return humanOptimalPath.slice(0, Math.min(moves, humanOptimalPath.length));
  }

  /**
   * Find optimal blocking position to disrupt human's path
   */
  private findOptimalBlockingPosition(gameState: GameState, humanPos: Position): Position | null {
    const predictedPath = this.predictHumanRoute(gameState, 5);
    
    if (predictedPath.length === 0) return null;
    
    // Find chokepoints in the predicted path
    const candidates: Array<{ pos: Position; impact: number }> = [];
    
    for (let i = 1; i < predictedPath.length - 1; i++) {
      const pos = predictedPath[i];
      const impact = this.calculateBlockingImpact(pos, gameState, humanPos);
      candidates.push({ pos, impact });
    }
    
    // Sort by impact and return best position
    candidates.sort((a, b) => b.impact - a.impact);
    return candidates.length > 0 ? candidates[0].pos : null;
  }

  /**
   * Calculate how much blocking at a position would disrupt human's progress
   */
  private calculateBlockingImpact(pos: Position, gameState: GameState, humanPos: Position): number {
    // Create temporary game state with wall at position
    const tempState = { ...gameState };
    tempState.grid[pos.row][pos.col] = { ...tempState.grid[pos.row][pos.col], type: 'wall' };
    
    // Calculate new path length for human
    const treasures = gameState.treasures;
    let totalImpact = 0;
    
    for (const treasure of treasures) {
      const originalPath = this.findOptimalPath(humanPos, treasure, gameState);
      const blockedPath = this.findOptimalPath(humanPos, treasure, tempState);
      
      const originalLength = originalPath.length;
      const blockedLength = blockedPath.length;
      
      // High impact if path is significantly longer or blocked entirely
      if (blockedLength === 0) {
        totalImpact += 20; // Complete blockage
      } else if (blockedLength > originalLength) {
        totalImpact += (blockedLength - originalLength) * 2;
      }
    }
    
    return totalImpact;
  }

  /**
   * Advanced Wall Placement Strategy - Determines if AI should place a wall
   */
  private shouldPlaceWall(gameState: GameState): boolean {
    const aiPos = gameState.players.ai;
    const humanPos = gameState.players.human;
    const treasures = gameState.treasures;
    
    // Check if AI has walls remaining
    if (gameState.playerResources.ai.walls <= 0) {
      return false;
    }
    
    // Find human's target treasure (shortest A* path)
    let humanTarget = treasures[0];
    let humanShortestPath: Position[] = [];
    let humanPathLength = Infinity;
    
    for (const treasure of treasures) {
      const path = this.findOptimalPath(humanPos, treasure, gameState);
      if (path.length > 0 && path.length < humanPathLength) {
        humanPathLength = path.length;
        humanTarget = treasure;
        humanShortestPath = path;
      }
    }
    
    // Find AI's path to same treasure
    const aiPath = this.findOptimalPath(aiPos, humanTarget, gameState);
    const aiPathLength = aiPath.length;
    
    // Strategic conditions for wall placement
    const humanIsCloser = humanPathLength < aiPathLength;
    const raceIsTight = Math.abs(humanPathLength - aiPathLength) <= 2;
    const humanPathExists = humanShortestPath.length > 0;
    const lateGame = this.turnCount > 5;
    
    // Personality-based wall placement decision
    const blockingDesire = this.personality.blockingPropensity;
    const riskTolerance = this.personality.riskTolerance;
    
    // Decision logic based on personality and game state
    if (this.personality.name === 'blocker') {
      // Blocker: Always try to block if human has any path advantage
      return humanPathExists && (humanIsCloser || raceIsTight);
    } else if (this.personality.name === 'strategist') {
      // Strategist: Block when strategically advantageous
      return humanIsCloser && humanPathExists && (raceIsTight || lateGame);
    } else if (this.personality.name === 'rusher') {
      // Rusher: Only block in desperate situations
      return humanIsCloser && humanPathLength < aiPathLength - 3;
    } else if (this.personality.name === 'collector') {
      // Collector: Block to buy time for power-up collection
      return humanIsCloser && gameState.powerUps.length > 0;
    }
    
    return false;
  }

  /**
   * Find the best wall tile for maximum strategic impact
   */
  private getBestWallTile(gameState: GameState): Position | null {
    const humanPos = gameState.players.human;
    const treasures = gameState.treasures;
    const aiPos = gameState.players.ai;
    
    // Find human's optimal path
    let humanTarget = treasures[0];
    let humanPath: Position[] = [];
    let shortestDistance = Infinity;
    
    for (const treasure of treasures) {
      const path = this.findOptimalPath(humanPos, treasure, gameState);
      if (path.length > 0 && path.length < shortestDistance) {
        shortestDistance = path.length;
        humanTarget = treasure;
        humanPath = path;
      }
    }
    
    if (humanPath.length === 0) return null;
    
    // Analyze potential wall positions
    const candidates: Array<{ pos: Position; impact: number; priority: number }> = [];
    
    // Check each position along human's path (excluding start and end)
    for (let i = 1; i < humanPath.length - 1; i++) {
      const pos = humanPath[i];
      
      // Validate wall placement rules
      if (!this.isValidWallPlacement(pos, gameState)) continue;
      
      const impact = this.calculateBlockingImpact(pos, gameState, humanPos);
      let priority = impact;
      
      // Bonus for chokepoints and narrow passages
      const chokePointBonus = this.calculateChokePointValue(pos, gameState);
      priority += chokePointBonus;
      
      // Bonus for mid-path positions (forces longer reroute)
      const midPathBonus = Math.abs(i - humanPath.length / 2) < 2 ? 10 : 0;
      priority += midPathBonus;
      
      // Penalty if too close to AI (might block own path)
      const aiDistance = Math.abs(pos.row - aiPos.row) + Math.abs(pos.col - aiPos.col);
      const proximityPenalty = aiDistance < 3 ? 5 : 0;
      priority -= proximityPenalty;
      
      // Memory integration - avoid previously failed positions
      if (this.isKnownFailurePosition(pos)) {
        priority -= 15;
      }
      
      candidates.push({ pos, impact, priority });
    }
    
    // Also check positions adjacent to human's path (flanking strategy)
    for (const pathPos of humanPath) {
      const adjacent = [
        { row: pathPos.row - 1, col: pathPos.col },
        { row: pathPos.row + 1, col: pathPos.col },
        { row: pathPos.row, col: pathPos.col - 1 },
        { row: pathPos.row, col: pathPos.col + 1 }
      ];
      
      for (const adjPos of adjacent) {
        if (!this.isValidWallPlacement(adjPos, gameState)) continue;
        
        const impact = this.calculateBlockingImpact(adjPos, gameState, humanPos);
        if (impact >= 2) { // Only consider if blocks for at least 2 turns
          candidates.push({ pos: adjPos, impact, priority: impact + 5 });
        }
      }
    }
    
    // Sort by priority and return best position
    candidates.sort((a, b) => b.priority - a.priority);
    
    return candidates.length > 0 ? candidates[0].pos : null;
  }

  /**
   * Validate if a wall can be placed at the given position
   */
  private isValidWallPlacement(pos: Position, gameState: GameState): boolean {
    // Check bounds
    if (pos.row < 0 || pos.row >= 10 || pos.col < 0 || pos.col >= 10) {
      return false;
    }
    
    // Check if position is already blocked
    const cell = gameState.grid[pos.row][pos.col];
    if (cell.type === 'wall') {
      return false;
    }
    
    // Don't block on treasure positions
    for (const treasure of gameState.treasures) {
      if (treasure.row === pos.row && treasure.col === pos.col) {
        return false;
      }
    }
    
    // Don't block directly on players
    if ((gameState.players.human.row === pos.row && gameState.players.human.col === pos.col) ||
        (gameState.players.ai.row === pos.row && gameState.players.ai.col === pos.col)) {
      return false;
    }
    
    // Don't block on keys or power-ups
    for (const key of gameState.keys || []) {
      if (key.row === pos.row && key.col === pos.col) {
        return false;
      }
    }
    
    for (const powerUp of gameState.powerUps || []) {
      if (powerUp.row === pos.row && powerUp.col === pos.col) {
        return false;
      }
    }
    
    return true;
  }

  /**
   * Calculate the strategic value of a position as a chokepoint
   */
  private calculateChokePointValue(pos: Position, gameState: GameState): number {
    let chokeValue = 0;
    
    // Count adjacent passable tiles
    const adjacent = [
      { row: pos.row - 1, col: pos.col },
      { row: pos.row + 1, col: pos.col },
      { row: pos.row, col: pos.col - 1 },
      { row: pos.row, col: pos.col + 1 }
    ];
    
    let passableTiles = 0;
    for (const adjPos of adjacent) {
      if (this.isValidPosition(adjPos, gameState)) {
        passableTiles++;
      }
    }
    
    // Positions with fewer adjacent passable tiles are better chokepoints
    chokeValue = (4 - passableTiles) * 5;
    
    // Bonus for positions near board edges or existing walls
    if (pos.row === 0 || pos.row === 9 || pos.col === 0 || pos.col === 9) {
      chokeValue += 3;
    }
    
    return chokeValue;
  }

  /**
   * Advanced bluffing strategy - place walls to confuse human player
   */
  private shouldBluffWall(gameState: GameState): boolean {
    const bluffingTendency = this.personality.name === 'strategist' ? 0.3 : 0.1;
    const randomFactor = Math.random();
    
    // Bluff occasionally when AI has multiple walls and is in good position
    return randomFactor < bluffingTendency && 
           gameState.playerResources.ai.walls > 1 && 
           this.turnCount > 3;
  }

  /**
   * Enhanced wall placement execution with multi-turn planning and analytics
   */
  private executeWallStrategy(gameState: GameState): AIDecision | null {
    // Check timing strategy - save walls for critical moments
    const shouldSaveWalls = this.shouldSaveWallsForLaterGame(gameState);
    if (shouldSaveWalls && !this.isUrgentWallSituation(gameState)) {
      return null;
    }
    
    // Check if we should place a wall
    if (!this.shouldPlaceWall(gameState) && !this.shouldBluffWall(gameState)) {
      return null;
    }
    
    // Find the best position for wall placement
    const bestWallPos = this.getBestWallTile(gameState);
    
    if (!bestWallPos) {
      return null;
    }
    
    // Calculate the strategic impact and expected success
    const impact = this.calculateBlockingImpact(bestWallPos, gameState, gameState.players.human);
    const chokeValue = this.calculateChokePointValue(bestWallPos, gameState);
    const expectedSuccess = this.predictWallPlacementSuccess(bestWallPos, gameState);
    
    // Only place wall if expected impact is significant
    if (impact < 2 && !this.shouldBluffWall(gameState)) {
      return null;
    }
    
    // Store this decision in memory for future learning
    this.memory.blockingSuccess.set(`${bestWallPos.row},${bestWallPos.col}`, true);
    this.memory.wallPlacementHistory.push({
      position: bestWallPos,
      turn: this.turnCount,
      impact: impact,
      success: false // Will be updated based on actual outcome
    });
    
    // Learn from this placement for future decisions
    this.learnFromWallPlacement(bestWallPos, impact, gameState);
    
    return {
      action: 'place-wall',
      position: bestWallPos,
      confidence: Math.min(0.95, 0.6 + (expectedSuccess * 0.4)),
      reasoning: `Strategic wall: blocks ${impact} turns, chokepoint value ${chokeValue}, success probability ${Math.round(expectedSuccess * 100)}%`
    };
  }

  /**
   * Timing strategy: save walls for critical late-game moments
   */
  private shouldSaveWallsForLaterGame(gameState: GameState): boolean {
    const wallsRemaining = gameState.playerResources.ai.walls;
    const humanDistance = Math.min(...gameState.treasures.map(t => 
      Math.abs(gameState.players.human.row - t.row) + Math.abs(gameState.players.human.col - t.col)
    ));
    
    // Save walls if we have plenty and human is still far from treasure
    return wallsRemaining > 2 && humanDistance > 5 && this.turnCount < 8;
  }

  /**
   * Detect urgent situations requiring immediate wall placement
   */
  private isUrgentWallSituation(gameState: GameState): boolean {
    const humanPos = gameState.players.human;
    const aiPos = gameState.players.ai;
    
    // Find closest treasure to human
    let minHumanDistance = Infinity;
    let minAiDistance = Infinity;
    
    for (const treasure of gameState.treasures) {
      const humanDist = Math.abs(humanPos.row - treasure.row) + Math.abs(humanPos.col - treasure.col);
      const aiDist = Math.abs(aiPos.row - treasure.row) + Math.abs(aiPos.col - treasure.col);
      
      if (humanDist < minHumanDistance) {
        minHumanDistance = humanDist;
      }
      if (aiDist < minAiDistance) {
        minAiDistance = aiDist;
      }
    }
    
    // Urgent if human is very close to treasure and AI is behind
    return minHumanDistance <= 3 && minHumanDistance < minAiDistance;
  }

  /**
   * Predict the success probability of a wall placement
   */
  private predictWallPlacementSuccess(pos: Position, gameState: GameState): number {
    let successProbability = 0.5; // Base probability
    
    // Learn from historical wall placements
    const historicalData = this.memory.wallPlacementHistory.filter(h => 
      Math.abs(h.position.row - pos.row) <= 1 && Math.abs(h.position.col - pos.col) <= 1
    );
    
    if (historicalData.length > 0) {
      const successRate = historicalData.filter(h => h.success).length / historicalData.length;
      successProbability = successRate * 0.7 + successProbability * 0.3; // Weighted average
    }
    
    // Factor in chokepoint value
    const chokeValue = this.calculateChokePointValue(pos, gameState);
    successProbability += (chokeValue / 100); // Chokepoints are more likely to succeed
    
    // Factor in human predictability
    const humanPredictability = this.calculateHumanPredictability(gameState);
    successProbability += (humanPredictability * 0.2);
    
    return Math.max(0.1, Math.min(0.95, successProbability));
  }

  /**
   * Calculate how predictable the human player's movements are
   */
  private calculateHumanPredictability(gameState: GameState): number {
    const patterns = Array.from(this.memory.humanPatterns.values());
    if (patterns.length === 0) return 0.5;
    
    // High predictability if human follows consistent patterns
    const maxPattern = Math.max(...patterns);
    const totalPatterns = patterns.reduce((a, b) => a + b, 0);
    
    return maxPattern / totalPatterns;
  }

  /**
   * Learn from wall placement outcomes to improve future decisions
   */
  private learnFromWallPlacement(pos: Position, expectedImpact: number, gameState: GameState): void {
    const posKey = `${pos.row},${pos.col}`;
    
    // Store the context for this wall placement
    const humanRoute = this.predictHumanRoute(gameState, 3);
    const routeKey = humanRoute.map(p => `${p.row},${p.col}`).join('-');
    
    // Track how humans typically respond to walls in similar positions
    if (!this.memory.humanCounterStrategies.has(routeKey)) {
      this.memory.humanCounterStrategies.set(routeKey, 0);
    }
    
    // This will be updated later when we observe the actual human response
    console.log(`AI ${this.personality.name}: Learning opportunity - wall at ${posKey}, expected impact ${expectedImpact}`);
  }

  /**
   * Personality-based decision making with memory adaptation
   */
  private makePersonalityBasedDecision(gameState: GameState): AIDecision {
    const aiPos = gameState.players.ai;
    const humanPos = gameState.players.human;
    const treasures = gameState.treasures;
    
    switch (this.personality.name) {
      case 'rusher':
        return this.makeRusherDecision(gameState, aiPos, treasures);
        
      case 'blocker':
        return this.makeBlockerDecision(gameState, aiPos, humanPos, treasures);
        
      case 'collector':
        return this.makeCollectorDecision(gameState, aiPos);
        
      case 'strategist':
        return this.makeStrategistDecision(gameState, aiPos, humanPos, treasures);
    }
  }

  /**
   * Multi-turn lookahead planning for strategic decision making
   */
  private evaluateMultiTurnStrategy(gameState: GameState, depth: number = 3): AIDecision {
    const aiPos = gameState.players.ai;
    const humanPos = gameState.players.human;
    const treasures = gameState.treasures;
    
    if (depth <= 0 || treasures.length === 0) {
      return this.makePersonalityBasedDecision(gameState);
    }
    
    // Evaluate multiple possible moves
    const possibleMoves = [
      { row: aiPos.row - 1, col: aiPos.col }, // Up
      { row: aiPos.row + 1, col: aiPos.col }, // Down
      { row: aiPos.row, col: aiPos.col - 1 }, // Left
      { row: aiPos.row, col: aiPos.col + 1 }  // Right
    ].filter(pos => this.isValidPosition(pos, gameState));
    
    let bestMove = possibleMoves[0];
    let bestScore = -Infinity;
    
    for (const move of possibleMoves) {
      // Simulate game state after this move
      const simulatedState = { ...gameState };
      simulatedState.players = { ...gameState.players, ai: move };
      
      // Calculate strategic value of this position
      let score = 0;
      
      // Distance to nearest treasure (lower is better)
      const nearestTreasure = treasures.reduce((closest, treasure) => {
        const dist = Math.abs(move.row - treasure.row) + Math.abs(move.col - treasure.col);
        const closestDist = Math.abs(move.row - closest.row) + Math.abs(move.col - closest.col);
        return dist < closestDist ? treasure : closest;
      }, treasures[0]);
      
      const treasureDistance = Math.abs(move.row - nearestTreasure.row) + Math.abs(move.col - nearestTreasure.col);
      score -= treasureDistance * 10; // Prioritize getting closer to treasure
      
      // Blocking potential (higher is better for blocker personality)
      if (this.personality.blockingPropensity > 0.5) {
        const humanDistanceToTreasure = Math.abs(humanPos.row - nearestTreasure.row) + Math.abs(humanPos.col - nearestTreasure.col);
        const blockingValue = this.calculateBlockingImpact(move, gameState, humanPos);
        score += blockingValue * this.personality.blockingPropensity * 5;
      }
      
      // Avoid previously failed positions
      if (this.isKnownFailurePosition(move)) {
        score -= 50;
      }
      
      // Strategic positioning bonus
      const centerDistance = Math.abs(move.row - 5) + Math.abs(move.col - 5);
      score += (10 - centerDistance) * 2; // Slight preference for center positions
      
      if (score > bestScore) {
        bestScore = score;
        bestMove = move;
      }
    }
    
    return {
      action: 'move',
      position: bestMove,
      confidence: 0.9,
      reasoning: `Multi-turn analysis (depth ${this.personality.planningDepth}): strategic positioning with score ${Math.round(bestScore)}`
    };
  }

  /**
   * Enhanced main decision-making function with memory, personality, wall strategy, and lookahead
   */
  public makeDecision(gameState: GameState): AIDecision {
    this.turnCount++;
    this.updateHumanPatterns(gameState);
    this.gameHistory.push(gameState);
    
    // PRIORITY 1: Strategic Wall Placement (highest priority for blocking)
    const wallDecision = this.executeWallStrategy(gameState);
    if (wallDecision && this.isValidDecision(wallDecision, gameState)) {
      console.log(`AI ${this.personality.name}: ${wallDecision.reasoning}`);
      return wallDecision;
    }
    
    // PRIORITY 2: Multi-turn planning for Strategist and high-level personalities
    if (this.personality.planningDepth >= 4 && this.personality.name === 'strategist') {
      const strategicDecision = this.evaluateMultiTurnStrategy(gameState, this.personality.planningDepth);
      if (this.isValidDecision(strategicDecision, gameState)) {
        return strategicDecision;
      }
    }
    
    // PRIORITY 3: Personality-based decision making with memory
    const decision = this.makePersonalityBasedDecision(gameState);
    
    // Validate the decision against game rules
    if (this.isValidDecision(decision, gameState)) {
      return decision;
    }
    
    // PRIORITY 4: Fallback to safe move if all other strategies fail
    return this.makeSafeMove(gameState);
  }

  // Helper methods for decision validation and fallback
  private isValidDecision(decision: AIDecision, gameState: GameState): boolean {
    const { position } = decision;
    return position.row >= 0 && position.row < 10 && 
           position.col >= 0 && position.col < 10;
  }

  private makeSafeMove(gameState: GameState): AIDecision {
    const aiPos = gameState.players.ai;
    const treasure = gameState.treasures[0];
    
    return {
      action: 'move',
      position: {
        row: Math.max(0, Math.min(9, aiPos.row + (treasure.row > aiPos.row ? 1 : treasure.row < aiPos.row ? -1 : 0))),
        col: Math.max(0, Math.min(9, aiPos.col + (treasure.col > aiPos.col ? 1 : treasure.col < aiPos.col ? -1 : 0)))
      },
      confidence: 0.3,
      reasoning: 'Safe fallback move toward treasure'
    };
  }

  public getPersonality() {
    return this.personality;
  }
}

// Create AI Agent function for the new personality system
export function createAIAgent(personalityName: 'rusher' | 'blocker' | 'collector' | 'strategist' = 'rusher'): AdvancedAI {
  return new AdvancedAI(personalityName);
}