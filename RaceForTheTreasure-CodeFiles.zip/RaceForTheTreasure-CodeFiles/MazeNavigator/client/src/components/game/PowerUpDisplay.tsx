import React from 'react';
import { Zap, Shield, Plus, Droplets } from 'lucide-react';
import { GameState } from '../../types/game';

interface PowerUpDisplayProps {
  gameState: GameState;
  currentPlayer: 'human' | 'ai';
  onActivatePowerUp?: (powerUpType: string) => void;
}

export const PowerUpDisplay: React.FC<PowerUpDisplayProps> = ({
  gameState,
  currentPlayer,
  onActivatePowerUp
}) => {
  // Add null checks to prevent runtime errors
  if (!gameState?.playerResources?.[currentPlayer]) {
    return (
      <div className="bg-white rounded-lg shadow-md p-4">
        <h3 className="text-lg font-semibold mb-3 text-gray-800">Power-Ups</h3>
        <p className="text-gray-500">Loading player resources...</p>
      </div>
    );
  }

  const playerResources = gameState.playerResources[currentPlayer];
  const powerUps = playerResources.powerUps;

  const powerUpItems = [
    {
      type: 'extraMovement',
      name: 'Extra Movement',
      icon: Zap,
      count: powerUps.extraMovement,
      color: 'text-yellow-600 bg-yellow-100',
      description: 'Additional movement points'
    },
    {
      type: 'ignoreWaterCost',
      name: 'Water Immunity',
      icon: Droplets,
      count: powerUps.ignoreWaterCost,
      color: 'text-blue-600 bg-blue-100',
      description: 'Ignore water terrain costs'
    },
    {
      type: 'extraWalls',
      name: 'Bonus Walls',
      icon: Shield,
      count: powerUps.extraWalls,
      color: 'text-slate-600 bg-slate-100',
      description: 'Additional wall placements'
    },
    {
      type: 'extraLadders',
      name: 'Bonus Ladders',
      icon: Plus,
      count: powerUps.extraLadders,
      color: 'text-purple-600 bg-purple-100',
      description: 'Additional ladder placements'
    }
  ];

  return (
    <div className="h-full p-2 bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 rounded-lg shadow border border-green-300 overflow-hidden">
      <h3 className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-green-600 to-teal-600 mb-2 flex items-center gap-1">
        <Zap className="w-4 h-4 text-green-500" />
        Power-Ups
      </h3>
      
      <div className="space-y-1 overflow-y-auto flex-1">
        {powerUpItems.map((item) => {
          const Icon = item.icon;
          const isActive = item.count > 0;
          
          return (
            <div
              key={item.type}
              className={`p-2 rounded-lg border transition-all ${
                isActive 
                  ? `${item.color} border-current` 
                  : 'bg-gray-50 text-gray-400 border-gray-200'
              }`}
              style={{
                transitionDelay: `${powerUpItems.indexOf(item) * 100}ms`
              }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`p-1 rounded ${isActive ? 'bg-white bg-opacity-50' : 'bg-gray-200'}`}>
                    <Icon className={`w-3 h-3 ${isActive ? '' : 'text-gray-400'}`} />
                  </div>
                  <div className="flex-1">
                    <div className={`font-medium text-xs ${isActive ? '' : 'text-gray-400'}`}>
                      {item.name}
                    </div>
                    <div className={`text-xs ${isActive ? 'opacity-80' : 'text-gray-400'} truncate`}>
                      {item.description}
                    </div>
                  </div>
                </div>
                
                <div className="flex items-center gap-1">
                  <div className={`text-sm font-bold px-1 py-1 rounded ${
                    isActive ? 'bg-white bg-opacity-70' : 'bg-gray-200 text-gray-400'
                  }`}>
                    {item.count}
                  </div>
                  
                  {/* Activation button for certain power-ups */}
                  {isActive && (item.type === 'extraMovement' || item.type === 'extraWalls' || item.type === 'extraLadders') && onActivatePowerUp && currentPlayer === 'human' && (
                    <button
                      onClick={() => onActivatePowerUp(item.type)}
                      className="px-2 py-1 text-xs font-medium bg-white bg-opacity-80 hover:bg-opacity-100 text-current rounded transition-all"
                    >
                      Use
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
      
      {/* Status Effects */}
      {playerResources.stunned > 0 && (
        <div className="mt-4 p-3 bg-red-100 border-2 border-red-300 rounded-xl">
          <div className="flex items-center gap-2 text-red-700">
            <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
            <span className="font-medium">Stunned: {playerResources.stunned} turns</span>
          </div>
        </div>
      )}
      
      {/* Resource Summary */}
      <div className="mt-4 p-3 bg-white bg-opacity-70 rounded-xl border border-green-200">
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div className="flex justify-between">
            <span className="text-green-700">Walls:</span>
            <span className="font-bold">{playerResources.walls}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-green-700">Ladders:</span>
            <span className="font-bold">{playerResources.ladders}</span>
          </div>
        </div>
      </div>
    </div>
  );
};