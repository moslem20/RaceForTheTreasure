import { GameState, Position } from '../../types/game';

export type DifficultyLevel = 'easy' | 'normal' | 'hard';

export interface AIDecision {
  action: 'move' | 'place-wall' | 'place-ladder';
  position: Position;
  confidence: number;
  reasoning: string;
}

export class DifficultyAI {
  private difficulty: DifficultyLevel = 'normal';

  constructor(difficulty: DifficultyLevel) {
    this.difficulty = difficulty;
  }

  public setDifficulty(difficulty: DifficultyLevel): void {
    this.difficulty = difficulty;
  }

  public getDifficulty(): DifficultyLevel {
    return this.difficulty;
  }

  public makeMove(gameState: GameState): AIDecision {
    switch (this.difficulty) {
      case 'easy':
        return this.aiEasyMove(gameState);
      case 'normal':
        return this.aiNormalMove(gameState);
      case 'hard':
        return this.aiHardMove(gameState);
      default:
        return this.aiNormalMove(gameState);
    }
  }

  /**
   * 🔹 Easy Mode - Basic BFS pathfinding
   * - Uses Breadth-First Search (BFS)
   * - Ignores tile costs (treats all as equal)
   * - No tool use, no opponent awareness
   */
  private aiEasyMove(gameState: GameState): AIDecision {
    const aiPos = gameState.players.ai;
    const treasures = gameState.treasures;
    
    if (treasures.length === 0) {
      return {
        action: 'move',
        position: aiPos,
        confidence: 0.1,
        reasoning: 'No treasures available'
      };
    }

    // Find nearest treasure using Manhattan distance (ignoring costs)
    const nearestTreasure = treasures.reduce((closest, treasure) => {
      const distToCurrent = Math.abs(aiPos.row - treasure.row) + Math.abs(aiPos.col - treasure.col);
      const distToClosest = Math.abs(aiPos.row - closest.row) + Math.abs(aiPos.col - closest.col);
      return distToCurrent < distToClosest ? treasure : closest;
    });

    // Simple BFS to find shortest path (ignoring costs)
    const path = this.bfsPathfinding(aiPos, nearestTreasure, gameState);
    
    if (path.length > 1) {
      const nextMove = path[1]; // First step after current position
      return {
        action: 'move',
        position: nextMove,
        confidence: 0.6,
        reasoning: `Easy mode: Moving toward treasure using BFS (${path.length} steps)`
      };
    }

    // Fallback: try adjacent moves
    const directions = [
      { row: -1, col: 0 }, { row: 1, col: 0 },
      { row: 0, col: -1 }, { row: 0, col: 1 }
    ];

    for (const dir of directions) {
      const newPos = { row: aiPos.row + dir.row, col: aiPos.col + dir.col };
      if (this.isValidPosition(newPos, gameState)) {
        return {
          action: 'move',
          position: newPos,
          confidence: 0.3,
          reasoning: 'Easy mode: Random valid move'
        };
      }
    }

    return {
      action: 'move',
      position: aiPos,
      confidence: 0.1,
      reasoning: 'Easy mode: No valid moves'
    };
  }

  /**
   * 🔸 Normal Mode - A* algorithm with terrain costs
   * - Uses A* with Manhattan distance heuristic
   * - Considers terrain cost (water = 2, normal = 1)
   * - Dynamically replans if blocked
   * - No tool placement, intelligent routing
   */
  private aiNormalMove(gameState: GameState): AIDecision {
    const aiPos = gameState.players.ai;
    const treasures = gameState.treasures;
    
    if (treasures.length === 0) {
      return {
        action: 'move',
        position: aiPos,
        confidence: 0.1,
        reasoning: 'No treasures available'
      };
    }

    // Use A* to find optimal path considering costs
    let bestPath: Position[] = [];
    let bestCost = Infinity;
    let targetTreasure: Position = treasures[0];

    for (const treasure of treasures) {
      const pathResult = this.aStarPathfinding(aiPos, treasure, gameState);
      if (pathResult.cost < bestCost) {
        bestCost = pathResult.cost;
        bestPath = pathResult.path;
        targetTreasure = treasure;
      }
    }

    if (bestPath.length > 1) {
      const nextMove = bestPath[1];
      return {
        action: 'move',
        position: nextMove,
        confidence: 0.8,
        reasoning: `Normal mode: A* pathfinding to treasure (cost: ${bestCost.toFixed(1)})`
      };
    }

    // Fallback to easy mode behavior
    return this.aiEasyMove(gameState);
  }

  /**
   * 🔴 Hard Mode - Enhanced planning with opponent modeling
   * - Uses A* + opponent prediction
   * - Places walls/ladders strategically
   * - Multi-turn planning (2-3 turns ahead)
   * - Prioritizes defense or offense based on board state
   */
  private aiHardMove(gameState: GameState): AIDecision {
    const aiPos = gameState.players.ai;
    const humanPos = gameState.players.human;
    const treasures = gameState.treasures;
    const aiResources = gameState.playerResources.ai;

    if (treasures.length === 0) {
      return {
        action: 'move',
        position: aiPos,
        confidence: 0.1,
        reasoning: 'No treasures available'
      };
    }

    // Step 1: Simulate player's A* path to treasure
    const humanPath = this.simulatePlayerPath(gameState, 'human');
    const aiPath = this.simulatePlayerPath(gameState, 'ai');

    // Step 2: Determine if player is closer to any treasure
    const humanMinDistance = Math.min(...treasures.map(t => 
      Math.abs(humanPos.row - t.row) + Math.abs(humanPos.col - t.col)
    ));
    const aiMinDistance = Math.min(...treasures.map(t => 
      Math.abs(aiPos.row - t.row) + Math.abs(aiPos.col - t.col)
    ));

    const playerIsCloser = humanMinDistance < aiMinDistance;

    // Step 3: Strategic decision making
    if (playerIsCloser && aiResources.walls > 0) {
      // Try to block player with wall
      const blockingPosition = this.findBestBlockingPosition(gameState, humanPath);
      if (blockingPosition) {
        return {
          action: 'place-wall',
          position: blockingPosition,
          confidence: 0.9,
          reasoning: `Hard mode: Blocking human path (${humanPath.length} steps ahead)`
        };
      }
    }

    // Step 4: Check if placing ladder would give significant advantage
    if (aiResources.ladders > 0) {
      const ladderPosition = this.findBestLadderPosition(gameState, aiPath);
      if (ladderPosition) {
        return {
          action: 'place-ladder',
          position: ladderPosition,
          confidence: 0.85,
          reasoning: `Hard mode: Strategic ladder placement for speed boost`
        };
      }
    }

    // Step 5: Execute best move based on projected 2-turn outcome
    const bestMove = this.evaluateMultiTurnMoves(gameState, 2);
    if (bestMove) {
      return {
        action: 'move',
        position: bestMove,
        confidence: 0.9,
        reasoning: `Hard mode: Multi-turn planning (${aiPath.length} steps to treasure)`
      };
    }

    // Fallback to normal mode A* pathfinding
    return this.aiNormalMove(gameState);
  }

  /**
   * BFS Pathfinding for Easy Mode
   */
  private bfsPathfinding(start: Position, goal: Position, gameState: GameState): Position[] {
    const queue: { pos: Position; path: Position[] }[] = [{ pos: start, path: [start] }];
    const visited = new Set<string>();
    visited.add(`${start.row},${start.col}`);

    while (queue.length > 0) {
      const { pos, path } = queue.shift()!;

      if (pos.row === goal.row && pos.col === goal.col) {
        return path;
      }

      const neighbors = this.getNeighbors(pos);
      for (const neighbor of neighbors) {
        const key = `${neighbor.row},${neighbor.col}`;
        if (!visited.has(key) && this.isValidPosition(neighbor, gameState)) {
          visited.add(key);
          queue.push({ pos: neighbor, path: [...path, neighbor] });
        }
      }
    }

    return [start]; // No path found
  }

  /**
   * A* Pathfinding for Normal and Hard Mode
   */
  private aStarPathfinding(start: Position, goal: Position, gameState: GameState): { path: Position[]; cost: number } {
    const openSet: { pos: Position; gScore: number; fScore: number; parent: Position | null }[] = [];
    const closedSet = new Set<string>();
    
    openSet.push({ pos: start, gScore: 0, fScore: this.heuristic(start, goal), parent: null });
    const cameFrom = new Map<string, Position>();

    while (openSet.length > 0) {
      // Find node with lowest fScore
      openSet.sort((a, b) => a.fScore - b.fScore);
      const current = openSet.shift()!;
      const currentKey = `${current.pos.row},${current.pos.col}`;

      if (current.pos.row === goal.row && current.pos.col === goal.col) {
        // Reconstruct path
        const path: Position[] = [];
        let pos = current.pos;
        path.push(pos);
        
        while (cameFrom.has(`${pos.row},${pos.col}`)) {
          pos = cameFrom.get(`${pos.row},${pos.col}`)!;
          path.unshift(pos);
        }
        
        return { path, cost: current.gScore };
      }

      closedSet.add(currentKey);

      const neighbors = this.getNeighbors(current.pos);
      for (const neighbor of neighbors) {
        const neighborKey = `${neighbor.row},${neighbor.col}`;
        
        if (closedSet.has(neighborKey) || !this.isValidPosition(neighbor, gameState)) {
          continue;
        }

        const tentativeGScore = current.gScore + this.getMoveCost(neighbor, gameState);
        
        const existingNode = openSet.find(node => 
          node.pos.row === neighbor.row && node.pos.col === neighbor.col
        );

        if (!existingNode) {
          openSet.push({
            pos: neighbor,
            gScore: tentativeGScore,
            fScore: tentativeGScore + this.heuristic(neighbor, goal),
            parent: current.pos
          });
          cameFrom.set(neighborKey, current.pos);
        } else if (tentativeGScore < existingNode.gScore) {
          existingNode.gScore = tentativeGScore;
          existingNode.fScore = tentativeGScore + this.heuristic(neighbor, goal);
          existingNode.parent = current.pos;
          cameFrom.set(neighborKey, current.pos);
        }
      }
    }

    return { path: [start], cost: Infinity };
  }

  /**
   * Helper methods
   */
  private simulatePlayerPath(gameState: GameState, player: 'human' | 'ai'): Position[] {
    const playerPos = gameState.players[player];
    const treasures = gameState.treasures;
    
    if (treasures.length === 0) return [playerPos];

    // Find nearest treasure
    const nearestTreasure = treasures.reduce((closest, treasure) => {
      const distToCurrent = Math.abs(playerPos.row - treasure.row) + Math.abs(playerPos.col - treasure.col);
      const distToClosest = Math.abs(playerPos.row - closest.row) + Math.abs(playerPos.col - closest.col);
      return distToCurrent < distToClosest ? treasure : closest;
    });

    return this.aStarPathfinding(playerPos, nearestTreasure, gameState).path;
  }

  private findBestBlockingPosition(gameState: GameState, humanPath: Position[]): Position | null {
    if (humanPath.length < 2) return null;

    // Try to block 2-3 steps ahead on human's path
    for (let i = 1; i < Math.min(4, humanPath.length); i++) {
      const blockPos = humanPath[i];
      if (this.isValidPlacement(blockPos, gameState)) {
        return blockPos;
      }
    }

    return null;
  }

  private findBestLadderPosition(gameState: GameState, aiPath: Position[]): Position | null {
    if (aiPath.length < 2) return null;

    // Find high-cost tiles on AI's path
    for (let i = 1; i < Math.min(4, aiPath.length); i++) {
      const ladderPos = aiPath[i];
      const isHighCost = gameState.highCostTiles.some(tile => 
        tile.row === ladderPos.row && tile.col === ladderPos.col
      );
      
      if (isHighCost && this.isValidPlacement(ladderPos, gameState)) {
        return ladderPos;
      }
    }

    return null;
  }

  private evaluateMultiTurnMoves(gameState: GameState, depth: number): Position | null {
    const aiPos = gameState.players.ai;
    const directions = [
      { row: -1, col: 0 }, { row: 1, col: 0 },
      { row: 0, col: -1 }, { row: 0, col: 1 }
    ];

    let bestMove: Position | null = null;
    let bestValue = -Infinity;

    for (const dir of directions) {
      const newPos = { row: aiPos.row + dir.row, col: aiPos.col + dir.col };
      if (this.isValidPosition(newPos, gameState)) {
        const value = this.evaluatePosition(newPos, gameState);
        if (value > bestValue) {
          bestValue = value;
          bestMove = newPos;
        }
      }
    }

    return bestMove;
  }

  private evaluatePosition(pos: Position, gameState: GameState): number {
    const treasures = gameState.treasures;
    if (treasures.length === 0) return 0;

    // Calculate distance to nearest treasure
    const minDistance = Math.min(...treasures.map(t => 
      Math.abs(pos.row - t.row) + Math.abs(pos.col - t.col)
    ));

    // Calculate distance to human (prefer positions farther from human)
    const humanDistance = Math.abs(pos.row - gameState.players.human.row) + 
                         Math.abs(pos.col - gameState.players.human.col);

    // Prefer positions closer to treasure and farther from human
    return (10 - minDistance) + (humanDistance * 0.1);
  }

  private getNeighbors(pos: Position): Position[] {
    return [
      { row: pos.row - 1, col: pos.col },
      { row: pos.row + 1, col: pos.col },
      { row: pos.row, col: pos.col - 1 },
      { row: pos.row, col: pos.col + 1 }
    ];
  }

  private isValidPosition(pos: Position, gameState: GameState): boolean {
    // Check bounds
    if (pos.row < 0 || pos.row >= 10 || pos.col < 0 || pos.col >= 10) {
      return false;
    }

    // Check for walls
    if (gameState.walls.some(wall => wall.row === pos.row && wall.col === pos.col)) {
      return false;
    }

    // Check for players
    if ((gameState.players.human.row === pos.row && gameState.players.human.col === pos.col) ||
        (gameState.players.ai.row === pos.row && gameState.players.ai.col === pos.col)) {
      return false;
    }

    return true;
  }

  private isValidPlacement(pos: Position, gameState: GameState): boolean {
    if (!this.isValidPosition(pos, gameState)) return false;

    // Check for other obstacles
    const isOccupied = 
      gameState.treasures.some(treasure => treasure.row === pos.row && treasure.col === pos.col) ||
      gameState.ladders.some(ladder => ladder.row === pos.row && ladder.col === pos.col) ||
      gameState.highCostTiles.some(tile => tile.row === pos.row && tile.col === pos.col) ||
      gameState.trapTiles.some(tile => tile.row === pos.row && tile.col === pos.col) ||
      gameState.powerUps.some(powerUp => powerUp.row === pos.row && powerUp.col === pos.col);

    return !isOccupied;
  }

  private getMoveCost(pos: Position, gameState: GameState): number {
    // Check for ladders - they provide free movement
    if (gameState.ladders.some(ladder => ladder.row === pos.row && ladder.col === pos.col)) {
      return 0.1; // Very low cost to encourage ladder usage
    }

    // Check for high-cost tiles
    if (gameState.highCostTiles.some(tile => tile.row === pos.row && tile.col === pos.col)) {
      return 2;
    }

    return 1;
  }

  private heuristic(a: Position, b: Position): number {
    return Math.abs(a.row - b.row) + Math.abs(a.col - b.col);
  }
}