import React, { useCallback, useState, useEffect } from 'react';
import { GameGrid } from './GameGrid';
import { GameControls } from './GameControls';
import { GameStatus } from './GameStatus';
import { ActionSelector } from './ActionSelector';
import { PowerUpDisplay } from './PowerUpDisplay';
import { LiveStatsPanel } from './LiveStatsPanel';
import { DifficultySelector } from './DifficultySelector';
import { ThemeSelector } from './ThemeSelector';
import { RandomEventsPanel } from './RandomEventsPanel';
import { ParticleSystem } from '../effects/ParticleSystem';

import { AIPanel, AIResult } from './AIPanel';
import { useGameState } from '../../hooks/useGameState';

export const EnhancedGameBoard = () => {
  const {
    gameState,
    currentPlayer,
    setCurrentPlayer,
    gameStatus,
    currentAction,
    setCurrentAction,
    performAction,
    resetGame,
    moveCount,
    activatePowerUp,
    changeDifficulty,
    changeTheme
  } = useGameState();

  const [lastAIResult, setLastAIResult] = useState<AIResult | null>(null);
  const [aiThinking, setAiThinking] = useState(false);

  // Helper functions for strategic AI blocking and placement
  const findOptimalBlockingPosition = (humanPos: any, target: any, gameState: any) => {
    const pathPositions = [];
    const deltaRow = target.row - humanPos.row;
    const deltaCol = target.col - humanPos.col;
    const steps = Math.abs(deltaRow) + Math.abs(deltaCol);
    
    // Generate positions along the optimal path (but not too close to treasure)
    for (let step = 1; step <= Math.min(steps, 4); step++) {
      const progress = step / steps;
      const pathRow = Math.round(humanPos.row + deltaRow * progress);
      const pathCol = Math.round(humanPos.col + deltaCol * progress);
      
      if (pathRow >= 0 && pathRow < 10 && pathCol >= 0 && pathCol < 10) {
        // Don't block positions immediately adjacent to treasures
        const distanceToTreasure = Math.abs(pathRow - target.row) + Math.abs(pathCol - target.col);
        if (distanceToTreasure > 1) {
          pathPositions.push({ row: pathRow, col: pathCol, priority: step === 1 ? 3 : step === 2 ? 2 : 1 });
        }
      }
    }
    
    // Consider positions adjacent to human (but ensure alternative paths exist)
    const adjacentDirections = [
      { row: -1, col: 0 }, { row: 1, col: 0 }, { row: 0, col: -1 }, { row: 0, col: 1 }
    ];
    
    for (const dir of adjacentDirections) {
      const adjPos = { row: humanPos.row + dir.row, col: humanPos.col + dir.col };
      if (adjPos.row >= 0 && adjPos.row < 10 && adjPos.col >= 0 && adjPos.col < 10) {
        const distToTarget = Math.abs(adjPos.row - target.row) + Math.abs(adjPos.col - target.col);
        const humanToTarget = Math.abs(humanPos.row - target.row) + Math.abs(humanPos.col - target.col);
        // Only block if it creates a strategic advantage but doesn't completely isolate
        if (distToTarget < humanToTarget && distToTarget > 1) {
          pathPositions.push({ row: adjPos.row, col: adjPos.col, priority: 2 });
        }
      }
    }
    
    pathPositions.sort((a, b) => b.priority - a.priority);
    
    for (const pos of pathPositions) {
      const isEmpty = !gameState.walls.some((wall: any) => wall.row === pos.row && wall.col === pos.col) &&
                     !gameState.ladders.some((ladder: any) => ladder.row === pos.row && ladder.col === pos.col) &&
                     !gameState.treasures.some((treasure: any) => treasure.row === pos.row && treasure.col === pos.col) &&
                     !(pos.row === gameState.players.human.row && pos.col === gameState.players.human.col) &&
                     !(pos.row === gameState.players.ai.row && pos.col === gameState.players.ai.col);
      
      // Additional check: ensure this wall doesn't completely block all paths to treasures
      if (isEmpty && !wouldCreateDeadlock(pos, gameState)) {
        return pos;
      }
    }
    return null;
  };

  const wouldCreateDeadlock = (wallPos: any, gameState: any) => {
    // Simple check: don't place walls that would surround treasures completely
    const treasures = gameState.treasures;
    
    for (const treasure of treasures) {
      const adjacentPositions = [
        { row: treasure.row - 1, col: treasure.col },
        { row: treasure.row + 1, col: treasure.col },
        { row: treasure.row, col: treasure.col - 1 },
        { row: treasure.row, col: treasure.col + 1 }
      ];
      
      let blockedCount = 0;
      for (const adjPos of adjacentPositions) {
        if (adjPos.row < 0 || adjPos.row >= 10 || adjPos.col < 0 || adjPos.col >= 10) {
          blockedCount++;
          continue;
        }
        
        const isBlocked = gameState.walls.some((wall: any) => wall.row === adjPos.row && wall.col === adjPos.col) ||
                         (wallPos.row === adjPos.row && wallPos.col === adjPos.col);
        
        if (isBlocked) blockedCount++;
      }
      
      // If 3 or more sides of a treasure would be blocked, don't place this wall
      if (blockedCount >= 3) {
        return true;
      }
    }
    
    return false;
  };

  const findAggressiveBlockingPosition = (humanPos: any, target: any, aiPos: any, gameState: any) => {
    const blockingCandidates = [];
    
    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 10; col++) {
        const isOccupied = gameState.walls.some((wall: any) => wall.row === row && wall.col === col) ||
                          gameState.ladders.some((ladder: any) => ladder.row === row && ladder.col === col) ||
                          gameState.treasures.some((treasure: any) => treasure.row === row && treasure.col === col) ||
                          (row === gameState.players.human.row && col === gameState.players.human.col) ||
                          (row === gameState.players.ai.row && col === gameState.players.ai.col);
        
        if (isOccupied) continue;
        
        const distanceToHuman = Math.abs(row - humanPos.row) + Math.abs(col - humanPos.col);
        const distanceToTarget = Math.abs(row - target.row) + Math.abs(col - target.col);
        const humanToTarget = Math.abs(humanPos.row - target.row) + Math.abs(humanPos.col - target.col);
        
        // Ensure we don't block too close to treasures and maintain playability
        if (distanceToHuman >= 1 && distanceToHuman <= 3 && distanceToTarget < humanToTarget && distanceToTarget > 1) {
          const strategicValue = (4 - distanceToHuman) + (humanToTarget - distanceToTarget) * 0.5;
          blockingCandidates.push({ row, col, value: strategicValue });
        }
      }
    }
    
    // Filter out positions that would create deadlocks
    const safeCandidates = blockingCandidates.filter(candidate => 
      !wouldCreateDeadlock({ row: candidate.row, col: candidate.col }, gameState)
    );
    
    safeCandidates.sort((a, b) => b.value - a.value);
    return safeCandidates.length > 0 ? safeCandidates[0] : null;
  };

  const findChokePointToControl = (humanPos: any, target: any, aiPos: any, gameState: any) => {
    const controlCandidates = [];
    
    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 10; col++) {
        const isOccupied = gameState.walls.some((wall: any) => wall.row === row && wall.col === col) ||
                          gameState.ladders.some((ladder: any) => ladder.row === row && ladder.col === col) ||
                          gameState.treasures.some((treasure: any) => treasure.row === row && treasure.col === col) ||
                          (row === gameState.players.human.row && col === gameState.players.human.col) ||
                          (row === gameState.players.ai.row && col === gameState.players.ai.col);
        
        if (isOccupied) continue;
        
        const distanceToHuman = Math.abs(row - humanPos.row) + Math.abs(col - humanPos.col);
        const distanceToTarget = Math.abs(row - target.row) + Math.abs(col - target.col);
        const humanToTarget = Math.abs(humanPos.row - target.row) + Math.abs(humanPos.col - target.col);
        
        if (distanceToHuman <= 5 && distanceToTarget < humanToTarget) {
          const pathProgress = (humanToTarget - distanceToTarget) / humanToTarget;
          const middleBonus = pathProgress > 0.3 && pathProgress < 0.7 ? 2 : 1;
          const controlValue = (6 - distanceToHuman) * middleBonus + (humanToTarget - distanceToTarget);
          controlCandidates.push({ row, col, value: controlValue });
        }
      }
    }
    
    controlCandidates.sort((a, b) => b.value - a.value);
    return controlCandidates.length > 0 ? controlCandidates[0] : null;
  };

  const findStrategicLadderPlacement = (aiPos: any, treasures: any[], gameState: any) => {
    const directions = [
      { row: -1, col: 0 }, { row: 1, col: 0 }, { row: 0, col: -1 }, { row: 0, col: 1 }
    ];
    
    for (const dir of directions) {
      const ladderPos = { row: aiPos.row + dir.row, col: aiPos.col + dir.col };
      
      if (ladderPos.row >= 0 && ladderPos.row < 10 && ladderPos.col >= 0 && ladderPos.col < 10) {
        const isEmpty = !gameState.walls.some((wall: any) => wall.row === ladderPos.row && wall.col === ladderPos.col) &&
                       !gameState.ladders.some((ladder: any) => ladder.row === ladderPos.row && ladder.col === ladderPos.col);
        
        if (isEmpty) return ladderPos;
      }
    }
    return null;
  };

  const findAdvancedLadderPlacement = (aiPos: any, humanPos: any, treasures: any[], gameState: any) => {
    const ladderCandidates = [];
    
    // Look for positions that create shortcuts for AI towards treasures
    for (const treasure of treasures) {
      const directions = [
        { row: -1, col: 0 }, { row: 1, col: 0 }, { row: 0, col: -1 }, { row: 0, col: 1 },
        { row: -1, col: -1 }, { row: -1, col: 1 }, { row: 1, col: -1 }, { row: 1, col: 1 }
      ];
      
      for (const dir of directions) {
        const ladderPos = { row: aiPos.row + dir.row, col: aiPos.col + dir.col };
        
        if (ladderPos.row >= 0 && ladderPos.row < 10 && ladderPos.col >= 0 && ladderPos.col < 10) {
          const isEmpty = !gameState.walls.some((wall: any) => wall.row === ladderPos.row && wall.col === ladderPos.col) &&
                         !gameState.ladders.some((ladder: any) => ladder.row === ladderPos.row && ladder.col === ladderPos.col) &&
                         !gameState.treasures.some((t: any) => t.row === ladderPos.row && t.col === ladderPos.col) &&
                         !(ladderPos.row === gameState.players.human.row && ladderPos.col === gameState.players.human.col);
          
          if (isEmpty) {
            // Calculate strategic value: closer to AI's target treasure, farther from human
            const distanceToTreasure = Math.abs(ladderPos.row - treasure.row) + Math.abs(ladderPos.col - treasure.col);
            const distanceToHuman = Math.abs(ladderPos.row - humanPos.row) + Math.abs(ladderPos.col - humanPos.col);
            const strategicValue = (10 - distanceToTreasure) + (distanceToHuman * 0.5);
            
            ladderCandidates.push({ row: ladderPos.row, col: ladderPos.col, value: strategicValue });
          }
        }
      }
    }
    
    // Sort by strategic value and return best position
    ladderCandidates.sort((a, b) => b.value - a.value);
    return ladderCandidates.length > 0 ? ladderCandidates[0] : null;
  };

  const findOpportunisticBlockingPosition = (humanPos: any, target: any, aiPos: any, gameState: any) => {
    const opportunisticCandidates = [];
    
    // Look for positions that maximize disruption while maintaining AI advantage
    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 10; col++) {
        const pos = { row, col };
        
        const isOccupied = gameState.walls.some((wall: any) => wall.row === row && wall.col === col) ||
                          gameState.ladders.some((ladder: any) => ladder.row === row && ladder.col === col) ||
                          gameState.treasures.some((treasure: any) => treasure.row === row && treasure.col === col) ||
                          (row === gameState.players.human.row && col === gameState.players.human.col) ||
                          (row === gameState.players.ai.row && col === gameState.players.ai.col);
        
        if (isOccupied) continue;
        
        const distanceToHuman = Math.abs(row - humanPos.row) + Math.abs(col - humanPos.col);
        const distanceToTarget = Math.abs(row - target.row) + Math.abs(col - target.col);
        const distanceFromAI = Math.abs(row - aiPos.row) + Math.abs(col - aiPos.col);
        
        // Prefer positions that:
        // 1. Are in human's general direction toward treasure
        // 2. Force longer detours
        // 3. Don't significantly impact AI's own path
        if (distanceToHuman >= 2 && distanceToHuman <= 5 && distanceToTarget > 1 && distanceFromAI >= 3) {
          const disruptionValue = (6 - distanceToHuman) + (distanceToTarget * 0.3) + (distanceFromAI * 0.2);
          opportunisticCandidates.push({ row, col, value: disruptionValue });
        }
      }
    }
    
    opportunisticCandidates.sort((a, b) => b.value - a.value);
    return opportunisticCandidates.length > 0 ? opportunisticCandidates[0] : null;
  };

  // AI Agent Decision Making
  const makeAIMove = useCallback(async () => {
    if (currentPlayer !== 'ai' || gameStatus !== 'playing') return;
    
    setAiThinking(true);
    
    // Difficulty-based thinking time
    const thinkingTime = gameState.difficulty === 'easy' ? 800 : 
                        gameState.difficulty === 'normal' ? 1200 : 1800;
    await new Promise(resolve => setTimeout(resolve, thinkingTime));
    
    const aiPos = gameState.players.ai;
    const humanPos = gameState.players.human;
    const treasures = gameState.treasures;
    
    let aiResult: AIResult;
    
    // Execute difficulty-specific AI behavior
    if (gameState.difficulty === 'easy') {
      aiResult = makeEasyAIMove(aiPos, treasures, gameState);
    } else if (gameState.difficulty === 'normal') {
      aiResult = makeNormalAIMove(aiPos, humanPos, treasures, gameState);
    } else {
      aiResult = makeHardAIMove(aiPos, humanPos, treasures, gameState);
    }

    setLastAIResult(aiResult);
    setAiThinking(false);

    if (aiResult.action === 'move') {
      setTimeout(() => {
        performAction(aiResult.position.row, aiResult.position.col);
      }, 500);
    } else if (aiResult.action === 'place-wall' || aiResult.action === 'place-ladder') {
      setCurrentAction(aiResult.action);
      setTimeout(() => {
        performAction(aiResult.position.row, aiResult.position.col);
      }, 500);
    }
  }, [currentPlayer, gameStatus, gameState, performAction]);

  // Easy AI: Basic pathfinding only, no strategy or blocking
  const makeEasyAIMove = (aiPos: any, treasures: any[], gameState: any): AIResult => {
    const directions = [
      { row: -1, col: 0, name: 'up' },
      { row: 1, col: 0, name: 'down' },
      { row: 0, col: -1, name: 'left' },
      { row: 0, col: 1, name: 'right' }
    ];
    
    const validMoves = directions.map(dir => ({
      row: aiPos.row + dir.row,
      col: aiPos.col + dir.col,
      name: dir.name
    })).filter(pos => 
      pos.row >= 0 && pos.row < 10 && 
      pos.col >= 0 && pos.col < 10 &&
      !gameState.walls.some((wall: any) => wall.row === pos.row && wall.col === pos.col) &&
      !(pos.row === gameState.players.human.row && pos.col === gameState.players.human.col)
    );
    
    if (validMoves.length === 0) {
      return {
        action: 'move',
        position: { row: aiPos.row, col: aiPos.col },
        reasoning: 'Easy AI: No valid moves available',
        confidence: 0.3
      };
    }
    
    // Simple greedy approach: always move towards closest treasure
    let bestMove = validMoves[0];
    let bestDistance = Infinity;
    
    for (const move of validMoves) {
      const distance = Math.min(...treasures.map((t: any) => 
        Math.abs(move.row - t.row) + Math.abs(move.col - t.col)
      ));
      
      if (distance < bestDistance) {
        bestDistance = distance;
        bestMove = move;
      }
    }
    
    return {
      action: 'move',
      position: bestMove,
      reasoning: `Easy AI: Moving ${bestMove.name} directly towards treasure (distance: ${bestDistance})`,
      confidence: 0.5,
      pathLength: bestDistance
    };
  };

  // Normal AI: Strategic movement with basic blocking and terrain awareness
  const makeNormalAIMove = (aiPos: any, humanPos: any, treasures: any[], gameState: any): AIResult => {
    // 30% chance to use walls/ladders for strategic advantage
    if (Math.random() < 0.3 && gameState.playerResources.ai.walls > 0) {
      const blockingPos = findStrategicBlockingPosition(humanPos, treasures, aiPos, gameState);
      if (blockingPos) {
        return {
          action: 'place-wall',
          position: blockingPos,
          reasoning: 'Normal AI: Placing strategic wall to slow human progress',
          confidence: 0.7
        };
      }
    }
    
    if (Math.random() < 0.2 && gameState.playerResources.ai.ladders > 0) {
      const ladderPos = findStrategicLadderPlacement(aiPos, humanPos, treasures, gameState);
      if (ladderPos) {
        return {
          action: 'place-ladder',
          position: ladderPos,
          reasoning: 'Normal AI: Placing ladder for tactical advantage',
          confidence: 0.6
        };
      }
    }
    
    const directions = [
      { row: -1, col: 0, name: 'up' },
      { row: 1, col: 0, name: 'down' },
      { row: 0, col: -1, name: 'left' },
      { row: 0, col: 1, name: 'right' }
    ];
    
    const validMoves = directions.map(dir => ({
      row: aiPos.row + dir.row,
      col: aiPos.col + dir.col,
      name: dir.name
    })).filter(pos => 
      pos.row >= 0 && pos.row < 10 && 
      pos.col >= 0 && pos.col < 10 &&
      !gameState.walls.some((wall: any) => wall.row === pos.row && wall.col === pos.col) &&
      !(pos.row === gameState.players.human.row && pos.col === gameState.players.human.col)
    );
    
    if (validMoves.length === 0) {
      return {
        action: 'move',
        position: { row: aiPos.row, col: aiPos.col },
        reasoning: 'Normal AI: Blocked - analyzing escape routes',
        confidence: 0.4
      };
    }
    
    // Find best treasure to target
    let bestTreasure = treasures[0];
    let bestTreasureCost = Infinity;
    
    for (const treasure of treasures) {
      const cost = Math.abs(aiPos.row - treasure.row) + Math.abs(aiPos.col - treasure.col);
      if (cost < bestTreasureCost) {
        bestTreasureCost = cost;
        bestTreasure = treasure;
      }
    }
    
    // Strategic movement considering terrain costs and human proximity
    let bestMove = validMoves[0];
    let bestScore = -Infinity;
    
    for (const move of validMoves) {
      let score = 0;
      
      // Distance to treasure (closer is better)
      const treasureDistance = Math.abs(move.row - bestTreasure.row) + Math.abs(move.col - bestTreasure.col);
      score += (10 - treasureDistance) * 3;
      
      // Terrain cost consideration
      const isHighCost = gameState.highCostTiles.some((tile: any) => tile.row === move.row && tile.col === move.col);
      if (isHighCost) score -= 2;
      
      // Avoid getting too close to human (basic competition awareness)
      const humanDistance = Math.abs(move.row - humanPos.row) + Math.abs(move.col - humanPos.col);
      if (humanDistance < 2) score -= 3;
      
      if (score > bestScore) {
        bestScore = score;
        bestMove = move;
      }
    }
      
      if (totalCost < bestCost) {
        bestCost = totalCost;
        bestMove = validMove;
        
        if (moveCost > 1) {
          reasoning = `A* pathfinding: avoiding high-cost terrain (cost: ${moveCost})`;
        }
      }
    }
    
    return {
      action: 'move',
      position: bestMove || { row: aiPos.row, col: aiPos.col },
      reasoning,
      confidence: 0.8,
      pathLength: Math.floor(bestCost)
    };
  };

  // Hard AI: Predictive AI with strategic blocking
  const makeHardAIMove = (aiPos: any, humanPos: any, treasures: any[], gameState: any): AIResult => {
    // Find closest treasure to human and AI
    let humanClosest = Infinity;
    let aiClosest = Infinity;
    let humanTarget = null;
    let aiTarget = null;
    
    for (const treasure of treasures) {
      const humanDist = Math.abs(humanPos.row - treasure.row) + Math.abs(humanPos.col - treasure.col);
      const aiDist = Math.abs(aiPos.row - treasure.row) + Math.abs(aiPos.col - treasure.col);
      
      if (humanDist < humanClosest) {
        humanClosest = humanDist;
        humanTarget = treasure;
      }
      if (aiDist < aiClosest) {
        aiClosest = aiDist;
        aiTarget = treasure;
      }
    }
    
    // Enhanced Priority 1: Critical blocking when human is close to treasure
    if (humanClosest <= 4 && gameState.playerResources.ai.walls > 0 && Math.random() < 0.85) {
      const blockPosition = findOptimalBlockingPosition(humanPos, humanTarget, gameState);
      if (blockPosition) {
        return {
          action: 'place-wall',
          position: blockPosition,
          reasoning: `🚧 CRITICAL BLOCK: Human ${humanClosest} steps from treasure! Placing strategic barrier`,
          confidence: 0.95
        };
      }
    }
    
    // Enhanced Priority 2: Aggressive competitive blocking when human is ahead
    if (humanClosest < aiClosest && gameState.playerResources.ai.walls > 0 && Math.random() < 0.75) {
      const blockPosition = findAggressiveBlockingPosition(humanPos, humanTarget, aiPos, gameState);
      if (blockPosition) {
        const advantage = aiClosest - humanClosest;
        return {
          action: 'place-wall',
          position: blockPosition,
          reasoning: `⚔️ SABOTAGE: Human ahead by ${advantage} steps! Disrupting optimal path`,
          confidence: 0.90
        };
      }
    }
    
    // Enhanced Priority 3: Preemptive blocking strategy
    if (humanClosest <= 6 && gameState.playerResources.ai.walls > 0 && Math.random() < 0.6) {
      const chokepoint = findChokePointToControl(humanPos, humanTarget, aiPos, gameState);
      if (chokepoint && !wouldCreateDeadlock(chokepoint, gameState)) {
        return {
          action: 'place-wall',
          position: chokepoint,
          reasoning: '🎯 PREEMPTIVE STRIKE: Controlling key battlefield position',
          confidence: 0.85
        };
      }
    }
    
    // Enhanced Priority 4: Strategic ladder placement for AI advantage
    if (gameState.playerResources.ai.ladders > 0 && Math.random() < 0.7) {
      const ladderPosition = findAdvancedLadderPlacement(aiPos, humanPos, treasures, gameState);
      if (ladderPosition) {
        return {
          action: 'place-ladder',
          position: ladderPosition,
          reasoning: '🪜 TACTICAL SHORTCUT: Creating AI advantage while blocking human',
          confidence: 0.85
        };
      }
    }
    
    // Enhanced Priority 5: Opportunistic blocking based on human movement patterns
    if (gameState.playerResources.ai.walls > 0 && Math.random() < 0.45) {
      const opportunisticBlock = findOpportunisticBlockingPosition(humanPos, humanTarget, aiPos, gameState);
      if (opportunisticBlock && !wouldCreateDeadlock(opportunisticBlock, gameState)) {
        return {
          action: 'place-wall',
          position: opportunisticBlock,
          reasoning: '🔒 OPPORTUNISTIC BLOCK: Capitalizing on human positioning',
          confidence: 0.80
        };
      }
    }
    
    // Priority 5: Advanced movement with human prediction
    return makeAdvancedAIMovement(aiPos, humanPos, treasures, gameState);
  };

  const makeAdvancedAIMovement = (aiPos: any, humanPos: any, treasures: any[], gameState: any): AIResult => {
    const directions = [
      { row: -1, col: 0, name: 'up' },
      { row: 1, col: 0, name: 'down' },
      { row: 0, col: -1, name: 'left' },
      { row: 0, col: 1, name: 'right' }
    ];
    
    const validMoves = directions.map(dir => ({
      row: aiPos.row + dir.row,
      col: aiPos.col + dir.col,
      name: dir.name
    })).filter(pos => 
      pos.row >= 0 && pos.row < 10 && 
      pos.col >= 0 && pos.col < 10 &&
      !gameState.walls.some((wall: any) => wall.row === pos.row && wall.col === pos.col)
    );
    
    if (validMoves.length === 0) {
      return {
        action: 'move',
        position: { row: aiPos.row, col: aiPos.col },
        reasoning: 'AI is trapped - strategically waiting for human move',
        confidence: 0.0
      };
    }
    
    // Advanced pathfinding with human prediction
    let bestMove = null;
    let bestScore = -Infinity;
    let reasoning = "Advanced A* with predictive analysis";
    
    for (const validMove of validMoves) {
      // Calculate move score considering multiple factors
      let score = 0;
      
      // Distance to nearest treasure (negative because closer is better)
      const distanceToTreasure = Math.min(...treasures.map((t: any) => 
        Math.abs(validMove.row - t.row) + Math.abs(validMove.col - t.col)
      ));
      score -= distanceToTreasure * 2;
      
      // Bonus for staying away from human (unless going for treasure)
      const distanceToHuman = Math.abs(validMove.row - humanPos.row) + Math.abs(validMove.col - humanPos.col);
      if (distanceToHuman > 2) score += 1;
      
      // Terrain cost consideration
      const isHighCost = gameState.highCostTiles.some((tile: any) => tile.row === validMove.row && tile.col === validMove.col);
      if (isHighCost) score -= 3;
      
      if (score > bestScore) {
        bestScore = score;
        bestMove = validMove;
        reasoning = `Advanced AI: Optimal move towards treasure (score: ${score.toFixed(1)})`;
      }
    }
    
    return {
      action: 'move',
      position: bestMove || validMoves[0],
      reasoning,
      confidence: 0.9,
      pathLength: Math.abs(bestScore)
    };
  };

  // Auto-execute AI moves
  useEffect(() => {
    if (currentPlayer === 'ai' && gameStatus === 'playing') {
      makeAIMove();
    }
  }, [currentPlayer, gameStatus, makeAIMove]);

  const handleCellClick = useCallback((row: number, col: number) => {
    if (currentPlayer === 'ai' || gameStatus !== 'playing') return;
    
    if (currentAction === 'move') {
      performAction(row, col);
    } else {
      performAction(row, col);
    }
  }, [currentPlayer, currentAction, gameStatus, performAction]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <ParticleSystem 
        theme={gameState.theme}
        intensity="medium"
        gameActive={gameStatus === 'playing'}
      />
      
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-6">
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600 mb-2">
            Treasure Quest Arena
          </h1>
          <p className="text-lg text-gray-600">
            Strategic battle between human intelligence and AI algorithms
          </p>
        </div>
        
        <div className="bg-white rounded-2xl shadow-2xl p-6">
          <div className="flex justify-center mb-6">
            <ThemeSelector 
              currentTheme={gameState.theme}
              onThemeChange={changeTheme}
              disabled={false}
            />
          </div>

      <GameStatus 
        currentPlayer={currentPlayer}
        gameStatus={gameStatus}
        moveCount={moveCount}
      />
      
      <div className="flex flex-col lg:flex-row gap-6">
        <div className="flex-1 space-y-4">
          <ActionSelector
            currentAction={currentAction}
            onActionChange={setCurrentAction}
            gameState={gameState}
            isPlayerTurn={currentPlayer === 'human' && gameStatus === 'playing'}
          />
          
          <PowerUpDisplay
            gameState={gameState}
            currentPlayer={currentPlayer}
            onActivatePowerUp={activatePowerUp}
          />
          
          <GameGrid 
            gameState={gameState}
            onCellClick={handleCellClick}
            currentPlayer={currentPlayer}
            currentAction={currentAction}
          />
        </div>
        
        <div className="lg:w-80 space-y-4">
          <DifficultySelector 
            currentDifficulty={gameState.difficulty}
            onDifficultyChange={changeDifficulty}
            disabled={gameStatus !== 'playing'}
          />
          
          <AIPanel 
            lastAIResult={lastAIResult}
            aiThinking={aiThinking}
          />
          
          <LiveStatsPanel
            gameState={gameState}
            currentPlayer={currentPlayer}
          />
          
          {gameState.lastEvent && (
            <RandomEventsPanel gameState={gameState} />
          )}
        </div>
      </div>
    </div>
      </div>
    </div>
  );
};