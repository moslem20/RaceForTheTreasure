import React from 'react';
import { Badge } from '../ui/badge';
import { GameState, GameAction, ActionType } from '../../lib/game/types';
import { BarChart, TrendingUp, Activity, Target, Timer } from 'lucide-react';

interface GameStatsProps {
  gameState: GameState;
  gameHistory: GameAction[];
}

export const GameStats: React.FC<GameStatsProps> = ({ gameState, gameHistory }) => {
  // Calculate statistics
  const humanActions = gameHistory.filter(action => action.playerId === 'human');
  const aiActions = gameHistory.filter(action => action.playerId === 'ai');
  
  const humanMoves = humanActions.filter(action => action.type === ActionType.MOVE).length;
  const aiMoves = aiActions.filter(action => action.type === ActionType.MOVE).length;
  
  const humanWalls = humanActions.filter(action => action.type === ActionType.PLACE_WALL).length;
  const aiWalls = aiActions.filter(action => action.type === ActionType.PLACE_WALL).length;
  
  const humanLadders = humanActions.filter(action => action.type === ActionType.PLACE_LADDER).length;
  const aiLadders = aiActions.filter(action => action.type === ActionType.PLACE_LADDER).length;

  // Calculate distances to treasure
  const humanDistance = Math.abs(gameState.players.human.position.x - gameState.treasure.x) + 
                       Math.abs(gameState.players.human.position.y - gameState.treasure.y);
  const aiDistance = Math.abs(gameState.players.ai.position.x - gameState.treasure.x) + 
                    Math.abs(gameState.players.ai.position.y - gameState.treasure.y);

  return (
    <div className="p-6 space-y-6">
      <div className="mb-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-orange-500"></div>
          Game Statistics
        </h3>
        <div className="h-0.5 bg-gradient-to-r from-orange-500 to-red-500 rounded-full"></div>
      </div>

      {/* Turn Summary */}
      <div className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl border border-indigo-200/50">
        <div className="flex items-center gap-3 mb-3">
          <Timer className="w-5 h-5 text-indigo-600" />
          <h4 className="font-bold text-gray-800">Turn {gameState.turnNumber}</h4>
        </div>
        <div className="text-center">
          <Badge className="bg-indigo-500 text-white">
            {gameHistory.length} total actions
          </Badge>
        </div>
      </div>

      {/* Distance to Treasure */}
      <div className="space-y-3">
        <h4 className="font-semibold text-gray-700 flex items-center gap-2">
          <Target className="w-4 h-4" />
          Distance to Treasure
        </h4>
        
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl border border-blue-200/50">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{humanDistance}</div>
              <div className="text-xs text-blue-700">Human</div>
            </div>
          </div>
          
          <div className="p-3 bg-gradient-to-r from-red-50 to-red-100 rounded-xl border border-red-200/50">
            <div className="text-center">
              <div className="text-2xl font-bold text-red-600">{aiDistance}</div>
              <div className="text-xs text-red-700">AI</div>
            </div>
          </div>
        </div>
      </div>

      {/* Action Comparison */}
      <div className="space-y-3">
        <h4 className="font-semibold text-gray-700 flex items-center gap-2">
          <BarChart className="w-4 h-4" />
          Action Comparison
        </h4>
        
        {/* Moves */}
        <div className="p-3 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-green-800">Movement</span>
            <Badge variant="secondary" className="text-xs">
              Total: {humanMoves + aiMoves}
            </Badge>
          </div>
          <div className="grid grid-cols-2 gap-2 text-sm">
            <div className="flex justify-between">
              <span className="text-green-600">Human:</span>
              <span className="font-bold text-green-700">{humanMoves}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-green-600">AI:</span>
              <span className="font-bold text-green-700">{aiMoves}</span>
            </div>
          </div>
        </div>

        {/* Tools Used */}
        <div className="p-3 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200/50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-purple-800">Strategic Tools</span>
            <Badge variant="secondary" className="text-xs">
              Total: {humanWalls + aiWalls + humanLadders + aiLadders}
            </Badge>
          </div>
          <div className="space-y-2 text-xs">
            <div className="grid grid-cols-2 gap-2">
              <div className="flex justify-between">
                <span className="text-purple-600">Human Walls:</span>
                <span className="font-bold text-purple-700">{humanWalls}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-purple-600">AI Walls:</span>
                <span className="font-bold text-purple-700">{aiWalls}</span>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="flex justify-between">
                <span className="text-purple-600">Human Ladders:</span>
                <span className="font-bold text-purple-700">{humanLadders}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-purple-600">AI Ladders:</span>
                <span className="font-bold text-purple-700">{aiLadders}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Game Progress */}
      <div className="p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl border border-yellow-200/50">
        <h4 className="font-semibold text-yellow-800 mb-3 flex items-center gap-2">
          <TrendingUp className="w-4 h-4" />
          Game Progress
        </h4>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-yellow-700">Human Efficiency:</span>
            <Badge className="bg-blue-500 text-white text-xs">
              {humanMoves > 0 ? Math.round((humanMoves / (humanMoves + humanWalls + humanLadders)) * 100) : 0}% moves
            </Badge>
          </div>
          
          <div className="flex items-center justify-between text-sm">
            <span className="text-yellow-700">AI Efficiency:</span>
            <Badge className="bg-red-500 text-white text-xs">
              {aiMoves > 0 ? Math.round((aiMoves / (aiMoves + aiWalls + aiLadders)) * 100) : 0}% moves
            </Badge>
          </div>
          
          {/* Who's closer */}
          <div className="mt-3 p-2 bg-white/50 rounded border">
            <div className="text-center text-sm">
              {humanDistance < aiDistance ? (
                <span className="text-blue-600 font-bold">Human is closer to treasure!</span>
              ) : humanDistance > aiDistance ? (
                <span className="text-red-600 font-bold">AI is closer to treasure!</span>
              ) : (
                <span className="text-gray-600 font-bold">Equal distance to treasure!</span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Recent Actions */}
      <div className="space-y-3">
        <h4 className="font-semibold text-gray-700 flex items-center gap-2">
          <Activity className="w-4 h-4" />
          Recent Actions
        </h4>
        
        <div className="max-h-40 overflow-y-auto space-y-2">
          {gameHistory.slice(-5).reverse().map((action, index) => (
            <div key={index} className="p-2 bg-gradient-to-r from-gray-50 to-slate-50 rounded border text-xs">
              <div className="flex items-center justify-between">
                <span className={`font-medium ${action.playerId === 'human' ? 'text-blue-600' : 'text-red-600'}`}>
                  {action.playerId === 'human' ? 'Human' : 'AI'}
                </span>
                <Badge variant="outline" className="text-xs">
                  {action.type.replace('_', ' ').toLowerCase()}
                </Badge>
              </div>
              {action.position && (
                <div className="text-gray-600 mt-1">
                  Position: ({action.position.x}, {action.position.y})
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};