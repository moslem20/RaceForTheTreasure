import React, { useCallback } from 'react';
import { GameGrid } from './GameGrid';
import { GameControls } from './GameControls';
import { GameStatus } from './GameStatus';
import { ActionSelector } from './ActionSelector';
import { PowerUpDisplay } from './PowerUpDisplay';
import { useGameState } from '../../hooks/useGameState';

export const GameBoard = () => {
  const {
    gameState,
    currentPlayer,
    gameStatus,
    currentAction,
    setCurrentAction,
    performAction,
    resetGame,
    moveCount
  } = useGameState();

  const handleCellClick = useCallback((row: number, col: number) => {
    if (gameStatus !== 'playing') return;
    
    const success = performAction(row, col);
    if (success) {
      console.log(`Player ${currentPlayer} performed ${currentAction} at (${row}, ${col})`);
    }
  }, [gameStatus, currentPlayer, currentAction, performAction]);

  return (
    <div className="bg-white rounded-2xl shadow-2xl p-6">
      <GameStatus 
        currentPlayer={currentPlayer}
        gameStatus={gameStatus}
        moveCount={moveCount}
      />
      
      <div className="flex flex-col lg:flex-row gap-6">
        <div className="flex-1 space-y-4">
          <ActionSelector
            currentAction={currentAction}
            onActionChange={setCurrentAction}
            gameState={gameState}
            isPlayerTurn={currentPlayer === 'human' && gameStatus === 'playing'}
          />
          
          <PowerUpDisplay
            gameState={gameState}
            currentPlayer={currentPlayer}
          />
          
          <GameGrid 
            gameState={gameState}
            onCellClick={handleCellClick}
            currentPlayer={currentPlayer}
            currentAction={currentAction}
          />
        </div>
        
        <div className="lg:w-80">
          <GameControls 
            onReset={resetGame}
            gameStatus={gameStatus}
            currentPlayer={currentPlayer}
          />
        </div>
      </div>
    </div>
  );
};