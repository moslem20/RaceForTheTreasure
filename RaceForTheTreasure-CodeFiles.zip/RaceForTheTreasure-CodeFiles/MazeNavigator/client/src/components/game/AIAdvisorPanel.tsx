import React, { useState, useEffect } from 'react';
import { GameState } from '../../types/game';
import { DetailedPerformanceMetrics } from '../../hooks/usePerformanceTracker';
import { Brain, TrendingUp, Target, Lightbulb, ChevronDown, ChevronUp } from 'lucide-react';

interface AIAdvisorPanelProps {
  gameState: GameState;
  performance: DetailedPerformanceMetrics | null;
}

interface AdvisorInsight {
  type: 'strategy' | 'performance' | 'learning' | 'timing';
  title: string;
  description: string;
  confidence: number;
  actionable: boolean;
}

export const AIAdvisorPanel: React.FC<AIAdvisorPanelProps> = ({ gameState, performance }) => {
  const [insights, setInsights] = useState<AdvisorInsight[]>([]);
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['strategy']));
  const [currentRecommendation, setCurrentRecommendation] = useState<string>('');

  useEffect(() => {
    if (performance) {
      generateInsights();
    }
  }, [performance, gameState]);

  const generateInsights = () => {
    if (!performance) return;

    const newInsights: AdvisorInsight[] = [];

    // Strategy insights
    if (performance.averageToolsUsedPerGame < 2) {
      newInsights.push({
        type: 'strategy',
        title: 'Improve Tool Strategy',
        description: `You're using ${performance.averageToolsUsedPerGame.toFixed(1)} tools per game on average. Consider placing walls to block AI paths and ladders to create shortcuts.`,
        confidence: 85,
        actionable: true
      });
    }

    if (performance.explorationCompleteness < 40) {
      newInsights.push({
        type: 'strategy',
        title: 'Explore More Territory',
        description: `You're only exploring ${performance.explorationCompleteness.toFixed(1)}% of the map. Greater exploration reveals better treasure routes and strategic positions.`,
        confidence: 80,
        actionable: true
      });
    }

    if (performance.backtrackingRate > 30) {
      newInsights.push({
        type: 'strategy',
        title: 'Reduce Backtracking',
        description: `${performance.backtrackingRate.toFixed(1)}% of your moves involve backtracking. Plan your route more carefully to improve efficiency.`,
        confidence: 75,
        actionable: true
      });
    }

    // Performance insights
    const totalWins = Object.values(performance.winsByDifficulty).reduce((a, b) => a + b, 0);
    const totalGames = totalWins + Object.values(performance.lossesByDifficulty).reduce((a, b) => a + b, 0);
    const winRate = totalGames > 0 ? (totalWins / totalGames) * 100 : 0;

    if (winRate > 70 && gameState.difficulty === 'easy') {
      newInsights.push({
        type: 'performance',
        title: 'Ready for Higher Difficulty',
        description: `With a ${winRate.toFixed(1)}% win rate on Easy, you're ready for Normal difficulty. This will improve your strategic thinking.`,
        confidence: 90,
        actionable: true
      });
    } else if (winRate < 30 && gameState.difficulty !== 'easy') {
      newInsights.push({
        type: 'performance',
        title: 'Consider Lower Difficulty',
        description: `${winRate.toFixed(1)}% win rate suggests the current difficulty may be too challenging. Lower difficulty helps build confidence.`,
        confidence: 85,
        actionable: true
      });
    }

    // Learning insights
    if (performance.improvementTrend > 20) {
      newInsights.push({
        type: 'learning',
        title: 'Strong Learning Progress',
        description: `Your performance is improving rapidly (${performance.improvementTrend.toFixed(1)}% trend). You're mastering the game mechanics effectively.`,
        confidence: 95,
        actionable: false
      });
    } else if (performance.improvementTrend < -10) {
      newInsights.push({
        type: 'learning',
        title: 'Performance Decline',
        description: 'Recent games show declining performance. Consider taking a break or reviewing successful strategies from earlier games.',
        confidence: 80,
        actionable: true
      });
    }

    // Timing insights
    if (performance.averageThinkingTime > 5000) {
      newInsights.push({
        type: 'timing',
        title: 'Decision Speed',
        description: `Average thinking time is ${(performance.averageThinkingTime / 1000).toFixed(1)}s. While planning is good, faster decisions often lead to better flow.`,
        confidence: 70,
        actionable: true
      });
    }

    // Time-of-day performance
    const bestTimeOfDay = getBestPerformanceTime(performance);
    if (bestTimeOfDay) {
      newInsights.push({
        type: 'timing',
        title: `Peak Performance: ${bestTimeOfDay}`,
        description: `You perform best during ${bestTimeOfDay} hours. Consider scheduling practice sessions during this time.`,
        confidence: 75,
        actionable: true
      });
    }

    setInsights(newInsights);
    
    // Generate current recommendation
    const actionableInsights = newInsights.filter(i => i.actionable);
    if (actionableInsights.length > 0) {
      const topInsight = actionableInsights.reduce((prev, current) => 
        current.confidence > prev.confidence ? current : prev
      );
      setCurrentRecommendation(topInsight.description);
    }
  };

  const getBestPerformanceTime = (performance: DetailedPerformanceMetrics): string | null => {
    const timeSlots = {
      'Morning': performance.morningPerformance,
      'Afternoon': performance.afternoonPerformance,
      'Evening': performance.eveningPerformance
    };

    const bestTime = Object.entries(timeSlots).reduce((best, [time, rate]) => 
      rate > best.rate ? { time, rate } : best
    , { time: '', rate: 0 });

    return bestTime.rate > 0.6 ? bestTime.time : null;
  };

  const toggleSection = (sectionType: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(sectionType)) {
      newExpanded.delete(sectionType);
    } else {
      newExpanded.add(sectionType);
    }
    setExpandedSections(newExpanded);
  };

  const getInsightIcon = (type: string) => {
    switch (type) {
      case 'strategy': return <Target className="w-4 h-4" />;
      case 'performance': return <TrendingUp className="w-4 h-4" />;
      case 'learning': return <Brain className="w-4 h-4" />;
      case 'timing': return <Lightbulb className="w-4 h-4" />;
      default: return <Brain className="w-4 h-4" />;
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 85) return 'text-green-600';
    if (confidence >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const groupedInsights = insights.reduce((groups, insight) => {
    if (!groups[insight.type]) groups[insight.type] = [];
    groups[insight.type].push(insight);
    return groups;
  }, {} as Record<string, AdvisorInsight[]>);

  if (!performance || performance.totalGamesPlayed < 2) {
    return (
      <div className="text-center py-4">
        <Brain className="w-8 h-8 text-gray-400 mx-auto mb-2" />
        <p className="text-sm text-gray-600">Play a few games to unlock AI insights</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Current Recommendation */}
      {currentRecommendation && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <div className="flex items-start gap-2">
            <Lightbulb className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
            <div>
              <h4 className="text-sm font-semibold text-blue-800 mb-1">Current Focus</h4>
              <p className="text-xs text-blue-700">{currentRecommendation}</p>
            </div>
          </div>
        </div>
      )}

      {/* Performance Summary */}
      <div className="bg-gray-50 rounded-lg p-3">
        <div className="grid grid-cols-2 gap-2 text-center">
          <div>
            <div className="text-lg font-bold text-gray-800">
              {((Object.values(performance.winsByDifficulty).reduce((a, b) => a + b, 0) / 
                 Math.max(performance.totalGamesPlayed, 1)) * 100).toFixed(0)}%
            </div>
            <div className="text-xs text-gray-600">Win Rate</div>
          </div>
          <div>
            <div className="text-lg font-bold text-gray-800">
              {performance.totalGamesPlayed}
            </div>
            <div className="text-xs text-gray-600">Games</div>
          </div>
        </div>
      </div>

      {/* Insights by Category */}
      {Object.entries(groupedInsights).map(([type, typeInsights]) => (
        <div key={type} className="border border-gray-200 rounded-lg">
          <button
            onClick={() => toggleSection(type)}
            className="w-full px-3 py-2 flex items-center justify-between text-left hover:bg-gray-50"
          >
            <div className="flex items-center gap-2">
              {getInsightIcon(type)}
              <span className="text-sm font-medium capitalize">{type}</span>
              <span className="text-xs text-gray-500">({typeInsights.length})</span>
            </div>
            {expandedSections.has(type) ? 
              <ChevronUp className="w-4 h-4" /> : 
              <ChevronDown className="w-4 h-4" />
            }
          </button>
          
          {expandedSections.has(type) && (
            <div className="px-3 pb-3 space-y-2 border-t border-gray-100">
              {typeInsights.map((insight, index) => (
                <div key={index} className="bg-white rounded p-2 border">
                  <div className="flex items-center justify-between mb-1">
                    <h5 className="text-xs font-semibold text-gray-800">{insight.title}</h5>
                    <span className={`text-xs ${getConfidenceColor(insight.confidence)}`}>
                      {insight.confidence}%
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 leading-relaxed">{insight.description}</p>
                  {insight.actionable && (
                    <div className="mt-1">
                      <span className="inline-block px-2 py-0.5 bg-blue-100 text-blue-700 text-xs rounded">
                        Actionable
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}

      {insights.length === 0 && (
        <div className="text-center py-4">
          <p className="text-sm text-gray-600">Keep playing to generate more insights!</p>
        </div>
      )}
    </div>
  );
};