import React from 'react';
import { Brain, Target, Zap, Clock } from 'lucide-react';

export interface AIResult {
  action: 'move' | 'place-wall' | 'place-ladder';
  position: { row: number; col: number };
  reasoning: string;
  confidence: number;
  pathLength?: number;
}

interface AIPanelProps {
  lastAIResult: AIResult | null;
  aiThinking: boolean;
}

export const AIPanel: React.FC<AIPanelProps> = ({ lastAIResult, aiThinking }) => {
  return (
    <div className="h-full p-2 bg-gradient-to-br from-red-50 via-orange-50 to-yellow-50 rounded-lg shadow border border-red-200 overflow-hidden">
      <h3 className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-600 to-orange-600 mb-2 flex items-center gap-1">
        <Brain className="w-4 h-4 text-red-500" />
        AI Analysis
      </h3>
      
      {aiThinking && (
        <div className="mb-2 p-2 bg-orange-100 border border-orange-300 rounded-lg">
          <div className="flex items-center gap-2 text-orange-800">
            <div className="w-3 h-3 border-2 border-orange-600 border-t-transparent rounded-full animate-spin"></div>
            <span className="text-xs font-medium">AI thinking...</span>
          </div>
        </div>
      )}
      
      {lastAIResult && !aiThinking && (
        <div className="space-y-2 overflow-y-auto flex-1">
          <div className="p-2 bg-white bg-opacity-70 rounded-lg border border-red-200">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-1">
                <Target className="w-3 h-3 text-red-600" />
                <span className="font-bold text-xs text-red-700 capitalize">
                  {lastAIResult.action.replace('-', ' ')}
                </span>
              </div>
              <div className="text-xs font-medium text-red-600">
                ({lastAIResult.position.row}, {lastAIResult.position.col})
              </div>
            </div>
            
            <div className="text-xs text-slate-700 mb-2 line-clamp-3">
              {lastAIResult.reasoning}
            </div>
            
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-1">
                <Zap className="w-3 h-3 text-amber-500" />
                <span className="text-slate-600">
                  {Math.round(lastAIResult.confidence * 100)}%
                </span>
              </div>
              
              {lastAIResult.pathLength && (
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-blue-500" />
                  <span className="text-slate-600">
                    {lastAIResult.pathLength} steps
                  </span>
                </div>
              )}
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-1 text-xs">
            <div className="p-1 bg-red-100 rounded text-center">
              <div className="font-bold text-red-700">Algorithm</div>
              <div className="text-red-600">A*</div>
            </div>
            <div className="p-1 bg-orange-100 rounded text-center">
              <div className="font-bold text-orange-700">Difficulty</div>
              <div className="text-orange-600">Normal</div>
            </div>
          </div>
        </div>
      )}
      
      {!lastAIResult && !aiThinking && (
        <div className="p-2 text-center text-slate-500">
          <Brain className="w-6 h-6 mx-auto mb-1 opacity-50" />
          <div className="text-xs">Waiting for AI turn...</div>
        </div>
      )}
    </div>
  );
};