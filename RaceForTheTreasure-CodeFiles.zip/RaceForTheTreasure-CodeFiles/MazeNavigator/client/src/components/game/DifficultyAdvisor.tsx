import React, { useEffect, useState } from 'react';
import { GameState } from '../../types/game';
import { Brain, TrendingUp, TrendingDown, Target, Clock, Zap } from 'lucide-react';

interface PlayerPerformance {
  winRate: number;
  averageMovesToWin: number;
  averageGameDuration: number;
  toolUsageEfficiency: number;
  explorationRate: number;
  decisionSpeed: number;
  difficultyHistory: ('easy' | 'normal' | 'hard')[];
  gamesPlayed: number;
}

interface DifficultyRecommendation {
  suggestedDifficulty: 'easy' | 'normal' | 'hard';
  confidence: number;
  reasoning: string[];
  adaptationTips: string[];
  performanceInsights: string[];
}

interface DifficultyAdvisorProps {
  gameState: GameState;
  currentPlayer: 'human' | 'ai';
  gameStatus: 'playing' | 'human-won' | 'ai-won' | 'draw';
  onDifficultyRecommend: (difficulty: 'easy' | 'normal' | 'hard') => void;
}

export const DifficultyAdvisor: React.FC<DifficultyAdvisorProps> = ({
  gameState,
  currentPlayer,
  gameStatus,
  onDifficultyRecommend
}) => {
  const [performance, setPerformance] = useState<PlayerPerformance>({
    winRate: 0,
    averageMovesToWin: 0,
    averageGameDuration: 0,
    toolUsageEfficiency: 0,
    explorationRate: 0,
    decisionSpeed: 0,
    difficultyHistory: [],
    gamesPlayed: 0
  });

  const [recommendation, setRecommendation] = useState<DifficultyRecommendation | null>(null);
  const [showAdvisor, setShowAdvisor] = useState(false);

  // Load performance data from localStorage
  useEffect(() => {
    const savedPerformance = localStorage.getItem('treasureQuest_playerPerformance');
    if (savedPerformance) {
      setPerformance(JSON.parse(savedPerformance));
    }
  }, []);

  // Save performance data when game ends
  useEffect(() => {
    if (gameStatus !== 'playing') {
      updatePerformanceMetrics();
    }
  }, [gameStatus]);

  // Generate recommendations when performance changes
  useEffect(() => {
    if (performance.gamesPlayed >= 2) {
      const newRecommendation = generateDifficultyRecommendation();
      setRecommendation(newRecommendation);
      setShowAdvisor(true);
    }
  }, [performance]);

  const updatePerformanceMetrics = () => {
    const newPerformance = { ...performance };
    newPerformance.gamesPlayed++;
    newPerformance.difficultyHistory.push(gameState.difficulty);
    
    // Update win rate
    if (gameStatus === 'human-won') {
      newPerformance.winRate = (newPerformance.winRate * (newPerformance.gamesPlayed - 1) + 1) / newPerformance.gamesPlayed;
    } else {
      newPerformance.winRate = (newPerformance.winRate * (newPerformance.gamesPlayed - 1)) / newPerformance.gamesPlayed;
    }

    // Update average moves to win (for wins only)
    if (gameStatus === 'human-won') {
      const currentMoves = gameState.gameStats.stepsHuman;
      newPerformance.averageMovesToWin = newPerformance.averageMovesToWin === 0 
        ? currentMoves 
        : (newPerformance.averageMovesToWin + currentMoves) / 2;
    }

    // Calculate tool usage efficiency
    const totalTools = gameState.playerResources.human.walls + gameState.playerResources.human.ladders;
    const toolsUsed = gameState.gameStats.toolsUsed;
    newPerformance.toolUsageEfficiency = totalTools > 0 ? (toolsUsed / totalTools) * 100 : 0;

    // Calculate exploration rate
    newPerformance.explorationRate = (gameState.gameStats.tilesExplored / 100) * 100;

    // Estimate decision speed (moves per turn)
    newPerformance.decisionSpeed = gameState.gameStats.turnCount > 0 
      ? gameState.gameStats.stepsHuman / gameState.gameStats.turnCount 
      : 1;

    setPerformance(newPerformance);
    localStorage.setItem('treasureQuest_playerPerformance', JSON.stringify(newPerformance));
  };

  const generateDifficultyRecommendation = (): DifficultyRecommendation => {
    const reasoning: string[] = [];
    const adaptationTips: string[] = [];
    const performanceInsights: string[] = [];
    let suggestedDifficulty: 'easy' | 'normal' | 'hard' = gameState.difficulty;
    let confidence = 0;

    // Analyze win rate
    if (performance.winRate > 0.7) {
      reasoning.push(`High win rate (${(performance.winRate * 100).toFixed(1)}%) suggests you're ready for more challenge`);
      suggestedDifficulty = gameState.difficulty === 'easy' ? 'normal' : 'hard';
      confidence += 30;
    } else if (performance.winRate < 0.3) {
      reasoning.push(`Lower win rate (${(performance.winRate * 100).toFixed(1)}%) indicates current difficulty might be too challenging`);
      suggestedDifficulty = gameState.difficulty === 'hard' ? 'normal' : 'easy';
      confidence += 25;
    } else {
      reasoning.push(`Balanced win rate (${(performance.winRate * 100).toFixed(1)}%) shows good difficulty match`);
      confidence += 20;
    }

    // Analyze tool usage efficiency
    if (performance.toolUsageEfficiency > 80) {
      reasoning.push(`Excellent tool usage (${performance.toolUsageEfficiency.toFixed(1)}%) shows strategic mastery`);
      adaptationTips.push("Your strategic planning is excellent - try harder AI opponents");
      confidence += 20;
    } else if (performance.toolUsageEfficiency < 40) {
      reasoning.push(`Low tool usage (${performance.toolUsageEfficiency.toFixed(1)}%) suggests room for strategic improvement`);
      adaptationTips.push("Focus on using walls and ladders more strategically");
      confidence += 15;
    }

    // Analyze exploration rate
    if (performance.explorationRate > 70) {
      performanceInsights.push(`High exploration rate (${performance.explorationRate.toFixed(1)}%) shows good map awareness`);
    } else {
      performanceInsights.push(`Exploration rate (${performance.explorationRate.toFixed(1)}%) - try exploring more tiles for better positioning`);
      adaptationTips.push("Explore more of the map to find optimal treasure routes");
    }

    // Analyze decision speed
    if (performance.decisionSpeed > 1.5) {
      performanceInsights.push(`Quick decision making (${performance.decisionSpeed.toFixed(1)} moves/turn) shows good game flow`);
      confidence += 15;
    } else {
      performanceInsights.push(`Take time to plan - faster decisions often lead to better outcomes`);
      adaptationTips.push("Plan your moves in advance to improve efficiency");
    }

    // Analyze difficulty progression
    const recentDifficulties = performance.difficultyHistory.slice(-3);
    const hasProgressed = recentDifficulties.some((diff, index) => 
      index > 0 && diff !== recentDifficulties[index - 1]
    );

    if (!hasProgressed && performance.gamesPlayed > 5) {
      reasoning.push("You've been playing the same difficulty - time to challenge yourself!");
      confidence += 10;
    }

    // Final confidence calculation
    confidence = Math.min(confidence, 95);

    return {
      suggestedDifficulty,
      confidence,
      reasoning,
      adaptationTips,
      performanceInsights
    };
  };

  const handleAcceptRecommendation = () => {
    if (recommendation) {
      onDifficultyRecommend(recommendation.suggestedDifficulty);
      setShowAdvisor(false);
    }
  };

  const handleDismiss = () => {
    setShowAdvisor(false);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-600';
      case 'normal': return 'text-yellow-600';
      case 'hard': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence > 80) return 'text-green-600';
    if (confidence > 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (!showAdvisor || !recommendation || performance.gamesPlayed < 2) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full max-h-[80vh] overflow-y-auto">
        <div className="p-6">
          {/* Header */}
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Brain className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-gray-800">AI Difficulty Advisor</h3>
              <p className="text-sm text-gray-600">Personalized recommendation based on your performance</p>
            </div>
          </div>

          {/* Recommendation */}
          <div className="mb-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-700">Recommended Difficulty:</span>
              <span className={`font-bold text-lg capitalize ${getDifficultyColor(recommendation.suggestedDifficulty)}`}>
                {recommendation.suggestedDifficulty}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-gray-500" />
              <span className="text-sm text-gray-600">
                Confidence: <span className={`font-semibold ${getConfidenceColor(recommendation.confidence)}`}>
                  {recommendation.confidence}%
                </span>
              </span>
            </div>
          </div>

          {/* Performance Insights */}
          <div className="mb-4">
            <h4 className="text-sm font-semibold text-gray-800 mb-2 flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Performance Analysis
            </h4>
            <div className="space-y-2">
              {recommendation.reasoning.map((reason, index) => (
                <div key={index} className="text-sm text-gray-600 pl-2 border-l-2 border-gray-200">
                  {reason}
                </div>
              ))}
            </div>
          </div>

          {/* Player Stats Summary */}
          <div className="mb-4 grid grid-cols-2 gap-3">
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <div className="text-lg font-bold text-gray-800">{(performance.winRate * 100).toFixed(1)}%</div>
              <div className="text-xs text-gray-600">Win Rate</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <div className="text-lg font-bold text-gray-800">{performance.gamesPlayed}</div>
              <div className="text-xs text-gray-600">Games Played</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <div className="text-lg font-bold text-gray-800">{performance.toolUsageEfficiency.toFixed(1)}%</div>
              <div className="text-xs text-gray-600">Tool Efficiency</div>
            </div>
            <div className="text-center p-3 bg-gray-50 rounded-lg">
              <div className="text-lg font-bold text-gray-800">{performance.explorationRate.toFixed(1)}%</div>
              <div className="text-xs text-gray-600">Exploration</div>
            </div>
          </div>

          {/* Adaptation Tips */}
          {recommendation.adaptationTips.length > 0 && (
            <div className="mb-4">
              <h4 className="text-sm font-semibold text-gray-800 mb-2 flex items-center gap-2">
                <Zap className="w-4 h-4" />
                Tips for Improvement
              </h4>
              <div className="space-y-1">
                {recommendation.adaptationTips.map((tip, index) => (
                  <div key={index} className="text-sm text-gray-600 pl-2 border-l-2 border-yellow-200">
                    {tip}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3">
            <button
              onClick={handleAcceptRecommendation}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium transition-colors"
            >
              Apply Recommendation
            </button>
            <button
              onClick={handleDismiss}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Maybe Later
            </button>
          </div>

          {/* Performance Insights */}
          {recommendation.performanceInsights.length > 0 && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <h4 className="text-xs font-semibold text-gray-700 mb-2">Additional Insights</h4>
              <div className="space-y-1">
                {recommendation.performanceInsights.map((insight, index) => (
                  <div key={index} className="text-xs text-gray-500">
                    • {insight}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};