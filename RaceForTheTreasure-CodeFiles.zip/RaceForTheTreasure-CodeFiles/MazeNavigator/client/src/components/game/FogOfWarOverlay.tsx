import React, { useState } from 'react';
import { GameState } from '../../types/game';

interface FogOfWarOverlayProps {
  gameState: GameState;
  currentPlayer: 'human' | 'ai';
}

type FogMode = 'all' | 'explored' | 'visible';

export const FogOfWarOverlay: React.FC<FogOfWarOverlayProps> = ({
  gameState,
  currentPlayer
}) => {
  // Fog of War feature disabled - always show all areas as explored
  return null;

  const getVisibleTiles = (playerPosition: any, range: number = 3) => {
    const visible: any[] = [];
    const centerRow = playerPosition.row;
    const centerCol = playerPosition.col;

    for (let row = centerRow - range; row <= centerRow + range; row++) {
      for (let col = centerCol - range; col <= centerCol + range; col++) {
        if (row >= 0 && row < 10 && col >= 0 && col < 10) {
          visible.push({ row, col });
        }
      }
    }
    return visible;
  };

  const humanVisibleTiles = getVisibleTiles(gameState.players.human);
  const aiVisibleTiles = getVisibleTiles(gameState.players.ai);
  const currentVisibleTiles = currentPlayer === 'human' ? humanVisibleTiles : aiVisibleTiles;

  return (
    <div className="absolute inset-0 pointer-events-none z-10">
      {Array.from({ length: 100 }, (_, index) => {
        const row = Math.floor(index / 10);
        const col = index % 10;
        
        const isVisible = currentVisibleTiles.some(tile => tile.row === row && tile.col === col);
        const isExplored = gameState.visibleTiles[currentPlayer].some(tile => tile.row === row && tile.col === col);
        
        // Apply fog mode filters
        if (fogMode === 'visible' && isVisible) return null;
        if (fogMode === 'explored' && !isExplored) return null;
        if (fogMode === 'all') {
          if (isVisible) return null; // Fully visible, no overlay
        }
        
        return (
          <div
            key={`fog-${row}-${col}`}
            className={`absolute w-12 h-12 rounded-lg transition-all duration-500 ${
              isExplored 
                ? 'bg-gradient-to-br from-slate-400 to-slate-500 bg-opacity-40 backdrop-blur-sm border border-slate-300 border-opacity-20' // Previously seen but now in fog
                : 'bg-gradient-to-br from-gray-800 to-black bg-opacity-80 backdrop-blur-md border border-gray-600 border-opacity-30 animate-pulse' // Never seen
            }`}
            style={{
              left: `${col * 48 + col * 4}px`, // 48px cell + 4px gap
              top: `${row * 48 + row * 4}px`,
              animationDelay: `${(row + col) * 0.05}s`,
            }}
          >
            {!isExplored && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-2 h-2 bg-gray-400 rounded-full opacity-30 animate-ping" 
                     style={{ animationDelay: `${(row * col) * 0.1}s` }} />
              </div>
            )}
            {isExplored && (
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-xs text-slate-300 opacity-50">?</div>
              </div>
            )}
          </div>
        );
      })}
      
      {/* Fog of War Interactive Legend */}
      <div className="absolute bottom-2 left-2 bg-gradient-to-br from-slate-800 to-gray-900 text-white p-3 rounded-2xl shadow-xl border border-slate-600 pointer-events-auto">
        <div className="text-xs font-bold mb-3 text-slate-200">Fog of War</div>
        <div className="space-y-2 text-xs">
          <button
            onClick={() => setFogMode('all')}
            className={`flex items-center gap-2 w-full p-2 rounded-lg transition-all duration-200 ${
              fogMode === 'all' 
                ? 'bg-slate-600 shadow-md' 
                : 'hover:bg-slate-700 opacity-70'
            }`}
          >
            <div className="w-3 h-3 bg-gradient-to-br from-gray-800 to-black rounded border border-gray-600"></div>
            <span className="text-slate-300">Unknown</span>
          </button>
          
          <button
            onClick={() => setFogMode('explored')}
            className={`flex items-center gap-2 w-full p-2 rounded-lg transition-all duration-200 ${
              fogMode === 'explored' 
                ? 'bg-slate-600 shadow-md' 
                : 'hover:bg-slate-700 opacity-70'
            }`}
          >
            <div className="w-3 h-3 bg-gradient-to-br from-slate-400 to-slate-500 bg-opacity-60 rounded border border-slate-300"></div>
            <span className="text-slate-300">Explored</span>
          </button>
          
          <button
            onClick={() => setFogMode('visible')}
            className={`flex items-center gap-2 w-full p-2 rounded-lg transition-all duration-200 ${
              fogMode === 'visible' 
                ? 'bg-slate-600 shadow-md' 
                : 'hover:bg-slate-700 opacity-70'
            }`}
          >
            <div className="w-3 h-3 bg-transparent border border-slate-400 rounded"></div>
            <span className="text-slate-300">Visible</span>
          </button>
        </div>
        
        <div className="mt-3 pt-2 border-t border-slate-600">
          <div className="text-xs text-slate-400">
            Mode: <span className="text-slate-200 font-medium capitalize">{fogMode}</span>
          </div>
        </div>
      </div>
    </div>
  );
};