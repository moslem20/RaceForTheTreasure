import React from 'react';
import { Volume2, VolumeX, Music, Zap } from 'lucide-react';
import { MusicIntensity } from '../../hooks/useAdaptiveSoundtrack';

interface SoundConfig {
  masterVolume: number;
  musicVolume: number;
  sfxVolume: number;
  enabled: boolean;
  manualMode: boolean;
  selectedIntensity: MusicIntensity;
}

interface AudioControlPanelProps {
  soundConfig: SoundConfig;
  currentIntensity: MusicIntensity;
  onConfigChange: (config: Partial<SoundConfig>) => void;
  onInitialize: () => void;
}

export const AudioControlPanel: React.FC<AudioControlPanelProps> = ({
  soundConfig,
  currentIntensity,
  onConfigChange,
  onInitialize
}) => {
  const getIntensityColor = (intensity: MusicIntensity): string => {
    switch (intensity) {
      case 'ambient': return 'text-blue-600 bg-blue-100';
      case 'tension': return 'text-yellow-600 bg-yellow-100';
      case 'action': return 'text-red-600 bg-red-100';
      case 'victory': return 'text-green-600 bg-green-100';
      case 'defeat': return 'text-gray-600 bg-gray-100';
      default: return 'text-blue-600 bg-blue-100';
    }
  };

  const getIntensityDescription = (intensity: MusicIntensity): string => {
    switch (intensity) {
      case 'ambient': return 'Calm exploration music';
      case 'tension': return 'Suspenseful competition music';
      case 'action': return 'High-energy battle music';
      case 'victory': return 'Triumphant victory music';
      case 'defeat': return 'Somber defeat music';
      default: return 'Background music';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm border p-4">
      <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
        <Music className="w-4 h-4" />
        Adaptive Soundtrack
      </h3>

      {/* Audio Enable/Disable */}
      <div className="mb-4">
        <button
          onClick={() => {
            if (!soundConfig.enabled) {
              onInitialize(); // Initialize audio context
            }
            onConfigChange({ enabled: !soundConfig.enabled });
          }}
          className={`w-full flex items-center justify-center gap-2 p-2 rounded-lg transition-all duration-200 ${
            soundConfig.enabled
              ? 'bg-green-100 text-green-700 hover:bg-green-200'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          {soundConfig.enabled ? (
            <>
              <Volume2 className="w-4 h-4" />
              Audio Enabled
            </>
          ) : (
            <>
              <VolumeX className="w-4 h-4" />
              Audio Disabled
            </>
          )}
        </button>
      </div>

      {soundConfig.enabled && (
        <>
          {/* Music Control Mode Toggle */}
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-gray-600">Music Control</label>
              <button
                onClick={() => onConfigChange({ manualMode: !soundConfig.manualMode })}
                className={`px-3 py-1 rounded text-xs font-medium transition-colors ${
                  soundConfig.manualMode
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {soundConfig.manualMode ? 'Manual' : 'Auto'}
              </button>
            </div>
            
            {soundConfig.manualMode ? (
              <div className="space-y-2">
                <label className="text-xs text-gray-600 block">Choose Music Type:</label>
                
                {/* Quick Preset Buttons */}
                <div className="grid grid-cols-2 gap-2 mb-3">
                  <button
                    onClick={() => onConfigChange({ selectedIntensity: 'ambient' })}
                    className={`p-2 rounded text-xs font-medium transition-colors ${
                      soundConfig.selectedIntensity === 'ambient'
                        ? 'bg-blue-500 text-white'
                        : 'bg-blue-100 text-blue-700 hover:bg-blue-200'
                    }`}
                  >
                    🌊 Chill
                  </button>
                  <button
                    onClick={() => onConfigChange({ selectedIntensity: 'action' })}
                    className={`p-2 rounded text-xs font-medium transition-colors ${
                      soundConfig.selectedIntensity === 'action'
                        ? 'bg-red-500 text-white'
                        : 'bg-red-100 text-red-700 hover:bg-red-200'
                    }`}
                  >
                    ⚡ Epic
                  </button>
                </div>

                {/* Detailed Music Selection */}
                {(['ambient', 'tension', 'action', 'victory', 'defeat'] as MusicIntensity[]).map((intensity) => (
                  <button
                    key={intensity}
                    onClick={() => onConfigChange({ selectedIntensity: intensity })}
                    className={`w-full p-2 rounded text-left text-xs transition-colors ${
                      soundConfig.selectedIntensity === intensity
                        ? getIntensityColor(intensity)
                        : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="capitalize font-medium">{intensity}</span>
                      <span className="opacity-70">{getIntensityDescription(intensity)}</span>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              <div className={`p-2 rounded-lg flex items-center gap-2 ${getIntensityColor(currentIntensity)}`}>
                <Zap className="w-4 h-4" />
                <div>
                  <div className="font-medium capitalize">{currentIntensity}</div>
                  <div className="text-xs opacity-80">{getIntensityDescription(currentIntensity)}</div>
                </div>
              </div>
            )}
          </div>

          {/* Volume Controls */}
          <div className="space-y-3">
            {/* Master Volume */}
            <div>
              <label className="text-xs font-medium text-gray-600 mb-1 block">
                Master Volume ({Math.round(soundConfig.masterVolume * 100)}%)
              </label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={soundConfig.masterVolume}
                onChange={(e) => onConfigChange({ masterVolume: parseFloat(e.target.value) })}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            {/* Music Volume */}
            <div>
              <label className="text-xs font-medium text-gray-600 mb-1 block">
                Music Volume ({Math.round(soundConfig.musicVolume * 100)}%)
              </label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={soundConfig.musicVolume}
                onChange={(e) => onConfigChange({ musicVolume: parseFloat(e.target.value) })}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
            </div>

            {/* SFX Volume */}
            <div>
              <label className="text-xs font-medium text-gray-600 mb-1 block">
                Sound Effects ({Math.round(soundConfig.sfxVolume * 100)}%)
              </label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={soundConfig.sfxVolume}
                onChange={(e) => onConfigChange({ sfxVolume: parseFloat(e.target.value) })}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
            </div>
          </div>

          {/* Music Intensity Levels */}
          <div className="mt-4">
            <label className="text-xs font-medium text-gray-600 mb-2 block">
              Music Intensity Levels
            </label>
            <div className="space-y-1">
              {(['ambient', 'tension', 'action', 'victory', 'defeat'] as MusicIntensity[]).map((intensity) => (
                <div
                  key={intensity}
                  className={`p-2 rounded text-xs flex items-center justify-between ${
                    currentIntensity === intensity
                      ? getIntensityColor(intensity)
                      : 'bg-gray-50 text-gray-600'
                  }`}
                >
                  <span className="capitalize font-medium">{intensity}</span>
                  <span className="opacity-70">{getIntensityDescription(intensity)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-3 p-2 bg-purple-50 rounded text-xs text-purple-700">
            {soundConfig.manualMode ? (
              <>🎵 Manual mode: Choose your preferred music type from the options above</>
            ) : (
              <>🎵 Auto mode: Music adapts to game events and player proximity to treasures</>
            )}
          </div>
        </>
      )}
    </div>
  );
};