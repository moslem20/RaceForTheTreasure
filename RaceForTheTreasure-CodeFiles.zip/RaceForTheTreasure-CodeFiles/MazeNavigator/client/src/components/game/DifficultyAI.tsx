import { AIResult } from './AIPanel';

export const createDifficultyAI = () => {
  // Easy AI: Basic pathfinding only, no strategy
  const makeEasyAIMove = (aiPos: any, treasures: any[], gameState: any): AIResult => {
    const directions = [
      { row: -1, col: 0, name: 'up' },
      { row: 1, col: 0, name: 'down' },
      { row: 0, col: -1, name: 'left' },
      { row: 0, col: 1, name: 'right' }
    ];
    
    const validMoves = directions.map(dir => ({
      row: aiPos.row + dir.row,
      col: aiPos.col + dir.col,
      name: dir.name
    })).filter(pos => 
      pos.row >= 0 && pos.row < 10 && 
      pos.col >= 0 && pos.col < 10 &&
      !gameState.walls.some((wall: any) => wall.row === pos.row && wall.col === pos.col) &&
      !(pos.row === gameState.players.human.row && pos.col === gameState.players.human.col)
    );
    
    if (validMoves.length === 0) {
      return {
        action: 'move',
        position: { row: aiPos.row, col: aiPos.col },
        reasoning: 'Easy AI: No valid moves available',
        confidence: 0.3
      };
    }
    
    // Simple greedy approach: move towards closest treasure
    let bestMove = validMoves[0];
    let bestDistance = Infinity;
    
    for (const move of validMoves) {
      const distance = Math.min(...treasures.map((t: any) => 
        Math.abs(move.row - t.row) + Math.abs(move.col - t.col)
      ));
      
      if (distance < bestDistance) {
        bestDistance = distance;
        bestMove = move;
      }
    }
    
    return {
      action: 'move',
      position: bestMove,
      reasoning: `Easy AI: Moving ${bestMove.name} towards treasure (${bestDistance} steps away)`,
      confidence: 0.5,
      pathLength: bestDistance
    };
  };

  // Normal AI: Strategic movement with occasional blocking
  const makeNormalAIMove = (aiPos: any, humanPos: any, treasures: any[], gameState: any): AIResult => {
    // 25% chance to place walls for blocking
    if (Math.random() < 0.25 && gameState.playerResources.ai.walls > 0) {
      const blockingPos = findBasicBlockingPosition(humanPos, treasures, gameState);
      if (blockingPos) {
        return {
          action: 'place-wall',
          position: blockingPos,
          reasoning: 'Normal AI: Placing strategic wall to hinder human progress',
          confidence: 0.7
        };
      }
    }
    
    // 15% chance to place ladders for shortcuts
    if (Math.random() < 0.15 && gameState.playerResources.ai.ladders > 0) {
      const ladderPos = findBasicLadderPosition(aiPos, treasures, gameState);
      if (ladderPos) {
        return {
          action: 'place-ladder',
          position: ladderPos,
          reasoning: 'Normal AI: Placing ladder for tactical advantage',
          confidence: 0.6
        };
      }
    }
    
    const directions = [
      { row: -1, col: 0, name: 'up' },
      { row: 1, col: 0, name: 'down' },
      { row: 0, col: -1, name: 'left' },
      { row: 0, col: 1, name: 'right' }
    ];
    
    const validMoves = directions.map(dir => ({
      row: aiPos.row + dir.row,
      col: aiPos.col + dir.col,
      name: dir.name
    })).filter(pos => 
      pos.row >= 0 && pos.row < 10 && 
      pos.col >= 0 && pos.col < 10 &&
      !gameState.walls.some((wall: any) => wall.row === pos.row && wall.col === pos.col) &&
      !(pos.row === gameState.players.human.row && pos.col === gameState.players.human.col)
    );
    
    if (validMoves.length === 0) {
      return {
        action: 'move',
        position: { row: aiPos.row, col: aiPos.col },
        reasoning: 'Normal AI: Blocked - seeking alternative routes',
        confidence: 0.4
      };
    }
    
    // Strategic movement considering terrain and competition
    let bestMove = validMoves[0];
    let bestScore = -Infinity;
    
    for (const move of validMoves) {
      let score = 0;
      
      // Distance to closest treasure
      const treasureDistance = Math.min(...treasures.map((t: any) => 
        Math.abs(move.row - t.row) + Math.abs(move.col - t.col)
      ));
      score += (15 - treasureDistance) * 2;
      
      // Avoid high-cost terrain
      const isHighCost = gameState.highCostTiles.some((tile: any) => 
        tile.row === move.row && tile.col === move.col);
      if (isHighCost) score -= 3;
      
      // Competition awareness - avoid human proximity
      const humanDistance = Math.abs(move.row - humanPos.row) + Math.abs(move.col - humanPos.col);
      if (humanDistance < 2) score -= 2;
      if (humanDistance === 1) score -= 5; // Strongly avoid adjacent positions
      
      if (score > bestScore) {
        bestScore = score;
        bestMove = move;
      }
    }
    
    return {
      action: 'move',
      position: bestMove,
      reasoning: `Normal AI: Strategic move ${bestMove.name} (score: ${Math.round(bestScore)})`,
      confidence: 0.75,
      pathLength: Math.min(...treasures.map((t: any) => 
        Math.abs(bestMove.row - t.row) + Math.abs(bestMove.col - t.col)
      ))
    };
  };

  // Hard AI: Advanced strategic AI with predictive blocking
  const makeHardAIMove = (aiPos: any, humanPos: any, treasures: any[], gameState: any): AIResult => {
    // Analyze treasure competition
    const treasureAnalysis = treasures.map((treasure: any) => ({
      treasure,
      humanDistance: Math.abs(humanPos.row - treasure.row) + Math.abs(humanPos.col - treasure.col),
      aiDistance: Math.abs(aiPos.row - treasure.row) + Math.abs(aiPos.col - treasure.col)
    }));
    
    // 50% chance for strategic wall placement
    if (Math.random() < 0.5 && gameState.playerResources.ai.walls > 0) {
      const criticalBlockingPos = findCriticalBlockingPosition(humanPos, treasureAnalysis, aiPos, gameState);
      if (criticalBlockingPos) {
        return {
          action: 'place-wall',
          position: criticalBlockingPos,
          reasoning: 'Hard AI: Critical blocking - disrupting human optimal path',
          confidence: 0.9
        };
      }
    }
    
    // 35% chance for advanced ladder placement
    if (Math.random() < 0.35 && gameState.playerResources.ai.ladders > 0) {
      const advancedLadderPos = findAdvancedLadderPosition(aiPos, humanPos, treasureAnalysis, gameState);
      if (advancedLadderPos) {
        return {
          action: 'place-ladder',
          position: advancedLadderPos,
          reasoning: 'Hard AI: Advanced positioning - creating strategic shortcuts',
          confidence: 0.85
        };
      }
    }
    
    const directions = [
      { row: -1, col: 0, name: 'up' },
      { row: 1, col: 0, name: 'down' },
      { row: 0, col: -1, name: 'left' },
      { row: 0, col: 1, name: 'right' }
    ];
    
    const validMoves = directions.map(dir => ({
      row: aiPos.row + dir.row,
      col: aiPos.col + dir.col,
      name: dir.name
    })).filter(pos => 
      pos.row >= 0 && pos.row < 10 && 
      pos.col >= 0 && pos.col < 10 &&
      !gameState.walls.some((wall: any) => wall.row === pos.row && wall.col === pos.col) &&
      !(pos.row === gameState.players.human.row && pos.col === gameState.players.human.col)
    );
    
    if (validMoves.length === 0) {
      return {
        action: 'move',
        position: { row: aiPos.row, col: aiPos.col },
        reasoning: 'Hard AI: Tactically blocked - recalculating strategy',
        confidence: 0.3
      };
    }
    
    // Advanced predictive movement
    let bestMove = validMoves[0];
    let bestScore = -Infinity;
    
    for (const move of validMoves) {
      let score = 0;
      
      // Multi-treasure strategy
      for (const analysis of treasureAnalysis) {
        const newAIDistance = Math.abs(move.row - analysis.treasure.row) + Math.abs(move.col - analysis.treasure.col);
        
        // Prioritize treasures where AI has advantage
        if (newAIDistance < analysis.humanDistance) {
          score += (20 - newAIDistance) * 3; // High weight for advantageous treasures
        } else if (newAIDistance === analysis.humanDistance) {
          score += (15 - newAIDistance) * 2; // Competitive treasures
        } else {
          score += (10 - newAIDistance) * 1; // Disadvantageous treasures
        }
      }
      
      // Advanced terrain analysis
      const isHighCost = gameState.highCostTiles.some((tile: any) => 
        tile.row === move.row && tile.col === move.col);
      const isTrap = gameState.trapTiles.some((trap: any) => 
        trap.row === move.row && trap.col === move.col);
      
      if (isHighCost) score -= 4;
      if (isTrap) score -= 8; // Strongly avoid traps
      
      // Predictive human movement analysis
      const humanDistance = Math.abs(move.row - humanPos.row) + Math.abs(move.col - humanPos.col);
      if (humanDistance === 1) score -= 10; // Avoid direct confrontation
      if (humanDistance === 2) score -= 3;  // Maintain tactical distance
      if (humanDistance > 6) score += 2;    // Bonus for strategic positioning
      
      // Power-up consideration
      const nearPowerUp = gameState.powerUps.some((powerUp: any) => 
        Math.abs(move.row - powerUp.row) + Math.abs(move.col - powerUp.col) <= 2);
      if (nearPowerUp) score += 5;
      
      if (score > bestScore) {
        bestScore = score;
        bestMove = move;
      }
    }
    
    return {
      action: 'move',
      position: bestMove,
      reasoning: `Hard AI: Predictive strategy ${bestMove.name} (tactical score: ${Math.round(bestScore)})`,
      confidence: 0.95,
      pathLength: Math.min(...treasures.map((t: any) => 
        Math.abs(bestMove.row - t.row) + Math.abs(bestMove.col - t.col)
      ))
    };
  };

  // Helper functions for AI strategies
  const findBasicBlockingPosition = (humanPos: any, treasures: any[], gameState: any) => {
    for (const treasure of treasures) {
      // Simple blocking: place walls between human and treasure
      const directions = [
        { row: -1, col: 0 }, { row: 1, col: 0 }, { row: 0, col: -1 }, { row: 0, col: 1 }
      ];
      
      for (const dir of directions) {
        const pos = { row: humanPos.row + dir.row, col: humanPos.col + dir.col };
        
        if (pos.row >= 0 && pos.row < 10 && pos.col >= 0 && pos.col < 10) {
          const isEmpty = !gameState.walls.some((wall: any) => wall.row === pos.row && wall.col === pos.col) &&
                         !gameState.treasures.some((t: any) => t.row === pos.row && t.col === pos.col) &&
                         !(pos.row === gameState.players.ai.row && pos.col === gameState.players.ai.col);
          
          if (isEmpty) return pos;
        }
      }
    }
    return null;
  };

  const findBasicLadderPosition = (aiPos: any, treasures: any[], gameState: any) => {
    // Place ladders near AI for shortcuts
    const directions = [
      { row: -1, col: 0 }, { row: 1, col: 0 }, { row: 0, col: -1 }, { row: 0, col: 1 }
    ];
    
    for (const dir of directions) {
      const pos = { row: aiPos.row + dir.row, col: aiPos.col + dir.col };
      
      if (pos.row >= 0 && pos.row < 10 && pos.col >= 0 && pos.col < 10) {
        const isEmpty = !gameState.walls.some((wall: any) => wall.row === pos.row && wall.col === pos.col) &&
                       !gameState.ladders.some((ladder: any) => ladder.row === pos.row && ladder.col === pos.col) &&
                       !gameState.treasures.some((t: any) => t.row === pos.row && t.col === pos.col) &&
                       !(pos.row === gameState.players.human.row && pos.col === gameState.players.human.col);
        
        if (isEmpty) return pos;
      }
    }
    return null;
  };

  const findCriticalBlockingPosition = (humanPos: any, treasureAnalysis: any[], aiPos: any, gameState: any) => {
    // Find the treasure human is closest to and block their path
    const humanTarget = treasureAnalysis.reduce((closest, current) => 
      current.humanDistance < closest.humanDistance ? current : closest
    );
    
    // Calculate path blocking positions
    const dx = humanTarget.treasure.row - humanPos.row;
    const dy = humanTarget.treasure.col - humanPos.col;
    
    const blockingCandidates = [];
    
    // Block direct path
    const stepX = dx === 0 ? 0 : (dx > 0 ? 1 : -1);
    const stepY = dy === 0 ? 0 : (dy > 0 ? 1 : -1);
    
    for (let i = 1; i <= 3; i++) {
      const pos = { 
        row: humanPos.row + (stepX * i), 
        col: humanPos.col + (stepY * i) 
      };
      
      if (pos.row >= 0 && pos.row < 10 && pos.col >= 0 && pos.col < 10) {
        const isEmpty = !gameState.walls.some((wall: any) => wall.row === pos.row && wall.col === pos.col) &&
                       !gameState.treasures.some((t: any) => t.row === pos.row && t.col === pos.col) &&
                       !(pos.row === gameState.players.ai.row && pos.col === gameState.players.ai.col);
        
        if (isEmpty) {
          const distanceToAI = Math.abs(pos.row - aiPos.row) + Math.abs(pos.col - aiPos.col);
          blockingCandidates.push({ ...pos, priority: 10 - i - (distanceToAI * 0.5) });
        }
      }
    }
    
    // Return best blocking position
    blockingCandidates.sort((a, b) => b.priority - a.priority);
    return blockingCandidates.length > 0 ? blockingCandidates[0] : null;
  };

  const findAdvancedLadderPosition = (aiPos: any, humanPos: any, treasureAnalysis: any[], gameState: any) => {
    // Find optimal ladder placement for AI advantage
    const aiTarget = treasureAnalysis.reduce((closest, current) => 
      current.aiDistance < closest.aiDistance ? current : closest
    );
    
    const ladderCandidates = [];
    
    // Look for positions that create shortcuts towards AI's target
    const directions = [
      { row: -2, col: 0 }, { row: 2, col: 0 }, { row: 0, col: -2 }, { row: 0, col: 2 },
      { row: -1, col: -1 }, { row: -1, col: 1 }, { row: 1, col: -1 }, { row: 1, col: 1 }
    ];
    
    for (const dir of directions) {
      const pos = { row: aiPos.row + dir.row, col: aiPos.col + dir.col };
      
      if (pos.row >= 0 && pos.row < 10 && pos.col >= 0 && pos.col < 10) {
        const isEmpty = !gameState.walls.some((wall: any) => wall.row === pos.row && wall.col === pos.col) &&
                       !gameState.ladders.some((ladder: any) => ladder.row === pos.row && ladder.col === pos.col) &&
                       !gameState.treasures.some((t: any) => t.row === pos.row && t.col === pos.col) &&
                       !(pos.row === gameState.players.human.row && pos.col === gameState.players.human.col);
        
        if (isEmpty) {
          const treasureDistance = Math.abs(pos.row - aiTarget.treasure.row) + Math.abs(pos.col - aiTarget.treasure.col);
          const humanDistance = Math.abs(pos.row - humanPos.row) + Math.abs(pos.col - humanPos.col);
          const strategicValue = (15 - treasureDistance) + (humanDistance * 0.3);
          
          ladderCandidates.push({ ...pos, value: strategicValue });
        }
      }
    }
    
    ladderCandidates.sort((a, b) => b.value - a.value);
    return ladderCandidates.length > 0 ? ladderCandidates[0] : null;
  };

  return {
    makeEasyAIMove,
    makeNormalAIMove,
    makeHardAIMove
  };
};