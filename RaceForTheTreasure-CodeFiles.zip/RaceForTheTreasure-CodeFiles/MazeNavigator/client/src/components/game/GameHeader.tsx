import React from 'react';
import { Trophy, Users, Brain } from 'lucide-react';

export const GameHeader = () => {
  return (
    <div className="text-center mb-8">
      <div className="flex items-center justify-center gap-3 mb-4">
        <Trophy className="w-8 h-8 text-amber-500" />
        <h1 className="text-4xl font-bold text-slate-800">Treasure Hunt Strategy</h1>
        <Trophy className="w-8 h-8 text-amber-500" />
      </div>
      <p className="text-lg text-slate-600 max-w-2xl mx-auto">
        A strategic grid-based game where human intelligence meets AI algorithms. 
        Race to reach the treasure first using smart moves and tactical decisions!
      </p>
      <div className="flex items-center justify-center gap-8 mt-6">
        <div className="flex items-center gap-2">
          <Users className="w-5 h-5 text-blue-500" />
          <span className="text-sm font-medium text-slate-700">Human vs AI</span>
        </div>
        <div className="flex items-center gap-2">
          <Brain className="w-5 h-5 text-purple-500" />
          <span className="text-sm font-medium text-slate-700">Advanced Algorithms</span>
        </div>
      </div>
    </div>
  );
};