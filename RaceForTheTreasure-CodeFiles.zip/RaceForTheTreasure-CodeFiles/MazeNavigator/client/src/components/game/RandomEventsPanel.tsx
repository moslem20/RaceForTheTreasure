import React from 'react';
import { Zap, Waves, Mountain, Gift, AlertTriangle, Clock } from 'lucide-react';
import { GameState, RandomEvent } from '../../types/game';

interface RandomEventsPanelProps {
  gameState: GameState;
  onTriggerEvent?: () => void;
}

export const RandomEventsPanel: React.FC<RandomEventsPanelProps> = ({
  gameState,
  onTriggerEvent
}) => {
  const getEventIcon = (eventType: RandomEvent['type']) => {
    switch (eventType) {
      case 'flood':
        return <Waves className="w-5 h-5 text-blue-500" />;
      case 'lightning':
        return <Zap className="w-5 h-5 text-yellow-500" />;
      case 'earthquake':
        return <Mountain className="w-5 h-5 text-orange-500" />;
      case 'bonus':
        return <Gift className="w-5 h-5 text-green-500" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-gray-500" />;
    }
  };

  const getEventColor = (eventType: RandomEvent['type']) => {
    switch (eventType) {
      case 'flood':
        return 'bg-blue-50 border-blue-200 text-blue-800';
      case 'lightning':
        return 'bg-yellow-50 border-yellow-200 text-yellow-800';
      case 'earthquake':
        return 'bg-orange-50 border-orange-200 text-orange-800';
      case 'bonus':
        return 'bg-green-50 border-green-200 text-green-800';
      default:
        return 'bg-gray-50 border-gray-200 text-gray-800';
    }
  };

  const possibleEvents = [
    {
      type: 'flood' as const,
      name: 'Rising Flood',
      description: '3 random tiles turn to water',
      probability: '15%'
    },
    {
      type: 'lightning' as const,
      name: 'Lightning Strike',
      description: 'Destroys one random wall',
      probability: '10%'
    },
    {
      type: 'earthquake' as const,
      name: 'Earthquake',
      description: 'Shifts walls and creates new obstacles',
      probability: '8%'
    },
    {
      type: 'bonus' as const,
      name: 'Treasure Surge',
      description: 'Spawns extra power-ups',
      probability: '12%'
    }
  ];

  return (
    <div className="h-full p-2 bg-gradient-to-br from-orange-50 via-red-50 to-yellow-50 rounded-lg shadow border border-orange-300 overflow-hidden">
      <h3 className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-red-600 mb-2 flex items-center gap-1">
        <AlertTriangle className="w-4 h-4 text-orange-500" />
        Events
      </h3>

      {gameState.lastEvent && (
        <div className={`p-4 rounded-2xl border-3 mb-6 shadow-lg transform hover:scale-105 transition-all duration-300 ${getEventColor(gameState.lastEvent.type)}`}>
          <div className="flex items-center gap-3 mb-3">
            <div className="p-2 bg-white rounded-full shadow-md">
              {getEventIcon(gameState.lastEvent.type)}
            </div>
            <span className="font-bold text-lg">Recent Event</span>
          </div>
          <p className="text-sm font-medium mb-2">{gameState.lastEvent.description}</p>
          <p className="text-xs bg-white bg-opacity-50 px-2 py-1 rounded-full inline-block">
            Triggered on turn {gameState.lastEvent.turnTriggered}
          </p>
        </div>
      )}

      <div className="space-y-4">
        <h4 className="font-bold text-slate-800 text-lg bg-gradient-to-r from-purple-100 to-pink-100 p-3 rounded-2xl border-2 border-purple-300">
          Possible Events (Every 5 turns)
        </h4>
        {possibleEvents.map((event, index) => (
          <div 
            key={event.type} 
            className="flex items-center gap-4 p-4 bg-gradient-to-r from-slate-100 to-gray-100 rounded-2xl border-2 border-slate-300 shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <div className="p-3 bg-white rounded-full shadow-md">
              {getEventIcon(event.type)}
            </div>
            <div className="flex-1">
              <div className="font-bold text-base text-slate-800">{event.name}</div>
              <div className="text-sm text-slate-600 mt-1">{event.description}</div>
            </div>
            <div className="text-sm font-bold text-white bg-gradient-to-r from-purple-500 to-pink-500 px-3 py-2 rounded-full shadow-md">
              {event.probability}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-gradient-to-r from-purple-100 to-indigo-100 rounded-2xl border-2 border-purple-300 shadow-lg">
        <h4 className="font-bold text-purple-800 mb-3 flex items-center gap-2">
          <Clock className="w-5 h-5 animate-spin" />
          Event Timing
        </h4>
        <div className="text-sm text-purple-700 space-y-2">
          <p className="bg-white bg-opacity-50 p-2 rounded-lg">
            Events trigger automatically every 5 turns
          </p>
          <p className="bg-white bg-opacity-50 p-2 rounded-lg font-medium">
            Next event possible on turn: <span className="text-purple-900 font-bold">{Math.ceil((gameState.gameStats.turnCount + 1) / 5) * 5}</span>
          </p>
        </div>
      </div>
    </div>
  );
};