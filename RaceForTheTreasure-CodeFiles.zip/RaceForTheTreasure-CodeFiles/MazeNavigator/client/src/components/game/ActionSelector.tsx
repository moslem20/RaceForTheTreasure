import React from 'react';
import { Move, Hammer, Layers } from 'lucide-react';
import { Button } from '../ui/button';
import { GameState } from '../../types/game';

export type ActionType = 'move' | 'place-wall' | 'place-ladder';

interface ActionSelectorProps {
  currentAction: ActionType;
  onActionChange: (action: ActionType) => void;
  gameState: GameState;
  isPlayerTurn: boolean;
}

export const ActionSelector: React.FC<ActionSelectorProps> = ({
  currentAction,
  onActionChange,
  gameState,
  isPlayerTurn
}) => {
  const humanResources = gameState.playerResources.human;
  
  const actions = [
    {
      type: 'move' as const,
      name: 'Move',
      icon: Move,
      description: 'Move to adjacent tile',
      available: true,
      color: 'text-blue-600 bg-blue-50 border-blue-200',
      activeColor: 'bg-blue-500 text-white'
    },
    {
      type: 'place-wall' as const,
      name: 'Place Wall',
      icon: Hammer,
      description: 'Block opponent path',
      available: humanResources.walls > 0,
      color: 'text-slate-600 bg-slate-50 border-slate-200',
      activeColor: 'bg-slate-500 text-white'
    },
    {
      type: 'place-ladder' as const,
      name: 'Place Ladder',
      icon: Layers,
      description: 'Create shortcut path',
      available: humanResources.ladders > 0,
      color: 'text-purple-600 bg-purple-50 border-purple-200',
      activeColor: 'bg-purple-500 text-white'
    }
  ];

  return (
    <div className="h-full p-2 bg-gradient-to-br from-cyan-50 via-blue-50 to-indigo-50 rounded-lg shadow border border-cyan-300 overflow-hidden">
      <h3 className="text-sm font-bold text-transparent bg-clip-text bg-gradient-to-r from-cyan-600 to-blue-600 mb-2 flex items-center gap-1">
        <Move className="w-4 h-4 text-cyan-500" />
        Actions
      </h3>
      
      <div className="space-y-1 overflow-y-auto flex-1">
        {actions.map((action) => {
          const Icon = action.icon;
          const isSelected = currentAction === action.type;
          const isDisabled = !action.available || !isPlayerTurn;
          
          return (
            <Button
              key={action.type}
              onClick={() => onActionChange(action.type)}
              disabled={isDisabled}
              variant="ghost"
              className={`w-full justify-start h-auto p-2 rounded-lg border transition-all ${
                isSelected 
                  ? `${action.activeColor}` 
                  : isDisabled
                    ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed'
                    : `${action.color}`
              }`}
            >
              <div className="flex items-center gap-3 w-full">
                <div className={`p-2 rounded-full ${
                  isSelected 
                    ? 'bg-white bg-opacity-20' 
                    : isDisabled 
                      ? 'bg-gray-200' 
                      : 'bg-white'
                }`}>
                  <Icon className={`w-5 h-5 ${
                    isSelected 
                      ? 'text-white' 
                      : isDisabled 
                        ? 'text-gray-400' 
                        : ''
                  }`} />
                </div>
                
                <div className="text-left flex-1">
                  <div className={`font-bold ${
                    isSelected 
                      ? 'text-white' 
                      : isDisabled 
                        ? 'text-gray-400' 
                        : ''
                  }`}>
                    {action.name}
                  </div>
                  <div className={`text-sm ${
                    isSelected 
                      ? 'text-white text-opacity-90' 
                      : isDisabled 
                        ? 'text-gray-400' 
                        : 'opacity-75'
                  }`}>
                    {action.description}
                  </div>
                </div>
                
                {action.type === 'place-wall' && (
                  <div className={`text-sm font-bold px-2 py-1 rounded-full ${
                    isSelected 
                      ? 'bg-white bg-opacity-20 text-white' 
                      : 'bg-slate-200 text-slate-700'
                  }`}>
                    {humanResources.walls}
                  </div>
                )}
                
                {action.type === 'place-ladder' && (
                  <div className={`text-sm font-bold px-2 py-1 rounded-full ${
                    isSelected 
                      ? 'bg-white bg-opacity-20 text-white' 
                      : 'bg-purple-200 text-purple-700'
                  }`}>
                    {humanResources.ladders}
                  </div>
                )}
              </div>
            </Button>
          );
        })}
      </div>
      
      {!isPlayerTurn && (
        <div className="mt-4 p-3 bg-amber-100 border-2 border-amber-300 rounded-xl">
          <div className="flex items-center gap-2 text-amber-800">
            <div className="w-3 h-3 bg-amber-500 rounded-full animate-pulse"></div>
            <span className="font-medium text-sm">Waiting for AI turn...</span>
          </div>
        </div>
      )}
    </div>
  );
};