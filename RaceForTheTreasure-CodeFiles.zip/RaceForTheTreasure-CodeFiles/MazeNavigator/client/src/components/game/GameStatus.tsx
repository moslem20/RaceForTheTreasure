import React from 'react';
import { Trophy, Users, Timer } from 'lucide-react';

export type GameStatusType = 'playing' | 'human-won' | 'ai-won' | 'draw';

interface GameStatusProps {
  currentPlayer: 'human' | 'ai';
  gameStatus: GameStatusType;
  moveCount: number;
}

export const GameStatus: React.FC<GameStatusProps> = ({
  currentPlayer,
  gameStatus,
  moveCount
}) => {
  const getStatusColor = () => {
    if (gameStatus === 'human-won') return 'text-blue-600 bg-blue-100';
    if (gameStatus === 'ai-won') return 'text-red-600 bg-red-100';
    if (gameStatus === 'draw') return 'text-yellow-600 bg-yellow-100';
    return currentPlayer === 'human' ? 'text-blue-600 bg-blue-100' : 'text-red-600 bg-red-100';
  };

  const getStatusMessage = () => {
    if (gameStatus === 'human-won') return '🎉 Human Player Wins!';
    if (gameStatus === 'ai-won') return '🤖 AI Agent Wins!';
    if (gameStatus === 'draw') return '🤝 It\'s a Draw!';
    return `${currentPlayer === 'human' ? '👤 Human' : '🤖 AI'} Player's Turn`;
  };

  return (
    <div className="mb-6 p-6 bg-gradient-to-r from-indigo-50 via-purple-50 to-pink-50 rounded-2xl shadow-lg border-2 border-indigo-200">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className={`px-4 py-2 rounded-full font-bold ${getStatusColor()} transition-all duration-500 ease-in-out transform hover:scale-105 animate-pulse`}>
            {getStatusMessage()}
          </div>
          
          <div className="flex items-center gap-2 text-slate-600">
            <Timer className="w-5 h-5" />
            <span className="font-medium">Turn: {moveCount}</span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-slate-700">
            <Users className="w-5 h-5" />
            <span className="font-medium">Human vs AI</span>
          </div>
          
          {gameStatus !== 'playing' && (
            <div className="flex items-center gap-2 text-amber-600">
              <Trophy className="w-5 h-5" />
              <span className="font-bold">Game Complete!</span>
            </div>
          )}
        </div>
      </div>
      
      {gameStatus === 'playing' && (
        <div className="mt-4 w-full bg-slate-200 rounded-full h-2">
          <div 
            className={`h-2 rounded-full transition-all duration-500 ${
              currentPlayer === 'human' 
                ? 'bg-gradient-to-r from-blue-400 to-blue-600' 
                : 'bg-gradient-to-r from-red-400 to-red-600'
            }`}
            style={{ width: currentPlayer === 'human' ? '50%' : '100%' }}
          />
        </div>
      )}
    </div>
  );
};