import React from 'react';
import { RotateCcw } from 'lucide-react';
import { Button } from '../ui/button';
import { GameStatus } from '../../types/game';

interface GameControlsProps {
  onReset: () => void;
  gameStatus: GameStatus;
  currentPlayer: 'human' | 'ai';
}

export const GameControls: React.FC<GameControlsProps> = ({
  onReset,
  gameStatus,
  currentPlayer
}) => {
  return (
    <div className="flex items-center gap-2">
      <Button
        onClick={onReset}
        size="sm"
        variant="outline"
        className="text-xs"
      >
        <RotateCcw className="w-3 h-3 mr-1" />
        New Game
      </Button>
      
      <div className={`px-2 py-1 rounded text-xs font-medium ${
        gameStatus === 'playing' 
          ? currentPlayer === 'human' 
            ? 'bg-blue-100 text-blue-800' 
            : 'bg-red-100 text-red-800'
          : 'bg-gray-100 text-gray-800'
      }`}>
        {gameStatus === 'playing' 
          ? `${currentPlayer === 'human' ? 'Your' : 'AI'} Turn`
          : gameStatus === 'human-won' ? 'You Won!'
          : gameStatus === 'ai-won' ? 'AI Won!'
          : 'Game Over'
        }
      </div>
    </div>
  );
};