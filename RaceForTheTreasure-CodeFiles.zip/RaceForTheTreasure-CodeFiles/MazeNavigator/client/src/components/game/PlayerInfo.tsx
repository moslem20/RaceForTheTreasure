import React from 'react';
import { Badge } from '../ui/badge';
import { Player } from '../../lib/game/types';
import { User, Bot, Shield, ArrowUp as Ladder, MapPin } from 'lucide-react';

interface PlayerInfoProps {
  humanPlayer: Player;
  aiPlayer: Player;
  currentPlayer: 'human' | 'ai';
  turnNumber: number;
}

export const PlayerInfo: React.FC<PlayerInfoProps> = ({
  humanPlayer,
  aiPlayer,
  currentPlayer,
  turnNumber
}) => {
  return (
    <div className="p-6 space-y-6">
      <div className="mb-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500"></div>
          Player Information
        </h3>
        <div className="h-0.5 bg-gradient-to-r from-green-500 to-blue-500 rounded-full"></div>
      </div>

      {/* Turn Counter */}
      <div className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl border border-indigo-200/50">
        <div className="text-center">
          <h4 className="font-bold text-gray-800">Turn {turnNumber}</h4>
          <p className="text-sm text-gray-600">Strategic moves made</p>
        </div>
      </div>

      {/* Human Player */}
      <div className={`p-4 rounded-xl border transition-all duration-300 ${
        currentPlayer === 'human' 
          ? 'bg-gradient-to-r from-blue-100 to-blue-50 border-blue-300 ring-2 ring-blue-200' 
          : 'bg-gradient-to-r from-gray-50 to-slate-50 border-gray-200'
      }`}>
        <div className="flex items-center gap-3 mb-3">
          <User className="w-5 h-5 text-blue-600" />
          <h4 className="font-bold text-gray-800">Human Player</h4>
          {currentPlayer === 'human' && (
            <Badge className="bg-blue-500 text-white text-xs">Active</Badge>
          )}
        </div>
        
        <div className="space-y-2 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-gray-600 flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              Position:
            </span>
            <span className="font-medium">({humanPlayer.position.x}, {humanPlayer.position.y})</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Moves this turn:</span>
            <span className="font-medium">{humanPlayer.movesThisTurn}/{humanPlayer.maxMovesPerTurn}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-gray-600 flex items-center gap-1">
              <Shield className="w-3 h-3" />
              Wall:
            </span>
            <div className="flex items-center gap-1">
              <Badge variant={humanPlayer.wallUsed ? "destructive" : "secondary"}>
                {humanPlayer.wallUsed ? "Used" : "Available"}
              </Badge>
              {humanPlayer.powerUps.extraWalls > 0 && (
                <span className="text-xs text-green-600 font-bold">+{humanPlayer.powerUps.extraWalls}</span>
              )}
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-gray-600 flex items-center gap-1">
              <Ladder className="w-3 h-3" />
              Ladder:
            </span>
            <div className="flex items-center gap-1">
              <Badge variant={humanPlayer.ladderUsed ? "destructive" : "secondary"}>
                {humanPlayer.ladderUsed ? "Used" : "Available"}
              </Badge>
              {humanPlayer.powerUps.extraLadders > 0 && (
                <span className="text-xs text-green-600 font-bold">+{humanPlayer.powerUps.extraLadders}</span>
              )}
            </div>
          </div>
          
          {humanPlayer.stunned > 0 && (
            <div className="flex items-center justify-between text-red-600 bg-red-50 p-2 rounded">
              <span className="text-sm font-medium">⚡ Stunned:</span>
              <span className="font-bold">{humanPlayer.stunned} turn(s)</span>
            </div>
          )}
          
          {(humanPlayer.powerUps.extraMovement > 0 || humanPlayer.powerUps.ignoreWaterCost > 0) && (
            <div className="mt-2 p-2 bg-purple-50 rounded border border-purple-200">
              <div className="text-xs text-purple-700 font-medium mb-1">Active Power-ups:</div>
              {humanPlayer.powerUps.extraMovement > 0 && (
                <div className="text-xs text-purple-600">⭐ Extra Movement: {humanPlayer.powerUps.extraMovement}</div>
              )}
              {humanPlayer.powerUps.ignoreWaterCost > 0 && (
                <div className="text-xs text-purple-600">💧 Water Immunity: {humanPlayer.powerUps.ignoreWaterCost}</div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* AI Player */}
      <div className={`p-4 rounded-xl border transition-all duration-300 ${
        currentPlayer === 'ai' 
          ? 'bg-gradient-to-r from-red-100 to-red-50 border-red-300 ring-2 ring-red-200' 
          : 'bg-gradient-to-r from-gray-50 to-slate-50 border-gray-200'
      }`}>
        <div className="flex items-center gap-3 mb-3">
          <Bot className="w-5 h-5 text-red-600" />
          <h4 className="font-bold text-gray-800">AI Agent</h4>
          {currentPlayer === 'ai' && (
            <Badge className="bg-red-500 text-white text-xs">Active</Badge>
          )}
        </div>
        
        <div className="space-y-2 text-sm">
          <div className="flex items-center justify-between">
            <span className="text-gray-600 flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              Position:
            </span>
            <span className="font-medium">({aiPlayer.position.x}, {aiPlayer.position.y})</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-gray-600">Moves this turn:</span>
            <span className="font-medium">{aiPlayer.movesThisTurn}/{aiPlayer.maxMovesPerTurn}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-gray-600 flex items-center gap-1">
              <Shield className="w-3 h-3" />
              Wall:
            </span>
            <Badge variant={aiPlayer.wallUsed ? "destructive" : "secondary"}>
              {aiPlayer.wallUsed ? "Used" : "Available"}
            </Badge>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-gray-600 flex items-center gap-1">
              <Ladder className="w-3 h-3" />
              Ladder:
            </span>
            <Badge variant={aiPlayer.ladderUsed ? "destructive" : "secondary"}>
              {aiPlayer.ladderUsed ? "Used" : "Available"}
            </Badge>
          </div>
        </div>
      </div>

      {/* Legend */}
      <div className="p-4 bg-gradient-to-r from-amber-50 to-yellow-50 rounded-xl border border-amber-200/50">
        <h4 className="font-semibold text-amber-800 mb-2">Terrain Legend</h4>
        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-400 rounded"></div>
            <span>Water (2x cost)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-yellow-400 rounded"></div>
            <span>Sand (3x cost)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-amber-600 rounded"></div>
            <span>Mud (2x cost)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-gray-800 rounded"></div>
            <span>Walls (blocked)</span>
          </div>
        </div>
      </div>
    </div>
  );
};