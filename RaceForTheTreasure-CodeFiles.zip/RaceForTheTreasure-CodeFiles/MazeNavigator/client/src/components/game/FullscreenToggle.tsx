import React, { useState, useEffect } from 'react';
import { Maximize, Minimize } from 'lucide-react';

interface FullscreenToggleProps {
  className?: string;
}

export const FullscreenToggle: React.FC<FullscreenToggleProps> = ({ className }) => {
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleFullscreen = async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
    } catch (error) {
      console.error('Error toggling fullscreen:', error);
    }
  };

  return (
    <button
      onClick={toggleFullscreen}
      className={`
        inline-flex items-center gap-2 px-3 py-1 
        bg-gray-100 hover:bg-gray-200 
        border border-gray-300 rounded-md
        text-sm font-medium text-gray-700
        transition-colors duration-200
        ${className}
      `}
      title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
    >
      {isFullscreen ? (
        <>
          <Minimize className="w-4 h-4" />
          <span className="hidden sm:inline">Exit Fullscreen</span>
        </>
      ) : (
        <>
          <Maximize className="w-4 h-4" />
          <span className="hidden sm:inline">Fullscreen</span>
        </>
      )}
    </button>
  );
};