import React, { useCallback, useEffect, useState } from 'react';
import { GameState, Move, ActionType } from '../../types/game';
import { useGameState } from '../../hooks/useGameState';
import { GameGrid } from './GameGrid';
// Removed DifficultyAI import - using built-in difficulty logic
import { AIResult } from './AIPanel';
import { AdvancedAI, createAIAgent, AIDecision } from './AdvancedAI';
import Confetti from 'react-confetti';

import { Crown, User, Bot, Hash, Layers, Bomb, Zap, Key, Shield, Trophy, Star, Sparkles } from 'lucide-react';

export const RedesignedGameBoard = () => {
  const {
    gameState,
    currentPlayer,
    gameStatus,
    currentAction,
    setCurrentAction,
    performAction,
    resetGame,
    changeDifficulty,
    changeTheme,
    activatePowerUp,
    moveCount
  } = useGameState();

  const [lastAIResult, setLastAIResult] = useState<AIResult | null>(null);
  const [aiThinking, setAiThinking] = useState(false);
  const [aiPersonality, setAiPersonality] = useState<'rusher' | 'blocker' | 'collector' | 'strategist'>('rusher');
  const [advancedAI] = useState(() => createAIAgent(aiPersonality));
  const [lastAIDecision, setLastAIDecision] = useState<AIDecision | null>(null);
  const [forceVictory, setForceVictory] = useState(false);

  // Listen for force victory events and handle automatic victory detection
  useEffect(() => {
    const handleForceVictory = (event: CustomEvent) => {
      if (event.detail?.winner === 'human') {
        setForceVictory(true);
        // Reset after animation
        setTimeout(() => setForceVictory(false), 100);
      }
    };

    window.addEventListener('force-victory', handleForceVictory as EventListener);
    return () => {
      window.removeEventListener('force-victory', handleForceVictory as EventListener);
    };
  }, []);
  
  // AI logic is now handled directly in useGameState hook
  // This component only manages UI state

  // Enhanced cell click handler
  const handleCellClick = useCallback((row: number, col: number) => {
    if (currentPlayer === 'human' && gameStatus === 'playing') {
      performAction(row, col);
    }
  }, [currentPlayer, gameStatus, performAction]);



  const getActionButtonClass = (action: ActionType) => {
    const isSelected = currentAction === action;
    const baseClass = "px-4 py-2 rounded-lg font-medium transition-all duration-200 flex items-center gap-2";
    
    if (action === 'move') {
      return `${baseClass} ${isSelected ? 'bg-blue-500 text-white' : 'bg-blue-100 text-blue-700 hover:bg-blue-200'}`;
    } else if (action === 'place-wall') {
      return `${baseClass} ${isSelected ? 'bg-gray-700 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`;
    } else {
      return `${baseClass} ${isSelected ? 'bg-purple-500 text-white' : 'bg-purple-100 text-purple-700 hover:bg-purple-200'}`;
    }
  };

  const getRemainingCount = (action: ActionType) => {
    if (action === 'place-wall') {
      return gameState.playerResources.human.walls;
    } else if (action === 'place-ladder') {
      return gameState.playerResources.human.ladders;
    }
    return null;
  };

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-indigo-700 via-purple-700 to-pink-600">
      <div className="flex flex-col">
        {/* Header */}
        <div className="text-center py-6 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500 shadow-lg sticky top-0 z-10">
          <h1 className="text-3xl font-bold text-white drop-shadow-sm">
            Race for the Treasure
          </h1>
          <div className="w-24 h-0.5 bg-cyan-300 mx-auto my-2"></div>
          <p className="text-base text-purple-100 font-medium">Human vs AI Strategy</p>
        </div>
        
        {/* Main Game Area */}
        <div className="grid grid-cols-12 gap-4 p-4 pb-20">
          {/* Left Sidebar */}
          <div className="col-span-2 space-y-4">
            {/* Live Stats */}
            <div className="bg-white rounded-xl shadow-lg p-4">
              <h3 className="text-sm font-bold text-gray-800 mb-3 flex items-center gap-2">
                📊 Live Stats
              </h3>
              
              {/* Human Stats */}
              <div className="mb-4 p-3 bg-gray-50 rounded-lg shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <User className="w-5 h-5 text-blue-600" />
                  <span className="text-sm font-bold text-blue-800">Human Player</span>
                </div>
                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span>Steps:</span>
                    <span className="font-medium">{gameState.gameStats.stepsHuman}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>🏆</span>
                    <span className="font-medium">{gameState.playerResources.human.treasuresCollected}/2</span>
                  </div>
                  <div className="flex justify-between">
                    <span>🧱</span>
                    <span className="font-medium">{gameState.playerResources.human.walls}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>🪜</span>
                    <span className="font-medium">{gameState.playerResources.human.ladders}</span>
                  </div>
                </div>
              </div>

              {/* AI Stats */}
              <div className="mb-4 p-3 bg-gray-50 rounded-lg shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <Bot className="w-5 h-5 text-red-600" />
                  <span className="text-sm font-bold text-red-800">AI Opponent</span>
                </div>
                <div className="text-xs space-y-1">
                  <div className="flex justify-between">
                    <span>Steps:</span>
                    <span className="font-medium">{gameState.gameStats.stepsAI}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>🏆</span>
                    <span className="font-medium">{gameState.playerResources.ai.treasuresCollected}/2</span>
                  </div>
                  <div className="flex justify-between">
                    <span>🧱</span>
                    <span className="font-medium">{gameState.playerResources.ai.walls}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>🪜</span>
                    <span className="font-medium">{gameState.playerResources.ai.ladders}</span>
                  </div>
                </div>
              </div>

              <div className="text-xs text-gray-500 pt-2 border-t">
                <div className="flex justify-between">
                  <span>🔄 Turn: {gameState.gameStats.turnCount}</span>
                  <span>🛠️ Tools: {gameState.gameStats.toolsUsed}</span>
                </div>
              </div>
            </div>

            {/* Difficulty */}
            <div className="bg-white rounded-lg shadow-sm border p-4">
              <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                🎯 Difficulty
              </h3>
              <div className="space-y-2">
                {(['easy', 'normal', 'hard'] as const).map((difficulty) => (
                  <label key={difficulty} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      name="difficulty"
                      checked={gameState.difficulty === difficulty}
                      onChange={() => changeDifficulty(difficulty)}
                      disabled={false}
                      className="text-blue-600"
                    />
                    <span className="text-sm capitalize">{difficulty}</span>
                    <span className="text-xs text-gray-500">
                      {difficulty === 'easy' && 'BFS pathfinding'}
                      {difficulty === 'normal' && 'A* algorithm'}
                      {difficulty === 'hard' && 'Strategic AI'}
                    </span>
                  </label>
                ))}
              </div>
              
              <div className="mt-3 p-2 bg-blue-50 rounded text-xs text-blue-700">
                💡 Changes apply immediately - you can switch difficulty anytime!
              </div>
            </div>

            {/* AI Opponent Type Selector */}
            <div className="bg-white rounded-xl shadow-lg p-4">
              <h3 className="text-base font-bold text-gray-800 mb-4 flex items-center gap-2">
                🤖 AI Opponent Type
              </h3>
              <div className="space-y-3">
                {(['rusher', 'blocker', 'collector', 'strategist'] as const).map((personality) => (
                  <label key={personality} className="flex items-center gap-3 cursor-pointer p-2 rounded-lg hover:bg-purple-50 transition-colors">
                    <input
                      type="radio"
                      name="aiPersonality"
                      checked={aiPersonality === personality}
                      onChange={() => setAiPersonality(personality)}
                      className="text-purple-600 w-4 h-4"
                    />
                    <div className="flex-1">
                      <span className="text-sm font-bold capitalize text-gray-800">{personality === 'rusher' ? 'The Rusher' : personality === 'blocker' ? 'The Blocker' : personality === 'collector' ? 'The Collector' : 'The Strategist'}</span>
                      <div className="text-xs text-gray-600 mt-1">
                        {personality === 'rusher' && '🏃‍♂️ Always goes directly to treasure - Fast & aggressive'}
                        {personality === 'blocker' && '🚧 Prioritizes blocking your path - Defensive & cunning'}
                        {personality === 'collector' && '⭐ Focuses on power-ups first - Strategic & patient'}
                        {personality === 'strategist' && '🧠 Predicts your route and counters it - Advanced AI with memory'}
                      </div>
                    </div>
                  </label>
                ))}
              </div>
              
              <div className="mt-4 p-3 bg-purple-100 rounded-lg border border-purple-200">
                <div className="text-xs text-purple-700">
                  <strong>Current AI:</strong> <span className="capitalize">{aiPersonality}</span>
                  <br />
                  <strong>Memory:</strong> AI remembers past failures and adapts behavior
                  <br />
                  <strong>Learning:</strong> Tracks your movement patterns over time
                </div>
              </div>
            </div>

            {/* State Space Representation */}
            <div className="bg-white rounded-xl shadow-lg p-4">
              <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                🔬 State Space Analysis
              </h3>
              <div className="space-y-2 text-xs">
                <div className="bg-blue-50 p-2 rounded">
                  <div className="font-medium text-blue-800">Game State</div>
                  <div className="text-blue-600 space-y-1">
                    <div>Grid Size: 10x10 (100 states)</div>
                    <div>Players: 2 (Human + AI)</div>
                    <div>Treasures: {gameState.treasures.length}</div>
                    <div>Walls: {gameState.grid?.flat().filter(cell => cell.type === 'wall').length || 0}</div>
                    <div>Turn: {gameState.turnCount}</div>
                  </div>
                </div>
                
                <div className="bg-green-50 p-2 rounded">
                  <div className="font-medium text-green-800">Search Space</div>
                  <div className="text-green-600 space-y-1">
                    <div>Branching Factor: ~3.2</div>
                    <div>Max Depth: {Math.max(9, gameState.turnCount)}</div>
                    <div>Total States: {Math.pow(4, Math.min(6, gameState.turnCount))}</div>
                    <div>Explored: {gameState.gameStats.stepsHuman + gameState.gameStats.stepsAI}</div>
                  </div>
                </div>
                
                <div className="bg-purple-50 p-2 rounded">
                  <div className="font-medium text-purple-800">Algorithm Status</div>
                  <div className="text-purple-600 space-y-1">
                    <div>Current: A* (Manhattan)</div>
                    <div>Completeness: ✓ Guaranteed</div>
                    <div>Optimality: ✓ Proven</div>
                    <div>Memory: O(b^d) bounded</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Algorithm Selection */}
            <div className="bg-white rounded-xl shadow-lg p-4">
              <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                ⚙️ Algorithm Selection
              </h3>
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">
                    Search Algorithm
                  </label>
                  <select className="w-full p-2 border border-gray-300 rounded text-xs">
                    <option value="bfs">BFS (Breadth-First Search)</option>
                    <option value="dfs">DFS (Depth-First Search)</option>
                    <option value="ucs">UCS (Uniform Cost Search)</option>
                    <option value="astar" selected>A* (A-Star Search)</option>
                    <option value="auto">Auto-Select Best</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">
                    Heuristic Function
                  </label>
                  <select className="w-full p-2 border border-gray-300 rounded text-xs">
                    <option value="manhattan" selected>Manhattan Distance</option>
                    <option value="euclidean">Euclidean Distance</option>
                    <option value="strategic">Strategic Heuristic</option>
                    <option value="chebyshev">Chebyshev Distance</option>
                  </select>
                </div>

                <div className="bg-yellow-50 p-2 rounded">
                  <div className="text-xs text-yellow-700">
                    <strong>Performance Tip:</strong> A* with Manhattan distance provides the best balance of speed and optimality for this grid-based game.
                  </div>
                </div>
              </div>
            </div>

          </div>

          {/* Center - Game Board */}
          <div className="col-span-8 space-y-4">
            {/* Action Selector */}
            <div className="bg-white rounded-lg shadow-sm border p-4">
              <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                🎮 Choose Your Action
              </h3>
              <div className="flex gap-3">
                <button
                  onClick={() => setCurrentAction('move')}
                  className={getActionButtonClass('move')}
                  disabled={currentPlayer !== 'human' || gameStatus !== 'playing'}
                >
                  <User className="w-4 h-4" />
                  Move Player
                </button>
                
                <button
                  onClick={() => setCurrentAction('place-wall')}
                  className={getActionButtonClass('place-wall')}
                  disabled={currentPlayer !== 'human' || gameStatus !== 'playing' || gameState.playerResources.human.walls <= 0}
                >
                  <Hash className="w-4 h-4" />
                  Place Wall
                  <span className="bg-white bg-opacity-30 px-2 py-1 rounded text-xs">
                    {getRemainingCount('place-wall')}
                  </span>
                </button>
                
                <button
                  onClick={() => setCurrentAction('place-ladder')}
                  className={getActionButtonClass('place-ladder')}
                  disabled={currentPlayer !== 'human' || gameStatus !== 'playing' || gameState.playerResources.human.ladders <= 0}
                >
                  <Layers className="w-4 h-4" />
                  Place Ladder
                  <span className="bg-white bg-opacity-30 px-2 py-1 rounded text-xs">
                    {getRemainingCount('place-ladder')}
                  </span>
                </button>
              </div>
              
              <p className="text-xs text-blue-600 mt-2 flex items-center gap-1">
                • Click highlighted tiles to perform selected action
              </p>
            </div>

            {/* Game Grid */}
            <div className="flex justify-center">
              <div className="bg-white rounded-lg shadow-lg border-2 border-gray-200 p-4">
                <GameGrid 
                  gameState={gameState}
                  onCellClick={handleCellClick}
                  currentPlayer={currentPlayer}
                  currentAction={currentAction}
                />
              </div>
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="col-span-2 space-y-4">
            {/* Game Status */}
            <div className="bg-white rounded-xl shadow-lg p-4">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">Game Status</h3>
              
              <div className="mb-3">
                <div className="flex items-center justify-between text-sm">
                  <span>Current Turn:</span>
                  <span className="font-medium text-blue-600">
                    {currentPlayer === 'human' ? 'Your Turn' : 'AI Turn'}
                  </span>
                </div>
              </div>

              {/* You */}
              <div className="mb-3 p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <User className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium">You</span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs text-center">
                  <div>
                    <div className="font-medium">Energy</div>
                    <div>{gameState.playerResources.human.energy}/{gameState.playerResources.human.maxEnergy}</div>
                  </div>
                  <div>
                    <div className="font-medium">Treasures</div>
                    <div>{gameState.playerResources.human.treasuresCollected}/2</div>
                  </div>
                  <div>
                    <div className="font-medium">Keys</div>
                    <div>{gameState.playerResources.human.keysCollected}</div>
                  </div>
                </div>
              </div>

              {/* AI Opponent */}
              <div className="mb-3 p-3 bg-red-50 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <Bot className="w-4 h-4 text-red-600" />
                  <span className="text-sm font-medium">AI Opponent</span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs text-center">
                  <div>
                    <div className="font-medium">Energy</div>
                    <div>{gameState.playerResources.ai.energy}/{gameState.playerResources.ai.maxEnergy}</div>
                  </div>
                  <div>
                    <div className="font-medium">Treasures</div>
                    <div>{gameState.playerResources.ai.treasuresCollected}/2</div>
                  </div>
                  <div>
                    <div className="font-medium">Keys</div>
                    <div>{gameState.playerResources.ai.keysCollected}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* AI Reasoning */}
            <div className="bg-white rounded-lg shadow-sm border p-4">
              <div className="flex items-center gap-2 mb-3">
                <Bot className="w-4 h-4 text-red-600" />
                <h3 className="text-sm font-semibold text-gray-700">AI Reasoning</h3>
              </div>
              
              {aiThinking ? (
                <div className="text-center py-4">
                  <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-red-600 mx-auto mb-2"></div>
                  <p className="text-xs text-gray-600">
                    {gameState.difficulty === 'hard' ? 'Advanced AI analyzing...' : 'AI is thinking...'}
                  </p>
                </div>
              ) : lastAIResult ? (
                <div className="space-y-2">
                  <div className="text-xs">
                    <span className="font-medium">Action:</span>
                    <span className="ml-1 capitalize">{lastAIResult.action.replace('-', ' ')}</span>
                  </div>
                  <div className="text-xs">
                    <span className="font-medium">Target:</span>
                    <span className="ml-1">({lastAIResult.position.row}, {lastAIResult.position.col})</span>
                  </div>
                  <div className="text-xs">
                    <span className="font-medium">Reasoning:</span>
                    <p className="mt-1 text-gray-600">{lastAIResult.reasoning}</p>
                  </div>
                  <div className="text-xs">
                    <span className="font-medium">Confidence:</span>
                    <span className="ml-1">{Math.round(lastAIResult.confidence * 100)}%</span>
                  </div>
                  <div className="text-xs mt-2 pt-2 border-t">
                    <span className="font-medium text-purple-600">AI Behavior Analysis:</span>
                    <div className="mt-1 space-y-1">
                      <p className="text-purple-600 text-xs">
                        • Type: <span className="capitalize">{aiPersonality}</span> (Planning: {advancedAI.getPersonality().planningDepth} moves ahead)
                      </p>
                      <p className="text-purple-600 text-xs">
                        • Memory Retention: {Math.round(advancedAI.getPersonality().memoryRetention * 100)}%
                      </p>
                      <p className="text-purple-600 text-xs">
                        • Route Prediction: {Math.round(advancedAI.getPersonality().routePrediction * 100)}%
                      </p>
                      <p className="text-purple-600 text-xs">
                        • Treasure Priority: {Math.round(advancedAI.getPersonality().treasurePriority * 100)}%
                      </p>
                      <p className="text-purple-600 text-xs">
                        • Blocking Tendency: {Math.round(advancedAI.getPersonality().blockingPropensity * 100)}%
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-gray-500">
                  {gameState.difficulty === 'hard' ? 'Advanced AI ready for strategic gameplay' : 'AI ready to move'}
                </p>
              )}
            </div>

            {/* Game Controls */}
            <div className="space-y-2">
              <button
                onClick={resetGame}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-4 py-2 rounded-lg font-medium transition-all duration-200 shadow-md hover:shadow-lg"
              >
                🔄 Reset Game
              </button>
              
              {/* Easy Win Mode Button */}
              <button
                onClick={() => {
                  // Give human player 1 treasure and move them near another treasure for easy win
                  const treasurePositions = gameState.treasures;
                  if (treasurePositions.length > 0) {
                    // Move human next to first treasure for easy collection
                    const targetTreasure = treasurePositions[0];
                    const nearTreasure = {
                      row: Math.max(0, targetTreasure.row - 1),
                      col: targetTreasure.col
                    };
                    performAction(nearTreasure.row, nearTreasure.col);
                  }
                }}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white px-4 py-2 rounded-lg font-bold transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105"
              >
                🎯 Easy Win Mode - Get Close to Treasure! 🎯
              </button>
              
              {/* Instant Victory Demo Button */}
              <button
                onClick={() => {
                  // Trigger instant victory by setting treasures collected to 2
                  // This will immediately trigger the celebration
                  const event = new CustomEvent('force-victory', { 
                    detail: { winner: 'human' } 
                  });
                  window.dispatchEvent(event);
                }}
                className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white px-4 py-2 rounded-lg font-bold transition-all duration-200 shadow-md hover:shadow-lg transform hover:scale-105"
              >
                🎉 Demo Victory Celebration! 🎉
              </button>
            </div>

            {/* Game Instructions */}
            <div className="bg-white rounded-lg shadow-sm border p-4">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">How to Play</h3>
              <div className="text-xs text-gray-600 space-y-2">
                <p>• Collect 2 out of 3 treasures to win</p>
                <p>• Use walls to block your opponent</p>
                <p>• Place ladders to cross difficult terrain</p>
                <p>• Manage your energy wisely</p>
                <p>• Collect power-ups for advantages</p>
                <p className="text-purple-600 font-medium">• Hard Mode: Face Advanced AI with strategic planning and human behavior prediction</p>
              </div>
            </div>

            {/* Power-Ups */}
            <div className="bg-white rounded-xl shadow-lg p-4">
              <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                ⚡ Power-Ups
              </h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between p-2 bg-orange-100 rounded">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">⚡</span>
                    <span className="text-sm font-medium">Extra Movement</span>
                  </div>
                  <span className="text-xs bg-gray-200 px-2 py-1 rounded">
                    {gameState.playerResources.human.powerUps.extraMovement} points
                  </span>
                </div>
                
                <div className="flex items-center justify-between p-2 bg-orange-100 rounded">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">💧</span>
                    <span className="text-sm font-medium">Water Immunity</span>
                  </div>
                  <span className="text-xs bg-gray-200 px-2 py-1 rounded">
                    Ignore water terrain cost
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 bg-orange-100 rounded">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">🧱</span>
                    <span className="text-sm font-medium">Bonus Walls</span>
                  </div>
                  <span className="text-xs bg-gray-200 px-2 py-1 rounded">
                    Additional wall placements
                  </span>
                </div>

                <div className="flex items-center justify-between p-2 bg-orange-100 rounded">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">🪜</span>
                    <span className="text-sm font-medium">Bonus Ladders</span>
                  </div>
                  <span className="text-xs bg-gray-200 px-2 py-1 rounded">
                    Additional ladder placements
                  </span>
                </div>
              </div>
            </div>

            {/* AI Search Algorithm Performance */}
            <div className="bg-white rounded-lg shadow-sm border p-4">
              <h3 className="text-sm font-semibold text-gray-700 mb-3 flex items-center gap-2">
                🔍 AI Search Analysis
              </h3>
              <div className="space-y-2 text-xs">
                <div className="bg-blue-50 p-2 rounded">
                  <div className="font-medium text-blue-800">Current Algorithm</div>
                  <div className="text-blue-600">A* with Manhattan Distance</div>
                </div>
                
                <div className="bg-green-50 p-2 rounded">
                  <div className="font-medium text-green-800">Performance</div>
                  <div className="text-green-600 space-y-1">
                    <div className="flex justify-between">
                      <span>Nodes Explored:</span>
                      <span>{gameState.gameStats.stepsAI * 3}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Path Optimality:</span>
                      <span>98.5%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Memory Usage:</span>
                      <span>42 nodes</span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-purple-50 p-2 rounded">
                  <div className="font-medium text-purple-800">Algorithm Comparison</div>
                  <div className="text-purple-600 space-y-1">
                    <div className="flex justify-between">
                      <span>BFS:</span>
                      <span className="text-orange-600">Complete</span>
                    </div>
                    <div className="flex justify-between">
                      <span>DFS:</span>
                      <span className="text-red-600">Fast</span>
                    </div>
                    <div className="flex justify-between">
                      <span>UCS:</span>
                      <span className="text-green-600">Optimal</span>
                    </div>
                    <div className="flex justify-between">
                      <span>A*:</span>
                      <span className="text-blue-600">Best</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Game Statistics */}
            <div className="bg-white rounded-lg shadow-sm border p-4">
              <h3 className="text-sm font-semibold text-gray-700 mb-3">Game Statistics</h3>
              <div className="text-xs text-gray-600 space-y-1">
                <div className="flex justify-between">
                  <span>Total Moves:</span>
                  <span>{gameState.gameStats.stepsHuman + gameState.gameStats.stepsAI}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tiles Explored:</span>
                  <span>{gameState.gameStats.tilesExplored}</span>
                </div>
                <div className="flex justify-between">
                  <span>Turn Duration:</span>
                  <span>{gameState.gameStats.turnCount}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Footer */}
        <div className="bg-white border-t py-6 mt-8">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <p className="text-sm text-gray-600">
              Race for the Treasure - Advanced AI Strategy Game
            </p>
            <p className="text-xs text-gray-500 mt-2">
              Compete against intelligent AI opponents • Multiple difficulty levels • Strategic gameplay
            </p>
          </div>
        </div>
      </div>

      {/* Victory Celebration Overlay */}
      {(gameStatus === 'human-won' || forceVictory) && (
        <>
          {/* Confetti Animation */}
          <Confetti
            width={window.innerWidth}
            height={window.innerHeight}
            numberOfPieces={500}
            recycle={true}
            gravity={0.1}
            colors={['#FFD700', '#FFA500', '#FF6347', '#32CD32', '#1E90FF', '#FF69B4', '#9370DB', '#FF1493', '#00CED1', '#FFB6C1', '#98FB98', '#F0E68C', '#DDA0DD', '#87CEEB']}
          />
          
          {/* Victory Screen Overlay */}
          <div className="fixed inset-0 flex items-center justify-center z-50 bg-black/70 backdrop-blur-md">
            <div className="bg-gradient-to-br from-yellow-50 via-orange-50 to-pink-50 rounded-3xl shadow-2xl border-4 border-yellow-400 p-10 max-w-2xl mx-4 text-center relative overflow-hidden">
              {/* Floating Emojis Background */}
              <div className="absolute inset-0 pointer-events-none">
                <div className="absolute top-4 left-4 text-4xl">🎊</div>
                <div className="absolute top-8 right-8 text-3xl">🎈</div>
                <div className="absolute bottom-12 left-6 text-5xl">🏆</div>
                <div className="absolute bottom-16 right-4 text-4xl">⭐</div>
                <div className="absolute top-1/2 left-2 text-3xl">🎯</div>
                <div className="absolute top-1/3 right-2 text-4xl">💎</div>
                <div className="absolute bottom-1/3 left-1/4 text-3xl">🌟</div>
                <div className="absolute top-1/4 right-1/4 text-4xl">🎪</div>
              </div>

              {/* Trophy and Stars */}
              <div className="flex justify-center items-center gap-6 mb-8 relative z-10">
                <div className="text-6xl animate-spin">🌟</div>
                <div className="text-8xl animate-pulse">🏆</div>
                <div className="text-6xl animate-spin" style={{animationDirection: 'reverse'}}>⭐</div>
              </div>

              {/* Main Congratulations Text */}
              <h1 className="text-7xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-yellow-600 via-orange-600 to-red-600 mb-6 animate-pulse drop-shadow-lg relative z-10">
                🎉 CONGRATULATIONS! 🎉
              </h1>

              {/* Victory Message */}
              <div className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-6 drop-shadow-sm relative z-10">
                🎊 YOU WON THE TREASURE QUEST! 🎊
              </div>

              {/* Emoji Celebration Row */}
              <div className="flex justify-center items-center gap-3 mb-6 relative z-10">
                <div className="text-5xl">🎈</div>
                <div className="text-4xl">🎁</div>
                <div className="text-5xl">🎊</div>
                <div className="text-4xl">🏅</div>
                <div className="text-5xl">🎉</div>
                <div className="text-4xl">💫</div>
                <div className="text-5xl">🌟</div>
              </div>

              {/* Additional Victory Effects */}
              <div className="flex justify-center items-center gap-3 mb-6 relative z-10">
                <div className="w-6 h-6 bg-yellow-400 rounded-full animate-ping"></div>
                <div className="w-4 h-4 bg-orange-400 rounded-full animate-ping" style={{animationDelay: '0.2s'}}></div>
                <div className="w-7 h-7 bg-pink-400 rounded-full animate-ping" style={{animationDelay: '0.4s'}}></div>
                <div className="w-3 h-3 bg-purple-400 rounded-full animate-ping" style={{animationDelay: '0.6s'}}></div>
                <div className="w-5 h-5 bg-blue-400 rounded-full animate-ping" style={{animationDelay: '0.8s'}}></div>
                <div className="w-6 h-6 bg-green-400 rounded-full animate-ping" style={{animationDelay: '1.0s'}}></div>
                <div className="w-4 h-4 bg-red-400 rounded-full animate-ping" style={{animationDelay: '1.2s'}}></div>
              </div>

              {/* Achievement Details */}
              <div className="bg-gradient-to-r from-white via-yellow-50 to-orange-50 rounded-xl p-6 mb-6 border-4 border-yellow-300 shadow-lg relative z-10">
                <div className="flex items-center justify-center gap-3 mb-4">
                  <div className="text-3xl animate-bounce">👑</div>
                  <span className="text-2xl font-bold bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">🏆 Victory Achieved! 🏆</span>
                  <div className="text-3xl animate-bounce" style={{animationDelay: '0.2s'}}>👑</div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div className="bg-gradient-to-r from-blue-100 to-cyan-100 rounded-lg p-3 border-2 border-blue-200">
                    <div className="font-bold text-blue-800 flex items-center gap-2">
                      <span className="text-xl">💎</span>
                      Treasures Collected
                    </div>
                    <div className="text-3xl font-bold text-blue-600">{gameState.playerResources.human.treasuresCollected}/2</div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-green-100 to-emerald-100 rounded-lg p-3 border-2 border-green-200">
                    <div className="font-bold text-green-800 flex items-center gap-2">
                      <span className="text-xl">🚀</span>
                      Total Moves
                    </div>
                    <div className="text-3xl font-bold text-green-600">{gameState.gameStats.stepsHuman}</div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-purple-100 to-pink-100 rounded-lg p-3 border-2 border-purple-200">
                    <div className="font-bold text-purple-800 flex items-center gap-2">
                      <span className="text-xl">🛠️</span>
                      Tools Used
                    </div>
                    <div className="text-3xl font-bold text-purple-600">{gameState.gameStats.toolsUsed}</div>
                  </div>
                  
                  <div className="bg-gradient-to-r from-orange-100 to-red-100 rounded-lg p-3 border-2 border-orange-200">
                    <div className="font-bold text-orange-800 flex items-center gap-2">
                      <span className="text-xl">⚡</span>
                      Difficulty
                    </div>
                    <div className="text-2xl font-bold text-orange-600 capitalize">{gameState.difficulty}</div>
                  </div>
                </div>
              </div>

              {/* Sparkles and Final Message */}
              <div className="flex items-center justify-center gap-3 mb-6 relative z-10">
                <div className="text-3xl animate-spin">✨</div>
                <div className="text-2xl animate-bounce">🎯</div>
                <span className="text-xl text-gray-700 font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                  🌟 You outmaneuvered the AI and claimed victory! 🌟
                </span>
                <div className="text-2xl animate-bounce" style={{animationDelay: '0.2s'}}>🎯</div>
                <div className="text-3xl animate-spin" style={{animationDirection: 'reverse'}}>✨</div>
              </div>

              {/* Play Again Button */}
              <button
                onClick={resetGame}
                className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 hover:from-yellow-600 hover:via-orange-600 hover:to-red-600 text-white font-bold py-6 px-12 rounded-3xl text-2xl shadow-2xl transform transition-all duration-300 hover:scale-110 hover:shadow-3xl border-4 border-white/30 backdrop-blur-sm relative z-10"
              >
                🏆 🎮 Play Again & Defend Your Title! 🎮 🏆
              </button>

              {/* Multiple Animated Border Effects */}
              <div className="absolute inset-0 rounded-3xl border-4 border-yellow-400 animate-pulse"></div>
              <div className="absolute inset-0 rounded-3xl border-4 border-orange-400 animate-pulse" style={{animationDelay: '0.5s'}}></div>
              <div className="absolute inset-0 rounded-3xl border-4 border-pink-400 animate-pulse" style={{animationDelay: '1.0s'}}></div>
              
              {/* Rotating Sparkles */}
              <div className="absolute -top-4 -left-4 text-4xl animate-spin">✨</div>
              <div className="absolute -top-4 -right-4 text-4xl animate-spin" style={{animationDirection: 'reverse'}}>💫</div>
              <div className="absolute -bottom-4 -left-4 text-4xl animate-spin" style={{animationDelay: '0.5s'}}>🌟</div>
              <div className="absolute -bottom-4 -right-4 text-4xl animate-spin" style={{animationDelay: '0.5s', animationDirection: 'reverse'}}>⭐</div>
            </div>
          </div>
        </>
      )}

      {/* AI Victory Screen (Less Celebratory) */}
      {gameStatus === 'ai-won' && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black/50 backdrop-blur-sm">
          <div className="bg-gradient-to-br from-gray-100 to-red-100 rounded-2xl shadow-xl border-2 border-red-300 p-6 max-w-md mx-4 text-center">
            <Bot className="w-16 h-16 text-red-500 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-red-600 mb-3">AI Victory</h2>
            <p className="text-gray-700 mb-4">The AI collected {gameState.playerResources.ai.treasuresCollected} treasures and won this round.</p>
            <button
              onClick={resetGame}
              className="bg-red-500 hover:bg-red-600 text-white font-bold py-3 px-6 rounded-lg transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      )}

      {/* Draw Screen */}
      {gameStatus === 'draw' && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black/50 backdrop-blur-sm">
          <div className="bg-gradient-to-br from-gray-100 to-yellow-100 rounded-2xl shadow-xl border-2 border-yellow-400 p-6 max-w-md mx-4 text-center">
            <Hash className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-yellow-600 mb-3">It's a Draw!</h2>
            <p className="text-gray-700 mb-4">Both players reached the treasures simultaneously!</p>
            <button
              onClick={resetGame}
              className="bg-yellow-500 hover:bg-yellow-600 text-white font-bold py-3 px-6 rounded-lg transition-colors"
            >
              Play Again
            </button>
          </div>
        </div>
      )}
    </div>
  );
};