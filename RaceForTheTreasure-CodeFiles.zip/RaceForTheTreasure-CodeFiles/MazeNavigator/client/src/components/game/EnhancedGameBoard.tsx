import React, { useCallback, useEffect, useState } from 'react';
import { GameState, Move, ActionType } from '../../types/game';
import { useGameState } from '../../hooks/useGameState';
import { GameStatus } from './GameStatus';
import { GameGrid } from './GameGrid';
import { GameControls } from './GameControls';
import { ActionSelector } from './ActionSelector';
import { PowerUpDisplay } from './PowerUpDisplay';
import { AIPanel, AIResult } from './AIPanel';
import { DifficultySelector } from './DifficultySelector';
import { LiveStatsPanel } from './LiveStatsPanel';
import { RandomEventsPanel } from './RandomEventsPanel';
import { ThemeSelector } from './ThemeSelector';
import { ParticleSystem } from '../effects/ParticleSystem';
import { createDifficultyAI } from './DifficultyAI';
import { FullscreenToggle } from './FullscreenToggle';
import { DifficultyAdvisor } from './DifficultyAdvisor';
import { usePerformanceTracker } from '../../hooks/usePerformanceTracker';
import { AIAdvisorPanel } from './AIAdvisorPanel';

export const EnhancedGameBoard = () => {
  const {
    gameState,
    currentPlayer,
    gameStatus,
    currentAction,
    setCurrentAction,
    performAction,
    resetGame,
    changeDifficulty,
    changeTheme,
    activatePowerUp,
    moveCount
  } = useGameState();

  const [lastAIResult, setLastAIResult] = useState<AIResult | null>(null);
  const [aiThinking, setAiThinking] = useState(false);

  // Initialize AI difficulty system
  const difficultyAI = createDifficultyAI();
  
  // Performance tracking
  const {
    initializeGameTracking,
    trackMove,
    trackToolUsage,
    trackPowerUpUsage,
    finalizeGameMetrics,
    getDetailedPerformance
  } = usePerformanceTracker();
  
  const [performanceData, setPerformanceData] = useState(getDetailedPerformance());

  // Initialize performance tracking when game starts
  useEffect(() => {
    if (gameStatus === 'playing' && moveCount === 0) {
      initializeGameTracking(gameState);
    }
  }, [gameStatus, moveCount, gameState, initializeGameTracking]);

  // Track game completion
  useEffect(() => {
    if (gameStatus !== 'playing' && moveCount > 0) {
      const result = gameStatus === 'human-won' ? 'won' : 
                    gameStatus === 'ai-won' ? 'lost' : 'draw';
      finalizeGameMetrics(gameState, result);
      // Update performance data for AI advisor
      setPerformanceData(getDetailedPerformance());
    }
  }, [gameStatus, moveCount, gameState, finalizeGameMetrics, getDetailedPerformance]);

  // Track player moves
  useEffect(() => {
    if (currentPlayer === 'human' && moveCount > 0) {
      const humanPos = gameState.players.human;
      trackMove(gameState, humanPos);
    }
  }, [gameState.players.human, currentPlayer, moveCount, gameState, trackMove]);

  const makeAIMove = useCallback(() => {
    if (currentPlayer !== 'ai' || gameStatus !== 'playing') return;
    
    setAiThinking(true);
    
    setTimeout(() => {
      const aiPos = gameState.players.ai;
      const humanPos = gameState.players.human;
      const treasures = gameState.treasures;
      
      let aiResult: AIResult;
      
      // Use appropriate AI based on difficulty level
      if (gameState.difficulty === 'easy') {
        aiResult = difficultyAI.makeEasyAIMove(aiPos, treasures, gameState);
      } else if (gameState.difficulty === 'normal') {
        aiResult = difficultyAI.makeNormalAIMove(aiPos, humanPos, treasures, gameState);
      } else {
        aiResult = difficultyAI.makeHardAIMove(aiPos, humanPos, treasures, gameState);
      }

      setLastAIResult(aiResult);
      setAiThinking(false);

      if (aiResult.action === 'move') {
        setTimeout(() => {
          performAction(aiResult.position.row, aiResult.position.col);
        }, 500);
      } else if (aiResult.action === 'place-wall' || aiResult.action === 'place-ladder') {
        setCurrentAction(aiResult.action);
        setTimeout(() => {
          performAction(aiResult.position.row, aiResult.position.col);
        }, 500);
      }
    }, 1000);
  }, [currentPlayer, gameStatus, gameState, performAction, difficultyAI]);

  // Auto-execute AI moves
  useEffect(() => {
    if (currentPlayer === 'ai' && gameStatus === 'playing') {
      makeAIMove();
    }
  }, [currentPlayer, gameStatus, makeAIMove]);

  const handleCellClick = useCallback((row: number, col: number) => {
    if (currentPlayer === 'ai' || gameStatus !== 'playing') return;
    
    if (currentAction === 'move') {
      performAction(row, col);
    } else {
      performAction(row, col);
    }
  }, [currentPlayer, currentAction, gameStatus, performAction]);

  return (
    <div className="w-full h-screen bg-gradient-to-br from-slate-50 to-slate-100 overflow-hidden">
      <ParticleSystem 
        theme={gameState.theme}
        intensity="low"
        gameActive={gameStatus === 'playing'}
      />
      
      <div className="h-full flex flex-col">
        {/* Compact Header */}
        <div className="game-header flex justify-between items-center py-1 px-4 bg-white shadow-sm border-b">
          <div>
            <h1 className="text-lg font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
              Treasure Quest Arena
            </h1>
            <p className="text-xs text-gray-600">Human vs AI Strategy</p>
          </div>
          
          <div className="flex items-center gap-2">
            <FullscreenToggle />
            <ThemeSelector 
              currentTheme={gameState.theme}
              onThemeChange={changeTheme}
              disabled={false}
            />
            <GameControls 
              onReset={resetGame} 
              gameStatus={gameStatus}
              currentPlayer={currentPlayer}
            />
          </div>
        </div>

        {/* Game Status Bar */}
        <div className="game-status px-4 py-1 bg-slate-50 border-b">
          <GameStatus 
            currentPlayer={currentPlayer}
            gameStatus={gameStatus}
            moveCount={moveCount}
          />
        </div>
        
        {/* Main Game Area - Full Width 3 Column Layout */}
        <div className="flex-1 grid grid-cols-12 lg:grid-cols-12 md:grid-cols-1 gap-4 p-4 overflow-hidden w-full max-w-none full-width-game-layout">
          {/* Left Column - Controls (25% width) */}
          <div className="col-span-3 lg:col-span-3 md:col-span-1 left-panel flex flex-col gap-3 overflow-hidden">
            <div className="sidebar-panel bg-white rounded-lg shadow-sm border p-3">
              <h3 className="text-sm font-semibold text-gray-800 mb-3">Game Settings</h3>
              <DifficultySelector 
                currentDifficulty={gameState.difficulty}
                onDifficultyChange={changeDifficulty}
                disabled={gameStatus === 'playing'}
              />
            </div>
            
            <div className="sidebar-panel bg-white rounded-lg shadow-sm border p-3">
              <h3 className="text-sm font-semibold text-gray-800 mb-3">Actions</h3>
              <ActionSelector
                currentAction={currentAction}
                onActionChange={setCurrentAction}
                gameState={gameState}
                isPlayerTurn={currentPlayer === 'human' && gameStatus === 'playing'}
              />
            </div>
            
            <div className="flex-1 sidebar-panel bg-white rounded-lg shadow-sm border p-3 scrollable-panel">
              <h3 className="text-sm font-semibold text-gray-800 mb-3">Power-Ups</h3>
              <PowerUpDisplay
                gameState={gameState}
                currentPlayer={currentPlayer}
                onActivatePowerUp={activatePowerUp}
              />
            </div>
          </div>

          {/* Center Column - Game Grid (50% width) */}
          <div className="col-span-6 lg:col-span-6 md:col-span-1 center-panel flex justify-center items-center overflow-hidden px-4">
            <div className="game-grid-container max-w-full max-h-full">
              <GameGrid 
                gameState={gameState}
                onCellClick={handleCellClick}
                currentPlayer={currentPlayer}
                currentAction={currentAction}
              />
            </div>
          </div>
          
          {/* Right Column - AI & Stats (25% width) */}
          <div className="col-span-3 lg:col-span-3 md:col-span-1 right-panel flex flex-col gap-3 overflow-hidden">
            <div className="flex-1 sidebar-panel bg-white rounded-lg shadow-sm border p-3 scrollable-panel">
              <h3 className="text-sm font-semibold text-gray-800 mb-3">AI Performance Advisor</h3>
              <div className="panel-content">
                <AIAdvisorPanel 
                  gameState={gameState}
                  performance={performanceData}
                />
              </div>
            </div>
            
            <div className="sidebar-panel bg-white rounded-lg shadow-sm border p-3 scrollable-panel">
              <h3 className="text-sm font-semibold text-gray-800 mb-3">Game Stats</h3>
              <div className="panel-content">
                <LiveStatsPanel
                  gameState={gameState}
                  currentPlayer={currentPlayer}
                />
              </div>
            </div>
            
            {gameState.lastEvent && (
              <div className="sidebar-panel bg-white rounded-lg shadow-sm border p-3">
                <h3 className="text-sm font-semibold text-gray-800 mb-3">Events</h3>
                <div className="panel-content">
                  <RandomEventsPanel gameState={gameState} />
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Difficulty Advisor Modal */}
      <DifficultyAdvisor
        gameState={gameState}
        currentPlayer={currentPlayer}
        gameStatus={gameStatus}
        onDifficultyRecommend={changeDifficulty}
      />
    </div>
  );
};