import React from 'react';
import { DifficultyLevel } from './DifficultyAI';
import { cn } from '../../lib/utils';

interface DifficultySelectorProps {
  currentDifficulty: DifficultyLevel;
  onDifficultyChange: (difficulty: DifficultyLevel) => void;
  className?: string;
}

export const DifficultySelector: React.FC<DifficultySelectorProps> = ({
  currentDifficulty,
  onDifficultyChange,
  className
}) => {
  const difficulties: { 
    level: DifficultyLevel; 
    label: string; 
    description: string; 
    color: string;
    algorithm: string;
  }[] = [
    {
      level: 'easy',
      label: 'Easy',
      description: 'Basic pathfinding only',
      color: 'bg-green-500',
      algorithm: 'BFS'
    },
    {
      level: 'normal',
      label: 'Normal',
      description: 'Smart pathfinding with costs',
      color: 'bg-yellow-500',
      algorithm: 'A*'
    },
    {
      level: 'hard',
      label: 'Hard',
      description: 'Strategic planning & blocking',
      color: 'bg-red-500',
      algorithm: 'A* + Strategy'
    }
  ];

  return (
    <div className={cn("space-y-3", className)}>
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-800">AI Difficulty</h3>
        <div className="flex items-center space-x-1">
          <div className={cn("w-3 h-3 rounded-full", 
            difficulties.find(d => d.level === currentDifficulty)?.color || 'bg-gray-400'
          )} />
          <span className="text-sm font-medium text-gray-600">
            {difficulties.find(d => d.level === currentDifficulty)?.algorithm}
          </span>
        </div>
      </div>

      <div className="space-y-2">
        {difficulties.map((difficulty) => (
          <button
            key={difficulty.level}
            onClick={() => onDifficultyChange(difficulty.level)}
            className={cn(
              "w-full p-3 rounded-lg border-2 text-left transition-all duration-200 hover:shadow-md",
              currentDifficulty === difficulty.level
                ? "border-blue-500 bg-blue-50 shadow-md"
                : "border-gray-200 bg-white hover:border-gray-300"
            )}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={cn("w-4 h-4 rounded-full", difficulty.color)} />
                <div>
                  <div className="font-semibold text-gray-800">{difficulty.label}</div>
                  <div className="text-sm text-gray-600">{difficulty.description}</div>
                </div>
              </div>
              <div className="text-xs font-mono text-gray-500 bg-gray-100 px-2 py-1 rounded">
                {difficulty.algorithm}
              </div>
            </div>
          </button>
        ))}
      </div>

      <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
        <div className="text-sm text-blue-800">
          <div className="font-medium mb-1">Current AI Behavior:</div>
          <div className="text-blue-700">
            {currentDifficulty === 'easy' && (
              <>
                <span className="font-medium">Easy Mode:</span> Uses BFS pathfinding, ignores terrain costs, 
                no strategic planning or tool usage. Good for beginners.
              </>
            )}
            {currentDifficulty === 'normal' && (
              <>
                <span className="font-medium">Normal Mode:</span> Uses A* algorithm with terrain costs, 
                smart routing around obstacles, no tool placement.
              </>
            )}
            {currentDifficulty === 'hard' && (
              <>
                <span className="font-medium">Hard Mode:</span> Uses A* + opponent modeling, 
                strategic wall/ladder placement, multi-turn planning.
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};