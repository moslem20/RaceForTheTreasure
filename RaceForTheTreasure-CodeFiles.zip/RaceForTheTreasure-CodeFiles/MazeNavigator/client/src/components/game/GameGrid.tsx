import React from 'react';
import { GameCell } from './GameCell';
import { GameState, Position, ActionType } from '../../types/game';

interface GameGridProps {
  gameState: GameState;
  onCellClick: (row: number, col: number) => void;
  currentPlayer: 'human' | 'ai';
  currentAction: ActionType;
}

export const GameGrid: React.FC<GameGridProps> = ({ 
  gameState, 
  onCellClick, 
  currentPlayer,
  currentAction
}) => {
  const getValidMoves = (player: 'human' | 'ai'): Position[] => {
    const playerPos = gameState.players[player];
    const validMoves: Position[] = [];
    
    // Check all adjacent positions
    const directions = [
      [-1, 0], [1, 0], [0, -1], [0, 1] // up, down, left, right
    ];
    
    directions.forEach(([dr, dc]) => {
      const newRow = playerPos.row + dr;
      const newCol = playerPos.col + dc;
      
      if (newRow >= 0 && newRow < 10 && newCol >= 0 && newCol < 10) {
        // Check if position is not occupied by the other player
        const otherPlayer = player === 'human' ? 'ai' : 'human';
        const otherPlayerPos = gameState.players[otherPlayer];
        
        // Check if position is not a wall
        const isWall = gameState.walls.some(wall => wall.row === newRow && wall.col === newCol);
        
        if (!(newRow === otherPlayerPos.row && newCol === otherPlayerPos.col) && !isWall) {
          validMoves.push({ row: newRow, col: newCol });
        }
      }
    });
    
    return validMoves;
  };

  const getValidPlacements = (): Position[] => {
    const validPlacements: Position[] = [];
    
    for (let row = 0; row < 10; row++) {
      for (let col = 0; col < 10; col++) {
        // Check if cell is empty (no players, treasure, walls, ladders, high-cost tiles, traps, or power-ups)
        const isOccupied = 
          (gameState.players.human.row === row && gameState.players.human.col === col) ||
          (gameState.players.ai.row === row && gameState.players.ai.col === col) ||
          gameState.treasures.some(treasure => treasure.row === row && treasure.col === col) ||
          gameState.walls.some(wall => wall.row === row && wall.col === col) ||
          gameState.ladders.some(ladder => ladder.row === row && ladder.col === col) ||
          gameState.highCostTiles.some(tile => tile.row === row && tile.col === col) ||
          gameState.trapTiles.some(trap => trap.row === row && trap.col === col) ||
          gameState.powerUps.some(powerUp => powerUp.row === row && powerUp.col === col);
        
        if (!isOccupied) {
          validPlacements.push({ row, col });
        }
      }
    }
    
    return validPlacements;
  };

  const validMoves = currentAction === 'move' ? getValidMoves(currentPlayer) : [];
  const validPlacements = (currentAction === 'place-wall' || currentAction === 'place-ladder') ? getValidPlacements() : [];
  
  const isValidMove = (row: number, col: number): boolean => {
    return validMoves.some(move => move.row === row && move.col === col);
  };

  const isValidPlacement = (row: number, col: number): boolean => {
    return validPlacements.some(placement => placement.row === row && placement.col === col);
  };

  return (
    <div className="grid grid-cols-10 gap-0 bg-slate-200 p-4 rounded-xl w-fit mx-auto shadow-2xl border-4 border-slate-400">
      {Array.from({ length: 100 }, (_, index) => {
        const row = Math.floor(index / 10);
        const col = index % 10;
        
        return (
          <GameCell
            key={`${row}-${col}`}
            row={row}
            col={col}
            gameState={gameState}
            onClick={onCellClick}
            isValidMove={isValidMove(row, col)}
            isValidPlacement={isValidPlacement(row, col)}
            showValidMoves={currentPlayer === 'human'}
            currentAction={currentAction}
          />
        );
      })}
    </div>
  );
};