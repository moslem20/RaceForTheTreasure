import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { AlgorithmType } from '../../lib/pathfinding/types';

interface AlgorithmPanelProps {
  currentAlgorithm: AlgorithmType | null;
  currentStep: number;
  totalSteps: number;
}

export const AlgorithmPanel: React.FC<AlgorithmPanelProps> = ({
  currentAlgorithm,
  currentStep,
  totalSteps
}) => {
  const algorithmDescriptions = {
    [AlgorithmType.BFS]: {
      title: 'Breadth-First Search (BFS)',
      description: 'Explores all neighbors at the current depth before moving to nodes at the next depth level. Guarantees the shortest path in unweighted graphs.',
      properties: ['Complete', 'Optimal (unweighted)', 'Time: O(V+E)', 'Space: O(V)'],
      color: 'bg-blue-100 text-blue-800'
    },
    [AlgorithmType.DFS]: {
      title: 'Depth-First Search (DFS)',
      description: 'Explores as far as possible along each branch before backtracking. Does not guarantee the shortest path.',
      properties: ['Complete', 'Not optimal', 'Time: O(V+E)', 'Space: O(V)'],
      color: 'bg-green-100 text-green-800'
    },
    [AlgorithmType.UCS]: {
      title: 'Uniform Cost Search (UCS)',
      description: 'Expands the node with the lowest path cost first. Guarantees the optimal solution in weighted graphs.',
      properties: ['Complete', 'Optimal', 'Time: O(b^(C*/ε))', 'Space: O(b^(C*/ε))'],
      color: 'bg-purple-100 text-purple-800'
    },
    [AlgorithmType.ASTAR]: {
      title: 'A* Search',
      description: 'Uses both the actual cost from start and a heuristic estimate to goal. Most efficient when the heuristic is admissible.',
      properties: ['Complete', 'Optimal (admissible heuristic)', 'Time: O(b^d)', 'Space: O(b^d)'],
      color: 'bg-orange-100 text-orange-800'
    }
  };

  return (
    <div className="p-6 max-h-none overflow-visible">
      <div className="mb-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-indigo-500"></div>
          Algorithm Information
        </h3>
        <div className="h-0.5 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full"></div>
      </div>
      <div className="space-y-6">
        {currentAlgorithm ? (
          <div>
            <div className="mb-6">
              <div className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl border border-indigo-200/50">
                <Badge className={`${algorithmDescriptions[currentAlgorithm].color} text-base px-3 py-1 shadow-lg`}>
                  {algorithmDescriptions[currentAlgorithm].title}
                </Badge>
                {totalSteps > 0 && (
                  <div className="mt-3 p-2 bg-white/60 rounded-lg">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium text-gray-700">Progress:</span>
                      <span className="text-lg font-bold text-indigo-600">
                        {currentStep + 1} / {totalSteps}
                      </span>
                    </div>
                    <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-indigo-500 to-purple-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${((currentStep + 1) / totalSteps) * 100}%` }}
                      ></div>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="p-4 bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl border border-gray-200/50">
                <h4 className="font-bold text-gray-800 mb-2 flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                  Description
                </h4>
                <p className="text-gray-700 leading-relaxed">
                  {algorithmDescriptions[currentAlgorithm].description}
                </p>
              </div>
              
              <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200/50">
                <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
                  <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                  Properties
                </h4>
                <div className="flex flex-wrap gap-2">
                  {algorithmDescriptions[currentAlgorithm].properties.map((prop, index) => (
                    <Badge key={index} variant="outline" className="text-xs px-2 py-1 bg-white/60 border-green-300">
                      {prop}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-200/50">
              <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-blue-500"></div>
                How to Use
              </h4>
              <ol className="text-gray-700 space-y-2 list-decimal list-inside">
                <li className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-green-500 rounded-full flex items-center justify-center text-white text-xs font-bold">S</div>
                  Set start point (green S)
                </li>
                <li className="flex items-center gap-2">
                  <div className="w-4 h-4 bg-red-500 rounded-full flex items-center justify-center text-white text-xs font-bold">G</div>
                  Set goal point (red G)
                </li>
                <li>Add walls and terrain</li>
                <li>Select an algorithm to run</li>
                <li>Watch the visualization!</li>
              </ol>
            </div>
            
            <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200/50">
              <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
                <div className="w-1.5 h-1.5 rounded-full bg-purple-500"></div>
                Legend
              </h4>
              <div className="grid grid-cols-1 gap-2">
                <div className="flex items-center gap-3 p-2 bg-white/60 rounded-lg">
                  <div className="w-4 h-4 bg-green-500 rounded-md shadow-sm"></div>
                  <span className="text-sm font-medium">Start Point</span>
                </div>
                <div className="flex items-center gap-3 p-2 bg-white/60 rounded-lg">
                  <div className="w-4 h-4 bg-red-500 rounded-md shadow-sm"></div>
                  <span className="text-sm font-medium">Goal Point</span>
                </div>
                <div className="flex items-center gap-3 p-2 bg-white/60 rounded-lg">
                  <div className="w-4 h-4 bg-gray-800 rounded-md shadow-sm"></div>
                  <span className="text-sm font-medium">Wall</span>
                </div>
                <div className="flex items-center gap-3 p-2 bg-white/60 rounded-lg">
                  <div className="w-4 h-4 bg-blue-300 rounded-md shadow-sm"></div>
                  <span className="text-sm font-medium">Explored</span>
                </div>
                <div className="flex items-center gap-3 p-2 bg-white/60 rounded-lg">
                  <div className="w-4 h-4 bg-purple-300 rounded-md shadow-sm"></div>
                  <span className="text-sm font-medium">In Queue</span>
                </div>
                <div className="flex items-center gap-3 p-2 bg-white/60 rounded-lg">
                  <div className="w-4 h-4 bg-yellow-400 rounded-md shadow-sm"></div>
                  <span className="text-sm font-medium">Final Path</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
