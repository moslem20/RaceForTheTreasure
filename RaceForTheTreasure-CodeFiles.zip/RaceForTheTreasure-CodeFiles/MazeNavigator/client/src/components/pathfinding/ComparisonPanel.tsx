import React from 'react';
import { Badge } from '../ui/badge';
import { Trophy, Clock, MapPin, Target, Zap } from 'lucide-react';
import { AlgorithmResult, AlgorithmType, ComparisonData } from '../../lib/pathfinding/types';

interface ComparisonPanelProps {
  results: Map<AlgorithmType, AlgorithmResult>;
  comparisonData?: ComparisonData | null;
}

export const ComparisonPanel: React.FC<ComparisonPanelProps> = ({ results, comparisonData }) => {
  if (results.size === 0) {
    return (
      <div className="p-6 max-h-none overflow-visible">
        <div className="mb-6">
          <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
            Algorithm Comparison
          </h3>
          <div className="h-0.5 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full"></div>
        </div>
        <div className="p-6 bg-gradient-to-r from-gray-50 to-yellow-50 rounded-xl border border-gray-200/50 text-center">
          <div className="mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full mx-auto flex items-center justify-center">
              <Trophy className="w-8 h-8 text-white" />
            </div>
          </div>
          <p className="text-gray-600 font-medium">
            Click "Compare All Algorithms" to see real-time performance analysis
          </p>
        </div>
      </div>
    );
  }

  const formatTime = (time: number) => `${time.toFixed(2)}ms`;
  
  const sortedResults = Array.from(results.entries()).sort((a, b) => {
    // Sort by: found path first, then by execution time
    if (a[1].found !== b[1].found) return b[1].found ? 1 : -1;
    return a[1].executionTime - b[1].executionTime;
  });

  const getAlgorithmColor = (algorithm: AlgorithmType) => {
    switch (algorithm) {
      case AlgorithmType.BFS: return 'from-blue-500 to-cyan-500';
      case AlgorithmType.DFS: return 'from-purple-500 to-pink-500';
      case AlgorithmType.UCS: return 'from-green-500 to-emerald-500';
      case AlgorithmType.ASTAR: return 'from-orange-500 to-red-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const getPositionIcon = (index: number) => {
    switch (index) {
      case 0: return <Trophy className="w-5 h-5 text-yellow-500" />;
      case 1: return <div className="w-5 h-5 bg-gray-400 rounded-full flex items-center justify-center text-white text-xs font-bold">2</div>;
      case 2: return <div className="w-5 h-5 bg-orange-400 rounded-full flex items-center justify-center text-white text-xs font-bold">3</div>;
      default: return <div className="w-5 h-5 bg-gray-300 rounded-full flex items-center justify-center text-white text-xs font-bold">{index + 1}</div>;
    }
  };

  return (
    <div className="p-6 space-y-6 max-h-none overflow-visible">
      <div className="mb-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
          Real-Time Comparison Results
        </h3>
        <div className="h-0.5 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full"></div>
      </div>

      {/* Winner Announcement */}
      {comparisonData && (
        <div className="p-4 bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl border border-yellow-200/50 shadow-lg">
          <div className="flex items-center justify-center gap-3 mb-3">
            <Trophy className="w-6 h-6 text-yellow-600" />
            <h4 className="text-lg font-bold text-gray-800">First to Complete!</h4>
          </div>
          <div className="text-center">
            <Badge className={`bg-gradient-to-r ${getAlgorithmColor(comparisonData.winner)} text-white text-lg px-4 py-2 shadow-lg`}>
              {comparisonData.winner}
            </Badge>
            <p className="mt-2 text-sm text-gray-600">
              Completed in <span className="font-bold text-yellow-600">{formatTime(comparisonData.winnerTime)}</span>
            </p>
          </div>
        </div>
      )}

      {/* Performance Ranking */}
      <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl border border-blue-200/50">
        <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
          <Zap className="w-4 h-4 text-blue-600" />
          Performance Ranking
        </h4>
        <div className="space-y-3">
          {sortedResults.map(([algorithm, result], index) => (
            <div 
              key={algorithm} 
              className={`flex items-center justify-between p-3 rounded-lg transition-all duration-200 ${
                index === 0 ? 'bg-yellow-100/80 border border-yellow-300 shadow-md' : 'bg-white/60'
              }`}
            >
              <div className="flex items-center gap-3">
                {getPositionIcon(index)}
                <span className={`font-medium ${index === 0 ? 'text-yellow-800' : 'text-gray-700'}`}>
                  {algorithm}
                </span>
                {!result.found && (
                  <Badge variant="destructive" className="text-xs">No Path</Badge>
                )}
              </div>
              <div className="text-right">
                <div className={`font-bold ${index === 0 ? 'text-yellow-700' : 'text-gray-600'}`}>
                  {formatTime(result.executionTime)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Detailed Metrics Comparison */}
      <div className="grid grid-cols-1 gap-4">
        {/* Path Length Comparison */}
        <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200/50">
          <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            <Target className="w-4 h-4 text-green-600" />
            Path Length Comparison
          </h4>
          <div className="space-y-2">
            {Array.from(results.entries())
              .filter(([, result]) => result.found)
              .sort((a, b) => a[1].pathLength - b[1].pathLength)
              .map(([algorithm, result], index) => {
                const isOptimal = index === 0;
                return (
                  <div key={algorithm} className="flex items-center justify-between p-2 bg-white/60 rounded-lg">
                    <div className="flex items-center gap-2">
                      {isOptimal && <Trophy className="w-4 h-4 text-green-500" />}
                      <span className={`font-medium ${isOptimal ? 'text-green-700' : 'text-gray-700'}`}>
                        {algorithm}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`font-bold ${isOptimal ? 'text-green-600' : 'text-gray-600'}`}>
                        {result.pathLength} steps
                      </span>
                      {isOptimal && (
                        <Badge className="bg-gradient-to-r from-green-500 to-emerald-500 text-white text-xs">
                          Optimal
                        </Badge>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>

        {/* Nodes Explored Comparison */}
        <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200/50">
          <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            <MapPin className="w-4 h-4 text-purple-600" />
            Exploration Efficiency
          </h4>
          <div className="space-y-2">
            {Array.from(results.entries())
              .sort((a, b) => a[1].nodesExplored - b[1].nodesExplored)
              .map(([algorithm, result], index) => {
                const isMostEfficient = index === 0;
                return (
                  <div key={algorithm} className="flex items-center justify-between p-2 bg-white/60 rounded-lg">
                    <div className="flex items-center gap-2">
                      {isMostEfficient && <Zap className="w-4 h-4 text-purple-500" />}
                      <span className={`font-medium ${isMostEfficient ? 'text-purple-700' : 'text-gray-700'}`}>
                        {algorithm}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`font-bold ${isMostEfficient ? 'text-purple-600' : 'text-gray-600'}`}>
                        {result.nodesExplored} nodes
                      </span>
                      {isMostEfficient && (
                        <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs">
                          Most Efficient
                        </Badge>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      </div>

      {/* Summary Statistics */}
      {comparisonData && (
        <div className="p-4 bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl border border-gray-200/50">
          <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-600" />
            Comparison Summary
          </h4>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="text-center p-2 bg-white/60 rounded-lg">
              <div className="font-medium text-gray-600">Total Time</div>
              <div className="font-bold text-blue-600">{formatTime(comparisonData.totalComparisonTime)}</div>
            </div>
            <div className="text-center p-2 bg-white/60 rounded-lg">
              <div className="font-medium text-gray-600">Algorithms Tested</div>
              <div className="font-bold text-blue-600">{results.size}</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};