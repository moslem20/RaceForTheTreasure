import React, { useRef, useEffect, useState } from 'react';
import { Cell, EditMode } from '../../lib/pathfinding/types';
import { getCellColor } from '../../lib/pathfinding/utils';

interface GridProps {
  grid: Cell[][];
  editMode: EditMode;
  onCellClick: (x: number, y: number, mode: EditMode) => void;
  className?: string;
}

export const Grid: React.FC<GridProps> = ({ grid, editMode, onCellClick, className = '' }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [canvasSize, setCanvasSize] = useState({ width: 500, height: 500 });

  useEffect(() => {
    const updateCanvasSize = () => {
      const container = canvasRef.current?.parentElement;
      if (container) {
        // Better responsive sizing for desktop
        const containerWidth = container.clientWidth - 40;
        const containerHeight = container.clientHeight - 40;
        const maxSize = Math.min(window.innerWidth * 0.4, window.innerHeight * 0.6, 700);
        const size = Math.min(containerWidth, containerHeight, maxSize);
        setCanvasSize({ width: size, height: size });
      }
    };

    updateCanvasSize();
    window.addEventListener('resize', updateCanvasSize);
    return () => window.removeEventListener('resize', updateCanvasSize);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const cellSize = canvasSize.width / grid.length;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvasSize.width, canvasSize.height);

    // Draw grid
    for (let y = 0; y < grid.length; y++) {
      for (let x = 0; x < grid[y].length; x++) {
        const cell = grid[y][x];
        const pixelX = x * cellSize;
        const pixelY = y * cellSize;

        // Fill cell with enhanced path highlighting
        ctx.fillStyle = getCellColor(cell);
        ctx.fillRect(pixelX, pixelY, cellSize, cellSize);
        
        // Add extra highlighting for path cells
        if (cell.isPath) {
          ctx.fillStyle = 'rgba(255, 107, 53, 0.7)'; // Semi-transparent orange overlay
          ctx.fillRect(pixelX + 1, pixelY + 1, cellSize - 2, cellSize - 2);
          
          // Add border glow effect
          ctx.strokeStyle = '#ff6b35';
          ctx.lineWidth = 2;
          ctx.strokeRect(pixelX, pixelY, cellSize, cellSize);
        }

        // Draw border (skip for path cells as they have their own border)
        if (!cell.isPath) {
          ctx.strokeStyle = '#e5e7eb';
          ctx.lineWidth = 1;
          ctx.strokeRect(pixelX, pixelY, cellSize, cellSize);
        }

        // Draw cost if greater than 1
        if (cell.cost > 1 && !cell.isWall && !cell.isStart && !cell.isGoal) {
          ctx.fillStyle = '#000000';
          ctx.font = `${cellSize * 0.3}px Arial`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText(
            cell.cost.toString(),
            pixelX + cellSize / 2,
            pixelY + cellSize / 2
          );
        }

        // Draw special symbols
        if (cell.isStart) {
          ctx.fillStyle = '#ffffff';
          ctx.font = `bold ${cellSize * 0.4}px Arial`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('S', pixelX + cellSize / 2, pixelY + cellSize / 2);
        } else if (cell.isGoal) {
          ctx.fillStyle = '#ffffff';
          ctx.font = `bold ${cellSize * 0.4}px Arial`;
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('G', pixelX + cellSize / 2, pixelY + cellSize / 2);
        }
      }
    }
  }, [grid, canvasSize]);

  const handleCanvasInteraction = (event: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    const cellSize = canvasSize.width / grid.length;
    const gridX = Math.floor(x / cellSize);
    const gridY = Math.floor(y / cellSize);

    if (gridX >= 0 && gridX < grid[0].length && gridY >= 0 && gridY < grid.length) {
      onCellClick(gridX, gridY, editMode);
    }
  };

  const handleMouseDown = (event: React.MouseEvent<HTMLCanvasElement>) => {
    setIsDrawing(true);
    handleCanvasInteraction(event);
  };

  const handleMouseMove = (event: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDrawing && (editMode === EditMode.WALL || editMode === EditMode.ERASE)) {
      handleCanvasInteraction(event);
    }
  };

  const handleMouseUp = () => {
    setIsDrawing(false);
  };

  return (
    <div className={`flex justify-center items-center w-full h-full ${className}`}>
      <div className="relative w-full h-full flex items-center justify-center">
        <canvas
          ref={canvasRef}
          width={canvasSize.width}
          height={canvasSize.height}
          className="border-2 border-gray-200 rounded-xl shadow-lg cursor-crosshair transition-all duration-200 hover:shadow-xl"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          style={{ 
            touchAction: 'none',
            maxWidth: '100%',
            maxHeight: '100%',
            width: 'auto',
            height: 'auto'
          }}
        />
        
        {/* Grid overlay for better visual appeal */}
        <div className="absolute inset-0 pointer-events-none rounded-xl bg-gradient-to-br from-transparent via-transparent to-black/5" style={{
          width: canvasSize.width,
          height: canvasSize.height,
          left: '50%',
          top: '50%',
          transform: 'translate(-50%, -50%)'
        }}></div>
        
        {/* Corner decorations */}
        <div className="absolute w-4 h-4 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full shadow-lg" style={{
          left: `calc(50% - ${canvasSize.width/2}px - 8px)`,
          top: `calc(50% - ${canvasSize.height/2}px - 8px)`
        }}></div>
        <div className="absolute w-4 h-4 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full shadow-lg" style={{
          right: `calc(50% - ${canvasSize.width/2}px - 8px)`,
          top: `calc(50% - ${canvasSize.height/2}px - 8px)`
        }}></div>
        <div className="absolute w-4 h-4 bg-gradient-to-br from-green-500 to-emerald-500 rounded-full shadow-lg" style={{
          left: `calc(50% - ${canvasSize.width/2}px - 8px)`,
          bottom: `calc(50% - ${canvasSize.height/2}px - 8px)`
        }}></div>
        <div className="absolute w-4 h-4 bg-gradient-to-br from-orange-500 to-red-500 rounded-full shadow-lg" style={{
          right: `calc(50% - ${canvasSize.width/2}px - 8px)`,
          bottom: `calc(50% - ${canvasSize.height/2}px - 8px)`
        }}></div>
      </div>
    </div>
  );
};
