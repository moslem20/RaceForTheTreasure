import React from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Slider } from '../ui/slider';
import { EditMode, AlgorithmType } from '../../lib/pathfinding/types';
import { Play, Square, RotateCcw, Zap, Trash2 } from 'lucide-react';

interface ControlsProps {
  editMode: EditMode;
  onEditModeChange: (mode: EditMode) => void;
  onRunAlgorithm: (algorithm: AlgorithmType) => void;
  onRunAllAlgorithms: () => void;
  onClearGrid: () => void;
  onClearVisualization: () => void;
  isRunning: boolean;
  speed: number;
  onSpeedChange: (speed: number) => void;
  onGenerateRandomMaze: () => void;
}

export const Controls: React.FC<ControlsProps> = ({
  editMode,
  onEditModeChange,
  onRunAlgorithm,
  onRunAllAlgorithms,
  onClearGrid,
  onClearVisualization,
  isRunning,
  speed,
  onSpeedChange,
  onGenerateRandomMaze
}) => {
  const editModes = [
    { value: EditMode.START, label: 'Start Point', color: 'bg-green-500' },
    { value: EditMode.GOAL, label: 'Goal Point', color: 'bg-red-500' },
    { value: EditMode.WALL, label: 'Wall', color: 'bg-gray-800' },
    { value: EditMode.MUD, label: 'Mud (Cost: 3)', color: 'bg-yellow-800' },
    { value: EditMode.SAND, label: 'Sand (Cost: 2)', color: 'bg-yellow-600' },
    { value: EditMode.WATER, label: 'Water (Cost: 5)', color: 'bg-blue-500' },
    { value: EditMode.ERASE, label: 'Erase', color: 'bg-gray-200' }
  ];

  const algorithms = [
    { value: AlgorithmType.BFS, label: 'BFS (Breadth-First)' },
    { value: AlgorithmType.DFS, label: 'DFS (Depth-First)' },
    { value: AlgorithmType.UCS, label: 'UCS (Uniform Cost)' },
    { value: AlgorithmType.ASTAR, label: 'A* (A-Star)' }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Edit Mode Selection */}
      <div>
        <div className="mb-4">
          <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
            Edit Mode
          </h3>
          <div className="h-0.5 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full"></div>
        </div>
        <div className="grid grid-cols-1 gap-3">
          {editModes.map((mode) => (
            <Button
              key={mode.value}
              variant={editMode === mode.value ? "default" : "outline"}
              size="sm"
              onClick={() => onEditModeChange(mode.value)}
              className={`justify-start h-12 transition-all duration-200 ${
                editMode === mode.value 
                  ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg transform scale-105' 
                  : 'hover:bg-gray-50 hover:shadow-md'
              }`}
            >
              <div className={`w-4 h-4 rounded-full mr-3 shadow-sm ${mode.color}`} />
              <span className="font-medium">{mode.label}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Algorithm Controls */}
      <div>
        <div className="mb-4">
          <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-purple-500"></div>
            Algorithm Control
          </h3>
          <div className="h-0.5 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full"></div>
        </div>
        <div className="space-y-4">
          <div className="grid grid-cols-1 gap-3">
            {algorithms.map((algorithm) => (
              <Button
                key={algorithm.value}
                onClick={() => onRunAlgorithm(algorithm.value)}
                disabled={isRunning}
                className={`h-12 justify-start transition-all duration-200 ${
                  isRunning 
                    ? 'opacity-50 cursor-not-allowed' 
                    : 'hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 hover:text-white hover:shadow-lg hover:transform hover:scale-105'
                }`}
                variant="outline"
              >
                <Play className="w-4 h-4 mr-3" />
                <span className="font-medium">{algorithm.label}</span>
              </Button>
            ))}
          </div>
          
          <Button
            onClick={onRunAllAlgorithms}
            disabled={isRunning}
            className={`w-full h-14 transition-all duration-200 ${
              isRunning 
                ? 'opacity-50 cursor-not-allowed' 
                : 'bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-lg hover:shadow-xl hover:transform hover:scale-105'
            }`}
          >
            <Zap className="w-5 h-5 mr-3" />
            <span className="font-bold">Compare All Algorithms</span>
          </Button>
        </div>
      </div>

      {/* Visualization Speed */}
      <div>
        <div className="mb-4">
          <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
            Animation Speed
          </h3>
          <div className="h-0.5 bg-gradient-to-r from-orange-500 to-red-500 rounded-full"></div>
        </div>
        <div className="space-y-4">
          <div className="p-4 bg-gradient-to-r from-orange-50 to-red-50 rounded-xl border border-orange-200/50">
            <Slider
              value={[speed]}
              onValueChange={(value) => onSpeedChange(value[0])}
              min={10}
              max={500}
              step={10}
              className="w-full"
            />
            <div className="text-center mt-3">
              <span className="text-lg font-bold text-orange-700">{speed}ms</span>
              <span className="text-sm text-orange-600 ml-1">delay</span>
            </div>
          </div>
        </div>
      </div>

      {/* Utility Controls */}
      <div>
        <div className="mb-4">
          <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500"></div>
            Utilities
          </h3>
          <div className="h-0.5 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full"></div>
        </div>
        <div className="space-y-3">
          <Button
            onClick={onGenerateRandomMaze}
            disabled={isRunning}
            className={`w-full h-12 transition-all duration-200 ${
              isRunning 
                ? 'opacity-50 cursor-not-allowed' 
                : 'hover:bg-gradient-to-r hover:from-blue-500 hover:to-cyan-500 hover:text-white hover:shadow-lg'
            }`}
            variant="outline"
          >
            <RotateCcw className="w-4 h-4 mr-3" />
            <span className="font-medium">Generate Random Maze</span>
          </Button>
          
          <Button
            onClick={onClearVisualization}
            disabled={isRunning}
            className={`w-full h-12 transition-all duration-200 ${
              isRunning 
                ? 'opacity-50 cursor-not-allowed' 
                : 'hover:bg-gradient-to-r hover:from-yellow-500 hover:to-orange-500 hover:text-white hover:shadow-lg'
            }`}
            variant="outline"
          >
            <Square className="w-4 h-4 mr-3" />
            <span className="font-medium">Clear Visualization</span>
          </Button>
          
          <Button
            onClick={onClearGrid}
            disabled={isRunning}
            className={`w-full h-12 transition-all duration-200 ${
              isRunning 
                ? 'opacity-50 cursor-not-allowed' 
                : 'hover:bg-gradient-to-r hover:from-red-500 hover:to-pink-500 hover:text-white hover:shadow-lg'
            }`}
            variant="outline"
          >
            <Trash2 className="w-4 h-4 mr-3" />
            <span className="font-medium">Clear Grid</span>
          </Button>
        </div>
      </div>
    </div>
  );
};
