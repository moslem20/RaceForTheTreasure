import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Badge } from '../ui/badge';
import { AlgorithmType, AlgorithmResult } from '../../lib/pathfinding/types';
import { Clock, Target, MapPin, TrendingUp } from 'lucide-react';

interface MetricsPanelProps {
  results: Map<AlgorithmType, AlgorithmResult>;
}

export const MetricsPanel: React.FC<MetricsPanelProps> = ({ results }) => {
  const formatTime = (ms: number) => {
    if (ms < 1) return '<1ms';
    return `${ms.toFixed(2)}ms`;
  };

  const getBestAlgorithm = (metric: keyof AlgorithmResult): AlgorithmType | null => {
    if (results.size === 0) return null;
    
    let best: AlgorithmType | null = null;
    let bestValue = metric === 'executionTime' ? Infinity : -Infinity;
    
    results.forEach((result, algorithm) => {
      const value = result[metric] as number;
      if (metric === 'executionTime' && value < bestValue) {
        bestValue = value;
        best = algorithm;
      } else if (metric !== 'executionTime' && value > bestValue) {
        bestValue = value;
        best = algorithm;
      }
    });
    
    return best;
  };

  const renderMetricCard = (
    title: string,
    icon: React.ReactNode,
    metric: keyof AlgorithmResult,
    formatter: (value: number) => string = (v) => v.toString(),
    gradientColors: string = "from-blue-50 to-indigo-50"
  ) => {
    const bestAlgorithm = getBestAlgorithm(metric);
    
    return (
      <div className={`p-4 bg-gradient-to-r ${gradientColors} rounded-xl border border-blue-200/50`}>
        <div className="mb-3">
          <h4 className="font-bold text-gray-800 flex items-center gap-2">
            {icon}
            {title}
          </h4>
        </div>
        <div className="space-y-3">
          {Array.from(results.entries()).map(([algorithm, result]) => {
            const value = result[metric] as number;
            const isBest = algorithm === bestAlgorithm;
            
            return (
              <div key={algorithm} className={`flex justify-between items-center p-2 rounded-lg transition-all duration-200 ${
                isBest ? 'bg-white/80 shadow-md transform scale-105' : 'bg-white/40'
              }`}>
                <span className={`font-medium ${isBest ? 'text-gray-800' : 'text-gray-600'}`}>
                  {algorithm}
                </span>
                <div className="flex items-center gap-2">
                  <span className={`font-bold ${isBest ? 'text-lg text-indigo-600' : 'text-gray-700'}`}>
                    {formatter(value)}
                  </span>
                  {isBest && (
                    <Badge className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg">
                      Best
                    </Badge>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  if (results.size === 0) {
    return (
      <div className="p-6 max-h-none overflow-visible">
        <div className="mb-6">
          <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
            Performance Metrics
          </h3>
          <div className="h-0.5 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full"></div>
        </div>
        <div className="p-6 bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl border border-gray-200/50 text-center">
          <div className="mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full mx-auto flex items-center justify-center">
              <TrendingUp className="w-8 h-8 text-white" />
            </div>
          </div>
          <p className="text-gray-600 font-medium">
            Run algorithms to see performance comparisons here
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-h-none overflow-visible">
      <div className="mb-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
          Performance Comparison
        </h3>
        <div className="h-0.5 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full"></div>
      </div>
      
      <div className="p-4 bg-gradient-to-r from-emerald-50 to-teal-50 rounded-xl border border-emerald-200/50">
        <div className="text-center">
          <span className="text-lg font-bold text-emerald-700">
            Comparing {results.size} algorithm{results.size > 1 ? 's' : ''}
          </span>
        </div>
      </div>

      {renderMetricCard(
        'Execution Time',
        <Clock className="w-4 h-4 text-blue-600" />,
        'executionTime',
        formatTime,
        'from-blue-50 to-cyan-50'
      )}

      {renderMetricCard(
        'Nodes Explored',
        <MapPin className="w-4 h-4 text-purple-600" />,
        'nodesExplored',
        (v) => v.toString(),
        'from-purple-50 to-violet-50'
      )}

      {renderMetricCard(
        'Path Length',
        <Target className="w-4 h-4 text-green-600" />,
        'pathLength',
        (v) => v.toString(),
        'from-green-50 to-emerald-50'
      )}

      {renderMetricCard(
        'Total Path Cost',
        <TrendingUp className="w-4 h-4 text-orange-600" />,
        'totalCost',
        (v) => v.toString(),
        'from-orange-50 to-red-50'
      )}

      <div className="p-4 bg-gradient-to-r from-pink-50 to-rose-50 rounded-xl border border-pink-200/50">
        <div className="mb-3">
          <h4 className="font-bold text-gray-800 flex items-center gap-2">
            <div className="w-1.5 h-1.5 rounded-full bg-pink-500"></div>
            Success Rate
          </h4>
        </div>
        <div className="space-y-2">
          {Array.from(results.entries()).map(([algorithm, result]) => (
            <div key={algorithm} className="flex justify-between items-center p-2 bg-white/60 rounded-lg">
              <span className="font-medium text-gray-700">{algorithm}</span>
              <Badge 
                variant={result.found ? "default" : "destructive"}
                className={result.found 
                  ? "bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-lg" 
                  : "bg-gradient-to-r from-red-500 to-pink-500 text-white shadow-lg"
                }
              >
                {result.found ? 'Path Found' : 'No Path'}
              </Badge>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
