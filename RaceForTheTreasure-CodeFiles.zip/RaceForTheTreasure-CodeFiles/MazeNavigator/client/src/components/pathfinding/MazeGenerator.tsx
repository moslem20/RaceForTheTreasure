import React from 'react';
import { Button } from '../ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Slider } from '../ui/slider';
import { Cell, CellType } from '../../lib/pathfinding/types';
import { generateRandomMaze, getCellCost } from '../../lib/pathfinding/utils';
import { Shuffle, Settings } from 'lucide-react';

interface MazeGeneratorProps {
  onGenerateMaze: (grid: Cell[][]) => void;
  gridSize: number;
  className?: string;
}

export const MazeGenerator: React.FC<MazeGeneratorProps> = ({
  onGenerateMaze,
  gridSize,
  className = ''
}) => {
  const [wallDensity, setWallDensity] = React.useState(30);
  const [terrainDensity, setTerrainDensity] = React.useState(20);

  const generateMaze = () => {
    const wallProbability = wallDensity / 100;
    const terrainProbability = terrainDensity / 100;
    
    const grid = generateRandomMaze(gridSize, wallProbability);
    
    // Add additional terrain types
    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        if (!grid[y][x].isWall && Math.random() < terrainProbability) {
          const rand = Math.random();
          if (rand < 0.4) {
            grid[y][x].type = CellType.MUD;
            grid[y][x].cost = getCellCost(CellType.MUD);
          } else if (rand < 0.7) {
            grid[y][x].type = CellType.SAND;
            grid[y][x].cost = getCellCost(CellType.SAND);
          } else {
            grid[y][x].type = CellType.WATER;
            grid[y][x].cost = getCellCost(CellType.WATER);
          }
        }
      }
    }
    
    onGenerateMaze(grid);
  };

  const generateLabyrinth = () => {
    // Generate a more structured maze using recursive backtracking
    const grid = generateRandomMaze(gridSize, 0);
    
    // Fill with walls first
    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        grid[y][x].type = CellType.WALL;
        grid[y][x].isWall = true;
      }
    }
    
    // Carve paths using recursive backtracking
    const stack: { x: number; y: number }[] = [];
    const visited = new Set<string>();
    
    const startX = 1;
    const startY = 1;
    
    const carveCell = (x: number, y: number) => {
      grid[y][x].type = CellType.EMPTY;
      grid[y][x].isWall = false;
      grid[y][x].cost = 1;
      visited.add(`${x},${y}`);
    };
    
    carveCell(startX, startY);
    stack.push({ x: startX, y: startY });
    
    while (stack.length > 0) {
      const current = stack[stack.length - 1];
      const neighbors = [];
      
      // Check all four directions, but skip by 2 to leave walls
      const directions = [
        { x: 0, y: -2 }, // up
        { x: 2, y: 0 },  // right
        { x: 0, y: 2 },  // down
        { x: -2, y: 0 }  // left
      ];
      
      for (const dir of directions) {
        const nx = current.x + dir.x;
        const ny = current.y + dir.y;
        
        if (nx > 0 && nx < gridSize - 1 && ny > 0 && ny < gridSize - 1) {
          if (!visited.has(`${nx},${ny}`)) {
            neighbors.push({ x: nx, y: ny, wallX: current.x + dir.x / 2, wallY: current.y + dir.y / 2 });
          }
        }
      }
      
      if (neighbors.length > 0) {
        const next = neighbors[Math.floor(Math.random() * neighbors.length)];
        
        // Carve the wall between current and next
        carveCell(next.wallX, next.wallY);
        carveCell(next.x, next.y);
        
        stack.push({ x: next.x, y: next.y });
      } else {
        stack.pop();
      }
    }
    
    onGenerateMaze(grid);
  };

  return (
    <div className={`p-6 max-h-none overflow-visible ${className}`}>
      <div className="mb-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-cyan-500"></div>
          Maze Generator
        </h3>
        <div className="h-0.5 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full"></div>
      </div>
      <div className="space-y-6">
        <div className="p-4 bg-gradient-to-r from-cyan-50 to-blue-50 rounded-xl border border-cyan-200/50">
          <div className="flex justify-between items-center mb-3">
            <label className="font-bold text-gray-800">Wall Density</label>
            <span className="text-lg font-bold text-cyan-600">{wallDensity}%</span>
          </div>
          <Slider
            value={[wallDensity]}
            onValueChange={(value) => setWallDensity(value[0])}
            min={10}
            max={60}
            step={5}
            className="w-full"
          />
        </div>
        
        <div className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 rounded-xl border border-purple-200/50">
          <div className="flex justify-between items-center mb-3">
            <label className="font-bold text-gray-800">Terrain Density</label>
            <span className="text-lg font-bold text-purple-600">{terrainDensity}%</span>
          </div>
          <Slider
            value={[terrainDensity]}
            onValueChange={(value) => setTerrainDensity(value[0])}
            min={0}
            max={40}
            step={5}
            className="w-full"
          />
        </div>
        
        <div className="space-y-3">
          <Button
            onClick={generateMaze}
            className="w-full h-12 transition-all duration-200 hover:bg-gradient-to-r hover:from-blue-500 hover:to-cyan-500 hover:text-white hover:shadow-lg hover:transform hover:scale-105"
            variant="outline"
          >
            <Shuffle className="w-4 h-4 mr-3" />
            <span className="font-medium">Generate Random Maze</span>
          </Button>
          
          <Button
            onClick={generateLabyrinth}
            className="w-full h-12 transition-all duration-200 hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 hover:text-white hover:shadow-lg hover:transform hover:scale-105"
            variant="outline"
          >
            <Shuffle className="w-4 h-4 mr-3" />
            <span className="font-medium">Generate Labyrinth</span>
          </Button>
        </div>
        
        <div className="p-4 bg-gradient-to-r from-gray-50 to-slate-50 rounded-xl border border-gray-200/50">
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span className="font-medium text-gray-700">Random Maze:</span>
              <span className="text-gray-600">Scattered walls and terrain</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              <span className="font-medium text-gray-700">Labyrinth:</span>
              <span className="text-gray-600">Connected pathways with dead ends</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
