import React from 'react';
import { Clock, Route, Target, Activity } from 'lucide-react';
import { AlgorithmResult, AlgorithmType } from '../../lib/pathfinding/types';

interface RunningStatsProps {
  currentAlgorithm: AlgorithmType | null;
  isRunning: boolean;
  results: Map<AlgorithmType, AlgorithmResult>;
  startTime?: number;
}

export const RunningStats: React.FC<RunningStatsProps> = ({ 
  currentAlgorithm, 
  isRunning, 
  results,
  startTime 
}) => {
  const [elapsedTime, setElapsedTime] = React.useState(0);

  React.useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRunning && startTime) {
      interval = setInterval(() => {
        setElapsedTime(Date.now() - startTime);
      }, 10);
    } else {
      setElapsedTime(0);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRunning, startTime]);

  const formatTime = (ms: number) => {
    if (ms < 1000) return `${ms.toFixed(0)}ms`;
    return `${(ms / 1000).toFixed(2)}s`;
  };

  const currentResult = currentAlgorithm ? results.get(currentAlgorithm) : null;
  const totalSituationsTested = Array.from(results.values()).reduce(
    (total, result) => total + result.nodesExplored, 0
  );

  return (
    <div className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl border border-indigo-200/50 shadow-lg">
      <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
        <Activity className="w-4 h-4 text-indigo-600" />
        Live Algorithm Stats
      </h4>
      
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {/* Running Time */}
        <div className="bg-white/60 rounded-lg p-3 text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Clock className="w-3 h-3 text-blue-600" />
            <span className="text-xs font-medium text-gray-600">Runtime</span>
          </div>
          <div className={`font-bold text-lg ${isRunning ? 'text-blue-600 animate-pulse' : 'text-gray-700'}`}>
            {isRunning ? formatTime(elapsedTime) : 
             currentResult ? formatTime(currentResult.executionTime) : '0ms'}
          </div>
        </div>

        {/* Path Length */}
        <div className="bg-white/60 rounded-lg p-3 text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Route className="w-3 h-3 text-green-600" />
            <span className="text-xs font-medium text-gray-600">Path Length</span>
          </div>
          <div className="font-bold text-lg text-gray-700">
            {currentResult?.found ? currentResult.pathLength : 
             isRunning ? '...' : '0'} steps
          </div>
        </div>

        {/* Nodes Explored */}
        <div className="bg-white/60 rounded-lg p-3 text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Target className="w-3 h-3 text-purple-600" />
            <span className="text-xs font-medium text-gray-600">Nodes Tested</span>
          </div>
          <div className="font-bold text-lg text-gray-700">
            {currentResult ? currentResult.nodesExplored : 
             results.size > 0 ? totalSituationsTested : '0'}
          </div>
        </div>

        {/* Algorithm Status */}
        <div className="bg-white/60 rounded-lg p-3 text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Activity className="w-3 h-3 text-orange-600" />
            <span className="text-xs font-medium text-gray-600">Status</span>
          </div>
          <div className={`font-bold text-sm ${
            isRunning ? 'text-orange-600' : 
            currentResult?.found ? 'text-green-600' : 'text-gray-600'
          }`}>
            {isRunning ? 'Running...' : 
             currentResult?.found ? 'Found!' : 
             results.size > 0 ? 'Complete' : 'Ready'}
          </div>
        </div>
      </div>

      {/* Path Highlighting Indicator */}
      {currentResult?.found && (
        <div className="mt-3 p-2 bg-orange-100 rounded-lg border border-orange-200">
          <div className="flex items-center justify-center gap-2 text-orange-700">
            <div className="w-3 h-3 bg-orange-500 rounded-full animate-pulse"></div>
            <span className="text-sm font-medium">Path highlighted in orange on grid</span>
          </div>
        </div>
      )}

      {/* Multiple Results Summary */}
      {results.size > 1 && (
        <div className="mt-3 p-2 bg-purple-100 rounded-lg border border-purple-200">
          <div className="text-center text-purple-700">
            <span className="text-sm font-medium">
              Compared {results.size} algorithms • {totalSituationsTested} total nodes tested
            </span>
          </div>
        </div>
      )}
    </div>
  );
};