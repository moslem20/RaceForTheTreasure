import React from 'react';
import { RedesignedGameBoard } from './components/game/RedesignedGameBoard';

function App() {
  return (
    <RedesignedGameBoard />
  );
}

export default App;
