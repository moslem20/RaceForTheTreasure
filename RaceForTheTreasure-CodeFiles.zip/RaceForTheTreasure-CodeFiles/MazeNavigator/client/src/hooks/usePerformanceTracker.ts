import { useEffect, useRef } from 'react';
import { GameState } from '../types/game';

export interface DetailedPerformanceMetrics {
  // Basic metrics
  totalGamesPlayed: number;
  winsByDifficulty: { easy: number; normal: number; hard: number };
  lossesByDifficulty: { easy: number; normal: number; hard: number };
  
  // Advanced gameplay metrics
  averageMovesPerGame: number;
  averageToolsUsedPerGame: number;
  averageGameDuration: number;
  treasureCollectionEfficiency: number; // treasures collected / game duration
  
  // Strategic metrics
  wallPlacementSuccess: number; // walls that actually helped
  ladderUsageOptimization: number; // ladders used efficiently
  powerUpActivationTiming: number; // power-ups used at optimal times
  
  // Decision-making metrics
  movesPerTurn: number;
  backtrackingRate: number; // how often player reverses direction
  explorationCompleteness: number; // % of map explored before winning
  
  // Adaptation metrics
  improvementTrend: number; // performance trend over last 5 games
  difficultyProgression: ('easy' | 'normal' | 'hard')[];
  learningCurve: number; // improvement rate over time
  
  // Time-based metrics
  firstMoveTime: number; // time to make first move (decision speed)
  averageThinkingTime: number; // average time between moves
  gameSessionLength: number; // how long player plays in one session
  
  // Contextual performance
  morningPerformance: number; // win rate in morning
  afternoonPerformance: number; // win rate in afternoon
  eveningPerformance: number; // win rate in evening
}

export const usePerformanceTracker = () => {
  const gameStartTime = useRef<number>(0);
  const moveStartTime = useRef<number>(0);
  const currentGameMetrics = useRef({
    moves: 0,
    toolsUsed: 0,
    backtrackingCount: 0,
    powerUpUsage: 0,
    exploredTiles: new Set<string>(),
    moveTimes: [] as number[],
    lastPosition: { row: -1, col: -1 }
  });

  const initializeGameTracking = (gameState: GameState) => {
    gameStartTime.current = Date.now();
    moveStartTime.current = Date.now();
    currentGameMetrics.current = {
      moves: 0,
      toolsUsed: 0,
      backtrackingCount: 0,
      powerUpUsage: 0,
      exploredTiles: new Set(),
      moveTimes: [],
      lastPosition: { row: -1, col: -1 }
    };
  };

  const trackMove = (gameState: GameState, newPosition: { row: number; col: number }) => {
    const now = Date.now();
    const moveTime = now - moveStartTime.current;
    
    currentGameMetrics.current.moves++;
    currentGameMetrics.current.moveTimes.push(moveTime);
    currentGameMetrics.current.exploredTiles.add(`${newPosition.row}-${newPosition.col}`);
    
    // Track backtracking
    const lastPos = currentGameMetrics.current.lastPosition;
    if (lastPos.row !== -1 && lastPos.col !== -1) {
      const distance = Math.abs(newPosition.row - lastPos.row) + Math.abs(newPosition.col - lastPos.col);
      if (distance > 2) { // Significant position change might indicate backtracking
        currentGameMetrics.current.backtrackingCount++;
      }
    }
    
    currentGameMetrics.current.lastPosition = newPosition;
    moveStartTime.current = now;
  };

  const trackToolUsage = (toolType: 'wall' | 'ladder') => {
    currentGameMetrics.current.toolsUsed++;
  };

  const trackPowerUpUsage = () => {
    currentGameMetrics.current.powerUpUsage++;
  };

  const finalizeGameMetrics = (gameState: GameState, gameResult: 'won' | 'lost' | 'draw'): void => {
    const gameEndTime = Date.now();
    const gameDuration = gameEndTime - gameStartTime.current;
    const currentHour = new Date().getHours();
    
    // Load existing performance data
    const existingData = localStorage.getItem('treasureQuest_detailedPerformance');
    const performance: DetailedPerformanceMetrics = existingData 
      ? JSON.parse(existingData)
      : {
          totalGamesPlayed: 0,
          winsByDifficulty: { easy: 0, normal: 0, hard: 0 },
          lossesByDifficulty: { easy: 0, normal: 0, hard: 0 },
          averageMovesPerGame: 0,
          averageToolsUsedPerGame: 0,
          averageGameDuration: 0,
          treasureCollectionEfficiency: 0,
          wallPlacementSuccess: 0,
          ladderUsageOptimization: 0,
          powerUpActivationTiming: 0,
          movesPerTurn: 0,
          backtrackingRate: 0,
          explorationCompleteness: 0,
          improvementTrend: 0,
          difficultyProgression: [],
          learningCurve: 0,
          firstMoveTime: 0,
          averageThinkingTime: 0,
          gameSessionLength: 0,
          morningPerformance: 0,
          afternoonPerformance: 0,
          eveningPerformance: 0
        };

    // Update basic metrics
    performance.totalGamesPlayed++;
    performance.difficultyProgression.push(gameState.difficulty);
    
    // Update win/loss by difficulty
    if (gameResult === 'won') {
      performance.winsByDifficulty[gameState.difficulty]++;
    } else if (gameResult === 'lost') {
      performance.lossesByDifficulty[gameState.difficulty]++;
    }

    // Update averages using incremental formula
    const gameCount = performance.totalGamesPlayed;
    performance.averageMovesPerGame = updateAverage(performance.averageMovesPerGame, currentGameMetrics.current.moves, gameCount);
    performance.averageToolsUsedPerGame = updateAverage(performance.averageToolsUsedPerGame, currentGameMetrics.current.toolsUsed, gameCount);
    performance.averageGameDuration = updateAverage(performance.averageGameDuration, gameDuration, gameCount);

    // Calculate complex metrics
    const treasuresCollected = gameState.playerResources.human.treasuresCollected;
    const treasureEfficiency = treasuresCollected / (gameDuration / 60000); // treasures per minute
    performance.treasureCollectionEfficiency = updateAverage(performance.treasureCollectionEfficiency, treasureEfficiency, gameCount);

    // Calculate exploration completeness
    const explorationRate = (currentGameMetrics.current.exploredTiles.size / 100) * 100;
    performance.explorationCompleteness = updateAverage(performance.explorationCompleteness, explorationRate, gameCount);

    // Calculate backtracking rate
    const backtrackRate = currentGameMetrics.current.moves > 0 
      ? (currentGameMetrics.current.backtrackingCount / currentGameMetrics.current.moves) * 100 
      : 0;
    performance.backtrackingRate = updateAverage(performance.backtrackingRate, backtrackRate, gameCount);

    // Calculate moves per turn
    const movesPerTurn = gameState.gameStats.turnCount > 0 
      ? currentGameMetrics.current.moves / gameState.gameStats.turnCount 
      : 1;
    performance.movesPerTurn = updateAverage(performance.movesPerTurn, movesPerTurn, gameCount);

    // Calculate thinking time metrics
    if (currentGameMetrics.current.moveTimes.length > 0) {
      const firstMove = currentGameMetrics.current.moveTimes[0];
      const avgThinking = currentGameMetrics.current.moveTimes.reduce((a, b) => a + b, 0) / currentGameMetrics.current.moveTimes.length;
      
      performance.firstMoveTime = updateAverage(performance.firstMoveTime, firstMove, gameCount);
      performance.averageThinkingTime = updateAverage(performance.averageThinkingTime, avgThinking, gameCount);
    }

    // Update time-based performance
    const timeOfDayWinRate = gameResult === 'won' ? 1 : 0;
    if (currentHour >= 6 && currentHour < 12) {
      performance.morningPerformance = updateAverage(performance.morningPerformance, timeOfDayWinRate, Math.floor(gameCount / 3) + 1);
    } else if (currentHour >= 12 && currentHour < 18) {
      performance.afternoonPerformance = updateAverage(performance.afternoonPerformance, timeOfDayWinRate, Math.floor(gameCount / 3) + 1);
    } else {
      performance.eveningPerformance = updateAverage(performance.eveningPerformance, timeOfDayWinRate, Math.floor(gameCount / 3) + 1);
    }

    // Calculate improvement trend (last 5 games)
    const recentGames = performance.difficultyProgression.slice(-5);
    const recentWins = recentGames.reduce((wins, difficulty) => {
      return wins + (performance.winsByDifficulty[difficulty] > 0 ? 1 : 0);
    }, 0);
    performance.improvementTrend = recentGames.length > 0 ? (recentWins / recentGames.length) * 100 : 0;

    // Calculate learning curve (improvement over time)
    if (gameCount > 5) {
      const earlyWinRate = getWinRateForGames(performance, 1, 5);
      const recentWinRate = getWinRateForGames(performance, gameCount - 4, gameCount);
      performance.learningCurve = recentWinRate - earlyWinRate;
    }

    // Save updated performance
    localStorage.setItem('treasureQuest_detailedPerformance', JSON.stringify(performance));
  };

  const updateAverage = (currentAvg: number, newValue: number, count: number): number => {
    return (currentAvg * (count - 1) + newValue) / count;
  };

  const getWinRateForGames = (performance: DetailedPerformanceMetrics, startGame: number, endGame: number): number => {
    const totalWins = Object.values(performance.winsByDifficulty).reduce((a, b) => a + b, 0);
    const totalLosses = Object.values(performance.lossesByDifficulty).reduce((a, b) => a + b, 0);
    const totalGames = totalWins + totalLosses;
    
    if (totalGames === 0) return 0;
    return (totalWins / totalGames) * 100;
  };

  const getDetailedPerformance = (): DetailedPerformanceMetrics | null => {
    const data = localStorage.getItem('treasureQuest_detailedPerformance');
    return data ? JSON.parse(data) : null;
  };

  const resetPerformanceData = () => {
    localStorage.removeItem('treasureQuest_detailedPerformance');
  };

  return {
    initializeGameTracking,
    trackMove,
    trackToolUsage,
    trackPowerUpUsage,
    finalizeGameMetrics,
    getDetailedPerformance,
    resetPerformanceData
  };
};