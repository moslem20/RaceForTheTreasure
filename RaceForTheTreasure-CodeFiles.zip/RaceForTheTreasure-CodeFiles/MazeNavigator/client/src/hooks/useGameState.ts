import React, { useState, useCallback, useEffect } from 'react';
import { GameState, Position, GameStatus, ActionType, PowerUpType } from '../types/game';

const generateObstacles = (treasure: Position, humanStart: Position, aiStart: Position): { 
  walls: Position[], 
  ladders: Position[], 
  highCostTiles: Position[],
  trapTiles: Position[],
  powerUps: Position[]
} => {
  const walls: Position[] = [];
  const ladders: Position[] = [];
  const highCostTiles: Position[] = [];
  const trapTiles: Position[] = [];
  const powerUps: Position[] = [];
  
  const occupiedPositions = [treasure, humanStart, aiStart];
  
  // Generate 8-12 random walls
  const numWalls = Math.floor(Math.random() * 5) + 8;
  for (let i = 0; i < numWalls; i++) {
    let wallPos: Position;
    let attempts = 0;
    do {
      wallPos = {
        row: Math.floor(Math.random() * 10),
        col: Math.floor(Math.random() * 10)
      };
      attempts++;
    } while (
      (occupiedPositions.some(pos => pos.row === wallPos.row && pos.col === wallPos.col) ||
       walls.some(pos => pos.row === wallPos.row && pos.col === wallPos.col)) &&
      attempts < 50
    );
    
    if (attempts < 50) {
      walls.push(wallPos);
    }
  }
  
  // Generate 3-5 ladders
  const numLadders = Math.floor(Math.random() * 3) + 3;
  for (let i = 0; i < numLadders; i++) {
    let ladderPos: Position;
    let attempts = 0;
    do {
      ladderPos = {
        row: Math.floor(Math.random() * 10),
        col: Math.floor(Math.random() * 10)
      };
      attempts++;
    } while (
      (occupiedPositions.some(pos => pos.row === ladderPos.row && pos.col === ladderPos.col) ||
       walls.some(pos => pos.row === ladderPos.row && pos.col === ladderPos.col) ||
       ladders.some(pos => pos.row === ladderPos.row && pos.col === ladderPos.col)) &&
      attempts < 50
    );
    
    if (attempts < 50) {
      ladders.push(ladderPos);
    }
  }
  
  // Generate 5-8 high cost tiles
  const numHighCost = Math.floor(Math.random() * 4) + 5;
  for (let i = 0; i < numHighCost; i++) {
    let highCostPos: Position;
    let attempts = 0;
    do {
      highCostPos = {
        row: Math.floor(Math.random() * 10),
        col: Math.floor(Math.random() * 10)
      };
      attempts++;
    } while (
      (occupiedPositions.some(pos => pos.row === highCostPos.row && pos.col === highCostPos.col) ||
       walls.some(pos => pos.row === highCostPos.row && pos.col === highCostPos.col) ||
       ladders.some(pos => pos.row === highCostPos.row && pos.col === highCostPos.col) ||
       highCostTiles.some(pos => pos.row === highCostPos.row && pos.col === highCostPos.col)) &&
      attempts < 50
    );
    
    if (attempts < 50) {
      highCostTiles.push(highCostPos);
    }
  }
  
  // Generate 2-4 trap tiles
  const numTraps = Math.floor(Math.random() * 3) + 2;
  for (let i = 0; i < numTraps; i++) {
    let trapPos: Position;
    let attempts = 0;
    do {
      trapPos = {
        row: Math.floor(Math.random() * 10),
        col: Math.floor(Math.random() * 10)
      };
      attempts++;
    } while (
      (occupiedPositions.some(pos => pos.row === trapPos.row && pos.col === trapPos.col) ||
       walls.some(pos => pos.row === trapPos.row && pos.col === trapPos.col) ||
       ladders.some(pos => pos.row === trapPos.row && pos.col === trapPos.col) ||
       highCostTiles.some(pos => pos.row === trapPos.row && pos.col === trapPos.col) ||
       trapTiles.some(pos => pos.row === trapPos.row && pos.col === trapPos.col)) &&
      attempts < 50
    );
    
    if (attempts < 50) {
      trapTiles.push(trapPos);
    }
  }
  
  // Generate 1-3 power-ups
  const numPowerUps = Math.floor(Math.random() * 3) + 1;
  for (let i = 0; i < numPowerUps; i++) {
    let powerUpPos: Position;
    let attempts = 0;
    do {
      powerUpPos = {
        row: Math.floor(Math.random() * 10),
        col: Math.floor(Math.random() * 10)
      };
      attempts++;
    } while (
      (occupiedPositions.some(pos => pos.row === powerUpPos.row && pos.col === powerUpPos.col) ||
       walls.some(pos => pos.row === powerUpPos.row && pos.col === powerUpPos.col) ||
       ladders.some(pos => pos.row === powerUpPos.row && pos.col === powerUpPos.col) ||
       highCostTiles.some(pos => pos.row === powerUpPos.row && pos.col === powerUpPos.col) ||
       trapTiles.some(pos => pos.row === powerUpPos.row && pos.col === powerUpPos.col) ||
       powerUps.some(pos => pos.row === powerUpPos.row && pos.col === powerUpPos.col)) &&
      attempts < 50
    );
    
    if (attempts < 50) {
      powerUps.push(powerUpPos);
    }
  }
  
  return { walls, ladders, highCostTiles, trapTiles, powerUps };
};

const manhattanDistance = (pos1: Position, pos2: Position): number => {
  return Math.abs(pos1.row - pos2.row) + Math.abs(pos1.col - pos2.col);
};

// Advanced Strategic Decision Making System
const calculateBestStrategy = (gameState: GameState, humanPos: Position, aiPos: Position, nearestTreasure: Position): {
  action: 'move' | 'place_wall' | 'place_ladder',
  position: Position | null,
  reasoning: string,
  priority: number
} => {
  const strategies: Array<{
    action: 'move' | 'place_wall' | 'place_ladder',
    position: Position | null,
    reasoning: string,
    priority: number
  }> = [];

  const humanDistance = manhattanDistance(humanPos, nearestTreasure);
  const aiDistance = manhattanDistance(aiPos, nearestTreasure);
  const humanToAiDistance = manhattanDistance(humanPos, aiPos);

  // Strategy 1: Defensive Wall Placement
  if (gameState.playerResources.ai.walls > 0) {
    // Critical blocking - human is about to win
    if (humanDistance <= 2 && gameState.playerResources.human.treasuresCollected >= 1) {
      const blockingPos = findOptimalBlockingPosition(humanPos, nearestTreasure, gameState);
      if (blockingPos) {
        strategies.push({
          action: 'place_wall',
          position: blockingPos,
          reasoning: 'Critical defensive wall - preventing human victory',
          priority: 100
        });
      }
    }
    
    // Aggressive blocking - human is closer to treasure
    if (humanDistance < aiDistance && humanDistance <= 4) {
      const blockingPos = findOptimalBlockingPosition(humanPos, nearestTreasure, gameState);
      if (blockingPos) {
        strategies.push({
          action: 'place_wall',
          position: blockingPos,
          reasoning: 'Aggressive blocking - human closer to treasure',
          priority: 70 + (5 - humanDistance) * 5
        });
      }
    }

    // Strategic corridor creation
    if (humanToAiDistance <= 3 && aiDistance > humanDistance) {
      const corridorWall = findCorridorWallPosition(humanPos, aiPos, nearestTreasure, gameState);
      if (corridorWall) {
        strategies.push({
          action: 'place_wall',
          position: corridorWall,
          reasoning: 'Creating strategic corridor control',
          priority: 60
        });
      }
    }
  }

  // Strategy 2: Offensive Ladder Placement
  if (gameState.playerResources.ai.ladders > 0) {
    // High-cost terrain optimization
    const optimalLadderPos = findOptimalLadderPosition(aiPos, nearestTreasure, gameState);
    if (optimalLadderPos) {
      const ladderValue = calculateLadderValue(optimalLadderPos, aiPos, nearestTreasure, gameState);
      strategies.push({
        action: 'place_ladder',
        position: optimalLadderPos,
        reasoning: `Optimizing path through high-cost terrain (value: ${ladderValue})`,
        priority: 40 + ladderValue
      });
    }

    // Shortcut creation
    if (aiDistance > 6) {
      const shortcutLadder = findShortcutLadderPosition(aiPos, nearestTreasure, gameState);
      if (shortcutLadder) {
        strategies.push({
          action: 'place_ladder',
          position: shortcutLadder,
          reasoning: 'Creating efficient shortcut path',
          priority: 35
        });
      }
    }
  }

  // Strategy 3: Opportunistic Movement
  strategies.push({
    action: 'move',
    position: null,
    reasoning: 'Standard movement toward treasure',
    priority: 20
  });

  // Sort strategies by priority and return the best one
  strategies.sort((a, b) => b.priority - a.priority);
  return strategies[0] || { action: 'move', position: null, reasoning: 'Default movement', priority: 0 };
};

// Find optimal position to block human's path
const findOptimalBlockingPosition = (humanPos: Position, treasurePos: Position, gameState: GameState): Position | null => {
  const candidates: Array<{ pos: Position, score: number }> = [];
  
  // Positions directly between human and treasure
  const pathPositions = calculateDirectPath(humanPos, treasurePos);
  
  // Positions around human
  const surroundingPositions = [
    { row: humanPos.row - 1, col: humanPos.col },
    { row: humanPos.row + 1, col: humanPos.col },
    { row: humanPos.row, col: humanPos.col - 1 },
    { row: humanPos.row, col: humanPos.col + 1 },
    { row: humanPos.row - 1, col: humanPos.col - 1 },
    { row: humanPos.row - 1, col: humanPos.col + 1 },
    { row: humanPos.row + 1, col: humanPos.col - 1 },
    { row: humanPos.row + 1, col: humanPos.col + 1 }
  ];

  const allCandidates = [...pathPositions.slice(1, 4), ...surroundingPositions];

  for (const pos of allCandidates) {
    if (isValidWallPlacement(pos, gameState)) {
      let score = 0;
      
      // Higher score for positions on direct path
      if (pathPositions.some(p => p.row === pos.row && p.col === pos.col)) {
        score += 50;
      }
      
      // Higher score for positions closer to human
      const distanceToHuman = manhattanDistance(pos, humanPos);
      score += (4 - distanceToHuman) * 10;
      
      // Higher score for positions that create bottlenecks
      const bottleneckScore = calculateBottleneckScore(pos, gameState);
      score += bottleneckScore;
      
      candidates.push({ pos, score });
    }
  }

  candidates.sort((a, b) => b.score - a.score);
  return candidates.length > 0 ? candidates[0].pos : null;
};

// Calculate direct path between two positions
const calculateDirectPath = (start: Position, end: Position): Position[] => {
  const path: Position[] = [];
  let current = { ...start };
  
  while (current.row !== end.row || current.col !== end.col) {
    if (current.row < end.row) current.row++;
    else if (current.row > end.row) current.row--;
    else if (current.col < end.col) current.col++;
    else if (current.col > end.col) current.col--;
    
    path.push({ ...current });
    
    if (path.length > 15) break; // Prevent infinite loops
  }
  
  return path;
};

// Find optimal ladder position for AI
const findOptimalLadderPosition = (aiPos: Position, treasurePos: Position, gameState: GameState): Position | null => {
  const candidates: Array<{ pos: Position, value: number }> = [];
  
  // Positions near AI and on path to treasure
  const searchPositions = [
    { row: aiPos.row - 1, col: aiPos.col },
    { row: aiPos.row + 1, col: aiPos.col },
    { row: aiPos.row, col: aiPos.col - 1 },
    { row: aiPos.row, col: aiPos.col + 1 },
    { row: aiPos.row - 2, col: aiPos.col },
    { row: aiPos.row + 2, col: aiPos.col },
    { row: aiPos.row, col: aiPos.col - 2 },
    { row: aiPos.row, col: aiPos.col + 2 }
  ];

  for (const pos of searchPositions) {
    if (isValidWallPlacement(pos, gameState)) {
      const value = calculateLadderValue(pos, aiPos, treasurePos, gameState);
      if (value > 0) {
        candidates.push({ pos, value });
      }
    }
  }

  candidates.sort((a, b) => b.value - a.value);
  return candidates.length > 0 ? candidates[0].pos : null;
};

// Calculate the value of placing a ladder at a position
const calculateLadderValue = (ladderPos: Position, aiPos: Position, treasurePos: Position, gameState: GameState): number => {
  let value = 0;
  
  // High value for high-cost terrain
  const isHighCost = gameState.highCostTiles.some(tile => 
    tile.row === ladderPos.row && tile.col === ladderPos.col
  );
  if (isHighCost) value += 30;
  
  // Value based on position relative to treasure path
  const distanceToTreasure = manhattanDistance(ladderPos, treasurePos);
  const distanceToAI = manhattanDistance(ladderPos, aiPos);
  
  if (distanceToAI <= 2 && distanceToTreasure < manhattanDistance(aiPos, treasurePos)) {
    value += 20;
  }
  
  return value;
};

// Find corridor wall position for strategic control
const findCorridorWallPosition = (humanPos: Position, aiPos: Position, treasurePos: Position, gameState: GameState): Position | null => {
  // Find positions that create advantageous corridors
  const midpoint = {
    row: Math.floor((humanPos.row + treasurePos.row) / 2),
    col: Math.floor((humanPos.col + treasurePos.col) / 2)
  };
  
  const corridorPositions = [
    { row: midpoint.row - 1, col: midpoint.col },
    { row: midpoint.row + 1, col: midpoint.col },
    { row: midpoint.row, col: midpoint.col - 1 },
    { row: midpoint.row, col: midpoint.col + 1 }
  ];
  
  for (const pos of corridorPositions) {
    if (isValidWallPlacement(pos, gameState)) {
      return pos;
    }
  }
  
  return null;
};

// Find shortcut ladder position
const findShortcutLadderPosition = (aiPos: Position, treasurePos: Position, gameState: GameState): Position | null => {
  const directPath = calculateDirectPath(aiPos, treasurePos);
  
  for (const pos of directPath.slice(1, 4)) {
    if (isValidWallPlacement(pos, gameState)) {
      const isHighCost = gameState.highCostTiles.some(tile => 
        tile.row === pos.row && tile.col === pos.col
      );
      if (isHighCost) return pos;
    }
  }
  
  return null;
};

// Calculate bottleneck score for strategic positioning
const calculateBottleneckScore = (pos: Position, gameState: GameState): number => {
  let score = 0;
  
  // Check adjacent walls
  const adjacentWalls = gameState.walls.filter(wall => 
    manhattanDistance(wall, pos) === 1
  ).length;
  
  score += adjacentWalls * 15;
  
  // Check for creating narrow passages
  const nearbyWalls = gameState.walls.filter(wall => 
    manhattanDistance(wall, pos) <= 2
  ).length;
  
  score += nearbyWalls * 5;
  
  return score;
};

// Check if position is valid for wall/ladder placement
const isValidWallPlacement = (pos: Position, gameState: GameState): boolean => {
  // Check bounds
  if (pos.row < 0 || pos.row >= 10 || pos.col < 0 || pos.col >= 10) return false;
  
  // Check for existing obstacles
  if (gameState.walls.some(wall => wall.row === pos.row && wall.col === pos.col)) return false;
  if (gameState.ladders.some(ladder => ladder.row === pos.row && ladder.col === pos.col)) return false;
  if (gameState.treasures.some(treasure => treasure.row === pos.row && treasure.col === pos.col)) return false;
  
  // Check for player positions
  if (pos.row === gameState.players.human.row && pos.col === gameState.players.human.col) return false;
  if (pos.row === gameState.players.ai.row && pos.col === gameState.players.ai.col) return false;
  
  return true;
};

// Calculate optimal move for AI with difficulty-based intelligence
const calculateOptimalMove = (
  gameState: GameState, 
  aiPos: Position, 
  treasurePos: Position, 
  humanPos: Position, 
  difficulty: 'easy' | 'normal' | 'hard'
): Position | null => {
  const directions = [
    { row: -1, col: 0 }, { row: 1, col: 0 },
    { row: 0, col: -1 }, { row: 0, col: 1 }
  ];

  const candidates: Array<{ pos: Position, score: number }> = [];

  for (const dir of directions) {
    const newPos = { row: aiPos.row + dir.row, col: aiPos.col + dir.col };
    if (isValidMove(aiPos, newPos, gameState)) {
      let score = 0;

      // Base scoring: distance to treasure
      const treasureDistance = manhattanDistance(newPos, treasurePos);
      score += (15 - treasureDistance) * 5;

      // Terrain optimization
      const isLadder = gameState.ladders.some(ladder => 
        ladder.row === newPos.row && ladder.col === newPos.col);
      const isHighCost = gameState.highCostTiles.some(tile => 
        tile.row === newPos.row && tile.col === newPos.col);
      const isPowerUp = gameState.powerUps.some(powerUp => 
        powerUp.row === newPos.row && powerUp.col === newPos.col);
      
      if (isLadder) score += 15; // Prioritize free movement
      if (isHighCost) score -= 10; // Avoid high-cost terrain when possible
      if (isPowerUp) score += 25; // High priority for power-ups

      // Difficulty-based strategic adjustments
      if (difficulty === 'hard') {
        // Advanced strategic thinking
        score += calculateAdvancedMoveScore(newPos, gameState, humanPos, treasurePos);
      } else if (difficulty === 'normal') {
        // Moderate strategic awareness
        score += calculateModerateMoveScore(newPos, gameState, humanPos, treasurePos);
      }
      // Easy mode uses only basic distance scoring

      // Avoid traps
      const isTrap = gameState.trapTiles.some(trap => 
        trap.row === newPos.row && trap.col === newPos.col);
      if (isTrap) score -= 30;

      // Energy efficiency
      const energyCost = getMovementCost(newPos, gameState);
      score -= energyCost * 2;

      candidates.push({ pos: newPos, score });
    }
  }

  // Sort by score and return best move
  candidates.sort((a, b) => b.score - a.score);
  return candidates.length > 0 ? candidates[0].pos : null;
};

// Advanced move scoring for hard difficulty
const calculateAdvancedMoveScore = (
  pos: Position, 
  gameState: GameState, 
  humanPos: Position, 
  treasurePos: Position
): number => {
  let score = 0;

  // Positional advantage relative to human
  const humanToTreasureDistance = manhattanDistance(humanPos, treasurePos);
  const aiToTreasureFromPos = manhattanDistance(pos, treasurePos);
  
  if (aiToTreasureFromPos < humanToTreasureDistance) {
    score += 20; // Bonus for being closer to treasure than human
  }

  // Strategic positioning to control key areas
  const humanToAiDistance = manhattanDistance(pos, humanPos);
  if (humanToAiDistance >= 3 && humanToAiDistance <= 5) {
    score += 10; // Optimal distance to maintain pressure
  }

  // Path optimization - look ahead 2 moves
  const pathScore = calculatePathEfficiency(pos, treasurePos, gameState);
  score += pathScore;

  // Defensive positioning if human is close to victory
  if (gameState.playerResources.human.treasuresCollected >= 1) {
    const blockingValue = calculateBlockingValue(pos, humanPos, treasurePos);
    score += blockingValue;
  }

  return score;
};

// Moderate move scoring for normal difficulty
const calculateModerateMoveScore = (
  pos: Position, 
  gameState: GameState, 
  humanPos: Position, 
  treasurePos: Position
): number => {
  let score = 0;

  // Basic strategic awareness
  const humanToTreasureDistance = manhattanDistance(humanPos, treasurePos);
  const aiToTreasureFromPos = manhattanDistance(pos, treasurePos);
  
  if (aiToTreasureFromPos < humanToTreasureDistance) {
    score += 10; // Moderate bonus for positional advantage
  }

  // Maintain reasonable distance from human
  const humanToAiDistance = manhattanDistance(pos, humanPos);
  if (humanToAiDistance > 2) {
    score += 5; // Slight preference for spacing
  }

  return score;
};

// Calculate path efficiency for look-ahead planning
const calculatePathEfficiency = (start: Position, target: Position, gameState: GameState): number => {
  let efficiency = 0;
  
  // Simple 2-step lookahead
  const directPath = calculateDirectPath(start, target);
  if (directPath.length >= 2) {
    const nextStep = directPath[1];
    
    // Check if next step is beneficial
    const isLadder = gameState.ladders.some(ladder => 
      ladder.row === nextStep.row && ladder.col === nextStep.col);
    const isHighCost = gameState.highCostTiles.some(tile => 
      tile.row === nextStep.row && tile.col === nextStep.col);
    
    if (isLadder) efficiency += 10;
    if (isHighCost) efficiency -= 5;
  }
  
  return efficiency;
};

// Calculate blocking value for defensive positioning
const calculateBlockingValue = (aiPos: Position, humanPos: Position, treasurePos: Position): number => {
  // Calculate if AI position could interfere with human's path
  const humanToTreasure = manhattanDistance(humanPos, treasurePos);
  const aiToHuman = manhattanDistance(aiPos, humanPos);
  const aiToTreasure = manhattanDistance(aiPos, treasurePos);
  
  // Higher value if AI can intercept human's path
  if (aiToHuman <= 2 && aiToTreasure < humanToTreasure) {
    return 15;
  }
  
  return 0;
};

// Get movement cost for energy calculation
const getMovementCost = (pos: Position, gameState: GameState): number => {
  const isHighCost = gameState.highCostTiles.some(tile => 
    tile.row === pos.row && tile.col === pos.col);
  const isLadder = gameState.ladders.some(ladder => 
    ladder.row === pos.row && ladder.col === pos.col);
  
  if (isLadder) return 0; // Ladders are free movement
  if (isHighCost) return 2; // High-cost terrain
  return 1; // Normal movement cost
};





const generateEqualDistancePositions = (): { treasure: Position, humanStart: Position, aiStart: Position } => {
  let treasure: Position, humanStart: Position, aiStart: Position;
  let attempts = 0;
  
  do {
    treasure = {
      row: Math.floor(Math.random() * 8) + 1, // Avoid edges
      col: Math.floor(Math.random() * 8) + 1
    };
    
    humanStart = {
      row: Math.floor(Math.random() * 10),
      col: Math.floor(Math.random() * 10)
    };
    
    aiStart = {
      row: Math.floor(Math.random() * 10),
      col: Math.floor(Math.random() * 10)
    };
    
    attempts++;
  } while (
    (manhattanDistance(humanStart, treasure) !== manhattanDistance(aiStart, treasure) ||
     manhattanDistance(humanStart, aiStart) < 3 ||
     (humanStart.row === treasure.row && humanStart.col === treasure.col) ||
     (aiStart.row === treasure.row && aiStart.col === treasure.col) ||
     (humanStart.row === aiStart.row && humanStart.col === aiStart.col)) &&
    attempts < 100
  );
  
  return { treasure, humanStart, aiStart };
};

export const useGameState = () => {
  const [gameState, setGameState] = useState<GameState>(() => {
    const { treasure, humanStart, aiStart } = generateEqualDistancePositions();
    const obstacles = generateObstacles(treasure, humanStart, aiStart);
    
    // Generate multiple treasures for advanced gameplay
    const treasures = [treasure];
    for (let i = 1; i < 3; i++) {
      const newTreasure = {
        row: Math.floor(Math.random() * 8) + 1,
        col: Math.floor(Math.random() * 8) + 1
      };
      treasures.push(newTreasure);
    }
    
    // Generate keys and gates
    const keys = [];
    const gates = [];
    for (let i = 0; i < 2; i++) {
      keys.push({
        row: Math.floor(Math.random() * 10),
        col: Math.floor(Math.random() * 10)
      });
      gates.push({
        row: Math.floor(Math.random() * 10),
        col: Math.floor(Math.random() * 10)
      });
    }
    
    // Generate guards
    const guards = [{
      id: 'guard1',
      position: { row: 5, col: 5 },
      direction: 'up' as const,
      speed: 2,
      lastMoveTime: 0
    }];
    
    return {
      players: {
        human: humanStart,
        ai: aiStart
      },
      treasures,
      walls: obstacles.walls,
      ladders: obstacles.ladders,
      highCostTiles: obstacles.highCostTiles,
      trapTiles: obstacles.trapTiles,
      powerUps: obstacles.powerUps,
      keys,
      gates,
      guards,
      fogOfWar: false,
      visibleTiles: {
        human: [],
        ai: []
      },
      playerResources: {
        human: { 
          walls: 3, 
          ladders: 2,
          energy: 10,
          maxEnergy: 10,
          keysCollected: 0,
          treasuresCollected: 0,
          powerUps: {
            extraMovement: 0,
            ignoreWaterCost: 0,
            extraWalls: 0,
            extraLadders: 0
          },
          stunned: 0
        },
        ai: { 
          walls: 3, 
          ladders: 2,
          energy: 10,
          maxEnergy: 10,
          keysCollected: 0,
          treasuresCollected: 0,
          powerUps: {
            extraMovement: 0,
            ignoreWaterCost: 0,
            extraWalls: 0,
            extraLadders: 0
          },
          stunned: 0
        }
      },
      gameStats: {
        stepsHuman: 0,
        stepsAI: 0,
        tilesExplored: 0,
        toolsUsed: 0,
        turnCount: 0
      },
      difficulty: 'normal',
      theme: 'default'
    };
  });
  
  const [currentPlayer, setCurrentPlayer] = useState<'human' | 'ai'>('human');
  const [gameStatus, setGameStatus] = useState<GameStatus>('playing');
  const [moveCount, setMoveCount] = useState<number>(0);
  const [currentAction, setCurrentAction] = useState<ActionType>('move');

  // Give players initial power-ups for testing
  useEffect(() => {
    if (gameState.playerResources.human.powerUps.extraMovement === 0) {
      setGameState(prevState => ({
        ...prevState,
        playerResources: {
          ...prevState.playerResources,
          human: {
            ...prevState.playerResources.human,
            powerUps: {
              extraMovement: 2,
              ignoreWaterCost: 1,
              extraWalls: 1,
              extraLadders: 1
            }
          }
        }
      }));
    }
  }, []);

  const checkWinCondition = useCallback((state: GameState): GameStatus => {
    const { players, playerResources } = state;
    
    // EASY MODE: Check if either player has collected enough treasures (1 treasure for easy victory!)
    const humanWins = playerResources.human.treasuresCollected >= 1;
    const aiWins = playerResources.ai.treasuresCollected >= 1;
    
    if (humanWins && aiWins) return 'draw';
    if (humanWins) return 'human-won';
    if (aiWins) return 'ai-won';
    
    return 'playing';
  }, []);

  // Helper function to consume power-ups
  const consumePowerUp = useCallback((player: 'human' | 'ai', powerUpType: PowerUpType, state: GameState): GameState => {
    const playerResources = state.playerResources[player];
    if (playerResources.powerUps[powerUpType] > 0) {
      return {
        ...state,
        playerResources: {
          ...state.playerResources,
          [player]: {
            ...playerResources,
            powerUps: {
              ...playerResources.powerUps,
              [powerUpType]: playerResources.powerUps[powerUpType] - 1
            }
          }
        }
      };
    }
    return state;
  }, []);

  const handleTileEffects = useCallback((position: Position, player: 'human' | 'ai', state: GameState): GameState => {
    let newState = { ...state };
    
    // Check if player stepped on a trap
    const isTrap = state.trapTiles.some(trap => trap.row === position.row && trap.col === position.col);
    if (isTrap) {
      newState.playerResources = {
        ...newState.playerResources,
        [player]: {
          ...newState.playerResources[player],
          stunned: 2 // Stun for 2 turns
        }
      };
      console.log(`${player} stepped on a trap and is stunned for 2 turns!`);
    }
    
    // Check if player stepped on a power-up
    const isPowerUp = state.powerUps.some(powerUp => powerUp.row === position.row && powerUp.col === position.col);
    if (isPowerUp) {
      // Remove the power-up from the board
      newState.powerUps = newState.powerUps.filter(powerUp => !(powerUp.row === position.row && powerUp.col === position.col));
      
      // Grant a random power-up
      const powerUpTypes: PowerUpType[] = ['extraMovement', 'ignoreWaterCost', 'extraWalls', 'extraLadders'];
      const randomPowerUp = powerUpTypes[Math.floor(Math.random() * powerUpTypes.length)];
      
      newState.playerResources = {
        ...newState.playerResources,
        [player]: {
          ...newState.playerResources[player],
          powerUps: {
            ...newState.playerResources[player].powerUps,
            [randomPowerUp]: newState.playerResources[player].powerUps[randomPowerUp] + 1
          }
        }
      };
      console.log(`${player} collected a ${randomPowerUp} power-up!`);
    }
    
    // Check if player stepped on a treasure
    const isTreasure = state.treasures.some(treasure => treasure.row === position.row && treasure.col === position.col);
    if (isTreasure) {
      // Remove treasure from board
      newState.treasures = newState.treasures.filter(treasure => !(treasure.row === position.row && treasure.col === position.col));
      
      // Increment treasure count for player
      newState.playerResources = {
        ...newState.playerResources,
        [player]: {
          ...newState.playerResources[player],
          treasuresCollected: newState.playerResources[player].treasuresCollected + 1
        }
      };
      console.log(`${player} collected a treasure! Total: ${newState.playerResources[player].treasuresCollected}`);
    }
    
    // Check if player stepped on a key
    const isKey = state.keys.some(key => key.row === position.row && key.col === position.col);
    if (isKey) {
      // Remove key from board
      newState.keys = newState.keys.filter(key => !(key.row === position.row && key.col === position.col));
      
      // Increment key count for player
      newState.playerResources = {
        ...newState.playerResources,
        [player]: {
          ...newState.playerResources[player],
          keysCollected: newState.playerResources[player].keysCollected + 1
        }
      };
      console.log(`${player} collected a key! Total: ${newState.playerResources[player].keysCollected}`);
    }
    
    return newState;
  }, []);

  const isValidMove = useCallback((from: Position, to: Position, state: GameState): boolean => {
    // Check if move is within bounds
    if (to.row < 0 || to.row >= 10 || to.col < 0 || to.col >= 10) {
      return false;
    }
    
    // Check if move is adjacent (only orthogonal moves allowed)
    const rowDiff = Math.abs(to.row - from.row);
    const colDiff = Math.abs(to.col - from.col);
    
    if ((rowDiff === 1 && colDiff === 0) || (rowDiff === 0 && colDiff === 1)) {
      // Check if destination is not occupied by the other player
      const otherPlayer = currentPlayer === 'human' ? 'ai' : 'human';
      const otherPlayerPos = state.players[otherPlayer];
      
      // Check if destination is not a wall
      const isWall = state.walls.some(wall => wall.row === to.row && wall.col === to.col);
      
      return !(to.row === otherPlayerPos.row && to.col === otherPlayerPos.col) && !isWall;
    }
    
    return false;
  }, [currentPlayer]);

  const isValidPlacement = useCallback((position: Position, state: GameState): boolean => {
    // Check if position is within bounds
    if (position.row < 0 || position.row >= 10 || position.col < 0 || position.col >= 10) {
      return false;
    }
    
    // Check if position is empty
    const isOccupied = 
      (state.players.human.row === position.row && state.players.human.col === position.col) ||
      (state.players.ai.row === position.row && state.players.ai.col === position.col) ||
      state.treasures.some(treasure => treasure.row === position.row && treasure.col === position.col) ||
      state.walls.some(wall => wall.row === position.row && wall.col === position.col) ||
      state.ladders.some(ladder => ladder.row === position.row && ladder.col === position.col) ||
      state.highCostTiles.some(tile => tile.row === position.row && tile.col === position.col) ||
      state.trapTiles.some(tile => tile.row === position.row && tile.col === position.col) ||
      state.powerUps.some(powerUp => powerUp.row === position.row && powerUp.col === position.col);
    
    return !isOccupied;
  }, []);

  // Enhanced ladder validation function
  const canPlaceLadder = useCallback((position: Position, state: GameState, player: 'human' | 'ai'): boolean => {
    if (!isValidPlacement(position, state)) {
      return false;
    }
    
    // Check if player has ladders available
    const totalLadders = state.playerResources[player].ladders + state.playerResources[player].powerUps.extraLadders;
    if (totalLadders <= 0) {
      return false;
    }
    
    // Ladders cannot be placed on certain restricted tiles
    const isRestricted = 
      state.gates?.some(gate => gate.row === position.row && gate.col === position.col) ||
      state.guards?.some(guard => guard.position.row === position.row && guard.position.col === position.col);
    
    return !isRestricted;
  }, [isValidPlacement]);

  // Calculate path cost with ladder benefits
  const getLadderBoostedPathCost = useCallback((start: Position, end: Position, state: GameState): number => {
    // Simple pathfinding with ladder cost consideration
    let cost = 0;
    
    // Create a simple path (Manhattan distance approach)
    const rowDiff = Math.abs(end.row - start.row);
    const colDiff = Math.abs(end.col - start.col);
    const totalSteps = rowDiff + colDiff;
    
    // Estimate average cost per step
    const ladderCount = state.ladders.length;
    const highCostCount = state.highCostTiles.length;
    const totalTiles = 100; // 10x10 grid
    
    // Simple heuristic: some steps will be on ladders (free), some on high-cost tiles, rest normal
    const ladderProbability = ladderCount / totalTiles;
    const highCostProbability = highCostCount / totalTiles;
    
    const avgCostPerStep = (ladderProbability * 0) + (highCostProbability * 2) + ((1 - ladderProbability - highCostProbability) * 1);
    
    return totalSteps * avgCostPerStep;
  }, []);

  // Helper function to evaluate if placing a ladder would be beneficial
  const useLadderIfHelpful = useCallback((player: 'human' | 'ai', state: GameState): Position | null => {
    const playerPos = state.players[player];
    const treasures = state.treasures;
    
    if (treasures.length === 0) return null;
    
    // Find closest treasure
    const closestTreasure = treasures.reduce((closest, treasure) => {
      const distToCurrent = Math.abs(playerPos.row - treasure.row) + Math.abs(playerPos.col - treasure.col);
      const distToClosest = Math.abs(playerPos.row - closest.row) + Math.abs(playerPos.col - closest.col);
      return distToCurrent < distToClosest ? treasure : closest;
    });
    
    // Test ladder placements in nearby positions
    const directions = [
      { row: -1, col: 0 }, { row: 1, col: 0 }, { row: 0, col: -1 }, { row: 0, col: 1 },
      { row: -2, col: 0 }, { row: 2, col: 0 }, { row: 0, col: -2 }, { row: 0, col: 2 }
    ];
    
    let bestPosition: Position | null = null;
    let bestValue = 0;
    
    for (const dir of directions) {
      const ladderPos = {
        row: playerPos.row + dir.row,
        col: playerPos.col + dir.col
      };
      
      if (canPlaceLadder(ladderPos, state, player)) {
        // Calculate strategic value: distance to treasure vs distance to opponent
        const distToTreasure = Math.abs(ladderPos.row - closestTreasure.row) + Math.abs(ladderPos.col - closestTreasure.col);
        const opponentPos = state.players[player === 'human' ? 'ai' : 'human'];
        const distToOpponent = Math.abs(ladderPos.row - opponentPos.row) + Math.abs(ladderPos.col - opponentPos.col);
        
        // Prefer positions closer to treasure and farther from opponent
        const strategicValue = (15 - distToTreasure) + (distToOpponent * 0.3);
        
        if (strategicValue > bestValue) {
          bestValue = strategicValue;
          bestPosition = ladderPos;
        }
      }
    }
    
    // Only place ladder if it provides good strategic value
    return bestValue >= 8 ? bestPosition : null;
  }, [canPlaceLadder]);

  const performAction = useCallback((row: number, col: number): boolean => {
    if (gameStatus !== 'playing' || currentPlayer !== 'human') {
      return false;
    }

    // Check if human player is stunned
    if (gameState.playerResources.human.stunned > 0) {
      console.log("You are stunned and cannot move!");
      return false;
    }

    const position: Position = { row, col };
    
    if (currentAction === 'move') {
      const currentPosition = gameState.players[currentPlayer];
      
      if (!isValidMove(currentPosition, position, gameState)) {
        return false;
      }

      let newGameState: GameState = {
        ...gameState,
        players: {
          ...gameState.players,
          [currentPlayer]: position
        }
      };

      // Calculate movement cost and handle power-ups
      const isLadderTile = gameState.ladders.some(ladder => ladder.row === position.row && ladder.col === position.col);
      const isWaterTile = gameState.highCostTiles.some(tile => tile.row === position.row && tile.col === position.col);
      
      let movementCost: number;
      
      if (isLadderTile) {
        // Ladders provide free movement
        movementCost = 0;
        console.log(`${currentPlayer} used a ladder for free movement!`);
      } else if (isWaterTile) {
        movementCost = 2;
        
        // Apply water immunity power-up if on water tile
        if (gameState.playerResources[currentPlayer].powerUps.ignoreWaterCost > 0) {
          movementCost = 1;
          newGameState = consumePowerUp(currentPlayer, 'ignoreWaterCost', newGameState);
          console.log(`${currentPlayer} used Water Immunity power-up!`);
        }
      } else {
        movementCost = 1;
      }
      
      // Check if player has enough energy
      if (gameState.playerResources[currentPlayer].energy < movementCost) {
        console.log(`${currentPlayer} doesn't have enough energy to move!`);
        return false;
      }
      
      // Consume energy
      newGameState.playerResources = {
        ...newGameState.playerResources,
        [currentPlayer]: {
          ...newGameState.playerResources[currentPlayer],
          energy: Math.max(0, newGameState.playerResources[currentPlayer].energy - movementCost)
        }
      };

      // Handle tile effects
      newGameState = handleTileEffects(position, currentPlayer, newGameState);

      // Update game statistics
      newGameState = {
        ...newGameState,
        gameStats: {
          ...newGameState.gameStats,
          stepsHuman: currentPlayer === 'human' ? newGameState.gameStats.stepsHuman + 1 : newGameState.gameStats.stepsHuman,
          stepsAI: currentPlayer === 'ai' ? newGameState.gameStats.stepsAI + 1 : newGameState.gameStats.stepsAI,
          turnCount: newGameState.gameStats.turnCount + 1
        }
      };

      // Regenerate energy at end of turn
      newGameState = {
        ...newGameState,
        playerResources: {
          ...newGameState.playerResources,
          [currentPlayer]: {
            ...newGameState.playerResources[currentPlayer],
            energy: Math.min(
              newGameState.playerResources[currentPlayer].maxEnergy, 
              newGameState.playerResources[currentPlayer].energy + 3
            )
          }
        }
      };

      // Reduce stun duration for both players
      newGameState = {
        ...newGameState,
        playerResources: {
          human: {
            ...newGameState.playerResources.human,
            stunned: Math.max(0, newGameState.playerResources.human.stunned - 1)
          },
          ai: {
            ...newGameState.playerResources.ai,
            stunned: Math.max(0, newGameState.playerResources.ai.stunned - 1)
          }
        }
      };

      setGameState(newGameState);
      setMoveCount(prev => prev + 1);
      
      const newStatus = checkWinCondition(newGameState);
      if (newStatus !== 'playing') {
        setGameStatus(newStatus);
      } else {
        setCurrentPlayer('ai');
        setCurrentAction('move');
      }

      return true;
    } else if (currentAction === 'place-wall') {
      const totalWalls = gameState.playerResources.human.walls + gameState.playerResources.human.powerUps.extraWalls;
      
      if (!isValidPlacement(position, gameState) || totalWalls === 0) {
        return false;
      }

      let newGameState: GameState = {
        ...gameState,
        walls: [...gameState.walls, position]
      };

      // Use regular walls first, then extra walls
      if (gameState.playerResources.human.walls > 0) {
        newGameState.playerResources = {
          ...newGameState.playerResources,
          human: {
            ...newGameState.playerResources.human,
            walls: newGameState.playerResources.human.walls - 1
          }
        };
      } else {
        newGameState.playerResources = {
          ...newGameState.playerResources,
          human: {
            ...newGameState.playerResources.human,
            powerUps: {
              ...newGameState.playerResources.human.powerUps,
              extraWalls: newGameState.playerResources.human.powerUps.extraWalls - 1
            }
          }
        };
      }

      // Update tool usage statistics for wall placement
      newGameState = {
        ...newGameState,
        gameStats: {
          ...newGameState.gameStats,
          toolsUsed: newGameState.gameStats.toolsUsed + 1,
          turnCount: newGameState.gameStats.turnCount + 1
        }
      };

      setGameState(newGameState);
      setCurrentPlayer('ai');
      setCurrentAction('move');
      return true;
    } else if (currentAction === 'place-ladder') {
      const totalLadders = gameState.playerResources.human.ladders + gameState.playerResources.human.powerUps.extraLadders;
      
      if (!isValidPlacement(position, gameState) || totalLadders === 0) {
        return false;
      }

      let newGameState: GameState = {
        ...gameState,
        ladders: [...gameState.ladders, position]
      };

      // Use regular ladders first, then extra ladders
      if (gameState.playerResources.human.ladders > 0) {
        newGameState.playerResources = {
          ...newGameState.playerResources,
          human: {
            ...newGameState.playerResources.human,
            ladders: newGameState.playerResources.human.ladders - 1
          }
        };
      } else {
        newGameState.playerResources = {
          ...newGameState.playerResources,
          human: {
            ...newGameState.playerResources.human,
            powerUps: {
              ...newGameState.playerResources.human.powerUps,
              extraLadders: newGameState.playerResources.human.powerUps.extraLadders - 1
            }
          }
        };
      }

      // Update tool usage statistics for ladder placement
      newGameState = {
        ...newGameState,
        gameStats: {
          ...newGameState.gameStats,
          toolsUsed: newGameState.gameStats.toolsUsed + 1,
          turnCount: newGameState.gameStats.turnCount + 1
        }
      };

      setGameState(newGameState);
      setCurrentPlayer('ai');
      setCurrentAction('move');
      return true;
    }

    return false;
  }, [gameState, currentPlayer, currentAction, gameStatus, isValidMove, isValidPlacement, checkWinCondition, handleTileEffects]);

  // Power-up activation system
  const activatePowerUp = useCallback((powerUpType: string) => {
    if (currentPlayer !== 'human' || gameStatus !== 'playing') return false;
    
    const playerResources = gameState.playerResources.human;
    
    switch (powerUpType) {
      case 'extraMovement':
        if (playerResources.powerUps.extraMovement > 0) {
          const newGameState = {
            ...gameState,
            playerResources: {
              ...gameState.playerResources,
              human: {
                ...playerResources,
                energy: Math.min(playerResources.maxEnergy, playerResources.energy + 5),
                powerUps: {
                  ...playerResources.powerUps,
                  extraMovement: playerResources.powerUps.extraMovement - 1
                }
              }
            }
          };
          setGameState(newGameState);
          console.log("Activated Extra Movement - gained 5 energy points!");
          return true;
        }
        break;
        
      case 'extraWalls':
        if (playerResources.powerUps.extraWalls > 0) {
          const newGameState = {
            ...gameState,
            playerResources: {
              ...gameState.playerResources,
              human: {
                ...playerResources,
                walls: playerResources.walls + 2,
                powerUps: {
                  ...playerResources.powerUps,
                  extraWalls: playerResources.powerUps.extraWalls - 1
                }
              }
            }
          };
          setGameState(newGameState);
          console.log("Activated Bonus Walls - gained 2 wall placements!");
          return true;
        }
        break;
        
      case 'extraLadders':
        if (playerResources.powerUps.extraLadders > 0) {
          const newGameState = {
            ...gameState,
            playerResources: {
              ...gameState.playerResources,
              human: {
                ...playerResources,
                ladders: playerResources.ladders + 2,
                powerUps: {
                  ...playerResources.powerUps,
                  extraLadders: playerResources.powerUps.extraLadders - 1
                }
              }
            }
          };
          setGameState(newGameState);
          console.log("Activated Bonus Ladders - gained 2 ladder placements!");
          return true;
        }
        break;
    }
    
    return false;
  }, [gameState, currentPlayer, gameStatus]);

  // AI move logic (simplified)
  const makeAIMove = useCallback(() => {
    if (gameStatus !== 'playing' || currentPlayer !== 'ai') {
      return;
    }

    // Check if AI is stunned
    if (gameState.playerResources.ai.stunned > 0) {
      console.log("AI is stunned and skips turn");
      setGameState(prevState => ({
        ...prevState,
        playerResources: {
          ...prevState.playerResources,
          ai: {
            ...prevState.playerResources.ai,
            stunned: prevState.playerResources.ai.stunned - 1
          }
        }
      }));
      setCurrentPlayer('human');
      return;
    }

    // AI logic based on difficulty level
    const aiPos = gameState.players.ai;
    const humanPos = gameState.players.human;
    const treasures = gameState.treasures;
    
    if (gameState.difficulty === 'easy') {
      // 🔹 Easy Mode: Basic BFS pathfinding, ignores costs
      const nearestTreasure = treasures.reduce((closest, treasure) => {
        const distToCurrent = manhattanDistance(aiPos, treasure);
        const distToClosest = manhattanDistance(aiPos, closest);
        return distToCurrent < distToClosest ? treasure : closest;
      });

      const directions = [
        { row: -1, col: 0 }, { row: 1, col: 0 },
        { row: 0, col: -1 }, { row: 0, col: 1 }
      ];

      let bestMove: Position | null = null;
      let bestDistance = Infinity;

      for (const dir of directions) {
        const newPos = { row: aiPos.row + dir.row, col: aiPos.col + dir.col };
        if (isValidMove(aiPos, newPos, gameState)) {
          const distance = manhattanDistance(newPos, nearestTreasure);
          if (distance < bestDistance) {
            bestDistance = distance;
            bestMove = newPos;
          }
        }
      }

      if (bestMove) {
        let newGameState: GameState = {
          ...gameState,
          players: { ...gameState.players, ai: bestMove }
        };
        newGameState = handleTileEffects(bestMove, 'ai', newGameState);
        setGameState(newGameState);
        setCurrentPlayer('human');
      }
    } else if (gameState.difficulty === 'normal') {
      // 🔸 Normal Mode: A* pathfinding with terrain costs
      const nearestTreasure = treasures.reduce((closest, treasure) => {
        const distToCurrent = manhattanDistance(aiPos, treasure);
        const distToClosest = manhattanDistance(aiPos, closest);
        return distToCurrent < distToClosest ? treasure : closest;
      });

      const directions = [
        { row: -1, col: 0 }, { row: 1, col: 0 },
        { row: 0, col: -1 }, { row: 0, col: 1 }
      ];

      let bestMove: Position | null = null;
      let bestScore = -Infinity;

      for (const dir of directions) {
        const newPos = { row: aiPos.row + dir.row, col: aiPos.col + dir.col };
        if (isValidMove(aiPos, newPos, gameState)) {
          let score = 0;

          // Distance to treasure (higher score for closer positions)
          const treasureDistance = manhattanDistance(newPos, nearestTreasure);
          score += (15 - treasureDistance) * 2;

          // Terrain cost consideration
          const isLadder = gameState.ladders.some(ladder => 
            ladder.row === newPos.row && ladder.col === newPos.col);
          const isHighCost = gameState.highCostTiles.some(tile => 
            tile.row === newPos.row && tile.col === newPos.col);
          
          if (isLadder) score += 5; // Prefer ladders
          if (isHighCost) score -= 3; // Avoid high-cost terrain

          if (score > bestScore) {
            bestScore = score;
            bestMove = newPos;
          }
        }
      }

      if (bestMove) {
        let newGameState: GameState = {
          ...gameState,
          players: { ...gameState.players, ai: bestMove }
        };
        newGameState = handleTileEffects(bestMove, 'ai', newGameState);
        setGameState(newGameState);
        setCurrentPlayer('human');
      }
    } else {
      // 🔴 Hard Mode: Strategic planning with tool usage
      const nearestTreasure = treasures.reduce((closest, treasure) => {
        const distToCurrent = manhattanDistance(aiPos, treasure);
        const distToClosest = manhattanDistance(aiPos, closest);
        return distToCurrent < distToClosest ? treasure : closest;
      });

      const humanDistance = manhattanDistance(humanPos, nearestTreasure);
      const aiDistance = manhattanDistance(aiPos, nearestTreasure);

      // Advanced Strategic Decision Making System
      const strategicDecision = calculateBestStrategy(gameState, humanPos, aiPos, nearestTreasure);
      
      // Execute Strategic Wall Placement
      if (strategicDecision.action === 'place_wall' && gameState.playerResources.ai.walls > 0) {
        const wallPosition = strategicDecision.position;
        if (wallPosition && isValidPlacement(wallPosition, gameState)) {
          let newGameState: GameState = {
            ...gameState,
            walls: [...gameState.walls, wallPosition],
            playerResources: {
              ...gameState.playerResources,
              ai: {
                ...gameState.playerResources.ai,
                walls: gameState.playerResources.ai.walls - 1
              }
            },
            gameStats: {
              ...gameState.gameStats,
              toolsUsed: gameState.gameStats.toolsUsed + 1
            }
          };
          setGameState(newGameState);
          setCurrentPlayer('human');
          console.log(`AI placed strategic wall at (${wallPosition.row}, ${wallPosition.col}) - ${strategicDecision.reasoning}`);
          return;
        }
      }

      // Execute Strategic Ladder Placement
      if (strategicDecision.action === 'place_ladder' && gameState.playerResources.ai.ladders > 0) {
        const ladderPosition = strategicDecision.position;
        if (ladderPosition && isValidPlacement(ladderPosition, gameState)) {
          let newGameState: GameState = {
            ...gameState,
            ladders: [...gameState.ladders, ladderPosition],
            playerResources: {
              ...gameState.playerResources,
              ai: {
                ...gameState.playerResources.ai,
                ladders: gameState.playerResources.ai.ladders - 1
              }
            },
            gameStats: {
              ...gameState.gameStats,
              toolsUsed: gameState.gameStats.toolsUsed + 1
            }
          };
          setGameState(newGameState);
          setCurrentPlayer('human');
          console.log(`AI placed strategic ladder at (${ladderPosition.row}, ${ladderPosition.col}) - ${strategicDecision.reasoning}`);
          return;
        }
      }

      // Strategic decision: Place ladder for faster movement
      if (gameState.playerResources.ai.ladders > 0 && Math.random() < 0.4) {
        const ladderPositions = [
          { row: aiPos.row - 1, col: aiPos.col },
          { row: aiPos.row + 1, col: aiPos.col },
          { row: aiPos.row, col: aiPos.col - 1 },
          { row: aiPos.row, col: aiPos.col + 1 }
        ];

        for (const ladderPos of ladderPositions) {
          if (isValidPlacement(ladderPos, gameState)) {
            const isHighCost = gameState.highCostTiles.some(tile => 
              tile.row === ladderPos.row && tile.col === ladderPos.col);
            if (isHighCost) {
              let newGameState: GameState = {
                ...gameState,
                ladders: [...gameState.ladders, ladderPos],
                playerResources: {
                  ...gameState.playerResources,
                  ai: {
                    ...gameState.playerResources.ai,
                    ladders: gameState.playerResources.ai.ladders - 1
                  }
                }
              };
              setGameState(newGameState);
              setCurrentPlayer('human');
              return;
            }
          }
        }
      }

      // Enhanced Movement with Advanced Strategic Scoring
      const directions = [
        { row: -1, col: 0 }, { row: 1, col: 0 },
        { row: 0, col: -1 }, { row: 0, col: 1 }
      ];

      let bestMove: Position | null = null;
      let bestScore = -Infinity;

      for (const dir of directions) {
        const newPos = { row: aiPos.row + dir.row, col: aiPos.col + dir.col };
        if (isValidMove(aiPos, newPos, gameState)) {
          let score = 0;

          // Base scoring: distance to treasure
          const treasureDistance = manhattanDistance(newPos, nearestTreasure);
          score += (15 - treasureDistance) * 5;

          // Terrain optimization
          const isLadder = gameState.ladders.some(ladder => 
            ladder.row === newPos.row && ladder.col === newPos.col);
          const isHighCost = gameState.highCostTiles.some(tile => 
            tile.row === newPos.row && tile.col === newPos.col);
          const isPowerUp = gameState.powerUps.some(powerUp => 
            powerUp.row === newPos.row && powerUp.col === newPos.col);
          
          if (isLadder) score += 15; // Prioritize free movement
          if (isHighCost) score -= 10; // Avoid high-cost terrain when possible
          if (isPowerUp) score += 25; // High priority for power-ups

          // Difficulty-based strategic adjustments
          if (aiDifficulty === 'hard') {
            // Advanced strategic thinking
            const humanToTreasureDistance = manhattanDistance(humanPos, nearestTreasure);
            const aiToTreasureFromPos = manhattanDistance(newPos, nearestTreasure);
            
            if (aiToTreasureFromPos < humanToTreasureDistance) {
              score += 20; // Bonus for being closer to treasure than human
            }

            // Strategic positioning
            const humanToAiDistance = manhattanDistance(newPos, humanPos);
            if (humanToAiDistance >= 3 && humanToAiDistance <= 5) {
              score += 10; // Optimal distance to maintain pressure
            }

            // Defensive positioning if human is close to victory
            if (gameState.playerResources.human.treasuresCollected >= 1) {
              const humanToTreasure = manhattanDistance(humanPos, nearestTreasure);
              const aiToHuman = manhattanDistance(newPos, humanPos);
              const aiToTreasure = manhattanDistance(newPos, nearestTreasure);
              
              if (aiToHuman <= 2 && aiToTreasure < humanToTreasure) {
                score += 15; // Blocking value
              }
            }
          } else if (aiDifficulty === 'normal') {
            // Moderate strategic awareness
            const humanToTreasureDistance = manhattanDistance(humanPos, nearestTreasure);
            const aiToTreasureFromPos = manhattanDistance(newPos, nearestTreasure);
            
            if (aiToTreasureFromPos < humanToTreasureDistance) {
              score += 10; // Moderate bonus for positional advantage
            }

            // Maintain reasonable distance from human
            const humanToAiDistance = manhattanDistance(newPos, humanPos);
            if (humanToAiDistance > 2) {
              score += 5; // Slight preference for spacing
            }
          }
          // Easy mode uses only basic distance scoring

          // Avoid traps
          const isTrap = gameState.trapTiles.some(trap => 
            trap.row === newPos.row && trap.col === newPos.col);
          if (isTrap) score -= 30;

          // Energy efficiency
          const energyCost = isLadder ? 0 : (isHighCost ? 2 : 1);
          score -= energyCost * 2;

          if (score > bestScore) {
            bestScore = score;
            bestMove = newPos;
          }
        }
      }

      if (bestMove) {
        let newGameState: GameState = {
          ...gameState,
          players: { ...gameState.players, ai: bestMove }
        };
        newGameState = handleTileEffects(bestMove, 'ai', newGameState);
        setGameState(newGameState);
        setCurrentPlayer('human');
      }
    }
  }, [gameState, currentPlayer, gameStatus, isValidMove, handleTileEffects, checkWinCondition]);

  // AI move effect
  useEffect(() => {
    if (currentPlayer === 'ai' && gameStatus === 'playing') {
      const timer = setTimeout(makeAIMove, 1000);
      return () => clearTimeout(timer);
    }
  }, [currentPlayer, gameStatus, makeAIMove]);

  // Reduce stun duration at start of turn
  useEffect(() => {
    if (currentPlayer === 'human' && gameState.playerResources.human.stunned > 0) {
      setGameState(prevState => ({
        ...prevState,
        playerResources: {
          ...prevState.playerResources,
          human: {
            ...prevState.playerResources.human,
            stunned: Math.max(0, prevState.playerResources.human.stunned - 1)
          }
        }
      }));
    }
  }, [currentPlayer]);

  const resetGame = useCallback(() => {
    const { treasure, humanStart, aiStart } = generateEqualDistancePositions();
    const obstacles = generateObstacles(treasure, humanStart, aiStart);
    
    // Generate multiple treasures for advanced gameplay
    const treasures = [treasure];
    for (let i = 1; i < 3; i++) {
      let newTreasure: Position;
      do {
        newTreasure = {
          row: Math.floor(Math.random() * 10),
          col: Math.floor(Math.random() * 10)
        };
      } while (
        treasures.some(t => t.row === newTreasure.row && t.col === newTreasure.col) ||
        (newTreasure.row === humanStart.row && newTreasure.col === humanStart.col) ||
        (newTreasure.row === aiStart.row && newTreasure.col === aiStart.col)
      );
      treasures.push(newTreasure);
    }
    
    setGameState({
      players: {
        human: humanStart,
        ai: aiStart
      },
      treasures: treasures,
      keys: [],
      gates: [],
      guards: [], 
      fogOfWar: false,
      visibleTiles: {
        human: [],
        ai: []
      },
      gameStats: {
        stepsHuman: 0,
        stepsAI: 0,
        tilesExplored: 0,
        toolsUsed: 0,
        turnCount: 0
      },
      difficulty: 'normal',
      theme: 'default',
      walls: obstacles.walls,
      ladders: obstacles.ladders,
      highCostTiles: obstacles.highCostTiles,
      trapTiles: obstacles.trapTiles,
      powerUps: obstacles.powerUps,
      playerResources: {
        human: { 
          walls: 3, 
          ladders: 2,
          energy: 10,
          maxEnergy: 10,
          keysCollected: 0,
          treasuresCollected: 0,
          powerUps: {
            extraMovement: 0,
            ignoreWaterCost: 0,
            extraWalls: 0,
            extraLadders: 0
          },
          stunned: 0
        },
        ai: { 
          walls: 3, 
          ladders: 2,
          energy: 10,
          maxEnergy: 10,
          keysCollected: 0,
          treasuresCollected: 0,
          powerUps: {
            extraMovement: 0,
            ignoreWaterCost: 0,
            extraWalls: 0,
            extraLadders: 0
          },
          stunned: 0
        }
      }
    });
    
    setCurrentPlayer('human');
    setGameStatus('playing');
    setMoveCount(0);
    setCurrentAction('move');
  }, []);

  const changeDifficulty = useCallback((difficulty: 'easy' | 'normal' | 'hard') => {
    setGameState(prevState => ({
      ...prevState,
      difficulty
    }));
  }, []);

  const changeTheme = useCallback((theme: 'default' | 'jungle' | 'ice' | 'cyber' | 'volcano') => {
    setGameState(prevState => ({
      ...prevState,
      theme
    }));
  }, []);

  return {
    gameState,
    currentPlayer,
    setCurrentPlayer,
    gameStatus,
    currentAction,
    setCurrentAction,
    performAction,
    resetGame,
    moveCount,
    activatePowerUp,
    changeDifficulty,
    changeTheme
  };
};