import { useState, useEffect, useCallback, useRef } from 'react';
import { GameState, GameStatus } from '../types/game';

export type MusicIntensity = 'ambient' | 'tension' | 'action' | 'victory' | 'defeat';
export type SoundEffect = 'move' | 'treasure' | 'wall' | 'ladder' | 'trap' | 'powerup' | 'ai_move';

interface AudioTrack {
  id: string;
  intensity: MusicIntensity;
  loop: boolean;
  volume: number;
}

interface SoundConfig {
  masterVolume: number;
  musicVolume: number;
  sfxVolume: number;
  enabled: boolean;
  manualMode: boolean;
  selectedIntensity: MusicIntensity;
}

export const useAdaptiveSoundtrack = () => {
  const [currentIntensity, setCurrentIntensity] = useState<MusicIntensity>('ambient');
  const [soundConfig, setSoundConfig] = useState<SoundConfig>({
    masterVolume: 0.7,
    musicVolume: 0.6,
    sfxVolume: 0.8,
    enabled: true,
    manualMode: false,
    selectedIntensity: 'ambient'
  });

  const audioContextRef = useRef<AudioContext | null>(null);
  const currentTrackRef = useRef<HTMLAudioElement | null>(null);
  const soundEffectsRef = useRef<Map<SoundEffect, HTMLAudioElement>>(new Map());

  // Initialize audio context and load tracks
  useEffect(() => {
    if (typeof window !== 'undefined' && soundConfig.enabled) {
      try {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        loadSoundEffects();
      } catch (error) {
        console.warn('Audio not supported in this browser');
      }
    }

    return () => {
      if (currentTrackRef.current) {
        currentTrackRef.current.pause();
        currentTrackRef.current = null;
      }
    };
  }, [soundConfig.enabled]);

  const loadSoundEffects = useCallback(() => {
    const soundEffects: Record<SoundEffect, string> = {
      move: createSynthSound('move'),
      treasure: createSynthSound('treasure'),
      wall: createSynthSound('wall'),
      ladder: createSynthSound('ladder'),
      trap: createSynthSound('trap'),
      powerup: createSynthSound('powerup'),
      ai_move: createSynthSound('ai_move')
    };

    Object.entries(soundEffects).forEach(([effect, audioData]) => {
      const audio = new Audio(audioData);
      audio.volume = soundConfig.sfxVolume * soundConfig.masterVolume;
      soundEffectsRef.current.set(effect as SoundEffect, audio);
    });
  }, [soundConfig.sfxVolume, soundConfig.masterVolume]);

  // Create synthetic sounds using Web Audio API
  const createSynthSound = useCallback((type: SoundEffect): string => {
    if (!audioContextRef.current) return '';

    const ctx = audioContextRef.current;
    const sampleRate = ctx.sampleRate;
    const duration = type === 'treasure' ? 0.8 : 0.3;
    const frameCount = sampleRate * duration;
    const arrayBuffer = ctx.createBuffer(1, frameCount, sampleRate);
    const channelData = arrayBuffer.getChannelData(0);

    // Generate different sound patterns for each effect
    for (let i = 0; i < frameCount; i++) {
      const t = i / sampleRate;
      let sample = 0;

      switch (type) {
        case 'move':
          sample = Math.sin(2 * Math.PI * 200 * t) * Math.exp(-t * 3) * 0.3;
          break;
        case 'treasure':
          sample = (Math.sin(2 * Math.PI * 440 * t) + Math.sin(2 * Math.PI * 554 * t) + Math.sin(2 * Math.PI * 659 * t)) * Math.exp(-t * 2) * 0.2;
          break;
        case 'wall':
          sample = (Math.random() * 2 - 1) * Math.exp(-t * 5) * 0.2;
          break;
        case 'ladder':
          sample = Math.sin(2 * Math.PI * 300 * t) * (1 - t / duration) * 0.3;
          break;
        case 'trap':
          sample = Math.sin(2 * Math.PI * 100 * t) * Math.sin(2 * Math.PI * 10 * t) * 0.4;
          break;
        case 'powerup':
          sample = Math.sin(2 * Math.PI * (400 + t * 400) * t) * Math.exp(-t * 2) * 0.3;
          break;
        case 'ai_move':
          sample = Math.sin(2 * Math.PI * 150 * t) * Math.exp(-t * 4) * 0.2;
          break;
        default:
          sample = Math.sin(2 * Math.PI * 440 * t) * Math.exp(-t * 3) * 0.3;
      }

      channelData[i] = sample;
    }

    // Convert to WAV data URL
    return audioBufferToWav(arrayBuffer);
  }, []);

  // Convert AudioBuffer to WAV data URL
  const audioBufferToWav = useCallback((buffer: AudioBuffer): string => {
    const length = buffer.length;
    const arrayBuffer = new ArrayBuffer(44 + length * 2);
    const view = new DataView(arrayBuffer);
    const channelData = buffer.getChannelData(0);

    // WAV header
    const writeString = (offset: number, string: string) => {
      for (let i = 0; i < string.length; i++) {
        view.setUint8(offset + i, string.charCodeAt(i));
      }
    };

    writeString(0, 'RIFF');
    view.setUint32(4, 36 + length * 2, true);
    writeString(8, 'WAVE');
    writeString(12, 'fmt ');
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true);
    view.setUint16(22, 1, true);
    view.setUint32(24, buffer.sampleRate, true);
    view.setUint32(28, buffer.sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeString(36, 'data');
    view.setUint32(40, length * 2, true);

    // Convert float samples to 16-bit PCM
    let offset = 44;
    for (let i = 0; i < length; i++) {
      const sample = Math.max(-1, Math.min(1, channelData[i]));
      view.setInt16(offset, sample * 0x7FFF, true);
      offset += 2;
    }

    const blob = new Blob([arrayBuffer], { type: 'audio/wav' });
    return URL.createObjectURL(blob);
  }, []);

  // Generate procedural background music
  const generateBackgroundMusic = useCallback((intensity: MusicIntensity): string => {
    if (!audioContextRef.current) return '';

    const ctx = audioContextRef.current;
    const sampleRate = ctx.sampleRate;
    const duration = 30; // 30 second loop
    const frameCount = sampleRate * duration;
    const arrayBuffer = ctx.createBuffer(2, frameCount, sampleRate); // Stereo

    const leftChannel = arrayBuffer.getChannelData(0);
    const rightChannel = arrayBuffer.getChannelData(1);

    // Define musical characteristics for each intensity
    const intensityConfig = {
      ambient: { tempo: 0.5, baseFreq: 110, complexity: 0.3, volume: 0.3 },
      tension: { tempo: 0.8, baseFreq: 130, complexity: 0.5, volume: 0.4 },
      action: { tempo: 1.2, baseFreq: 150, complexity: 0.8, volume: 0.6 },
      victory: { tempo: 1.0, baseFreq: 220, complexity: 0.7, volume: 0.5 },
      defeat: { tempo: 0.6, baseFreq: 90, complexity: 0.4, volume: 0.4 }
    };

    const config = intensityConfig[intensity];

    for (let i = 0; i < frameCount; i++) {
      const t = i / sampleRate;
      let leftSample = 0;
      let rightSample = 0;

      // Base rhythm
      const beat = Math.sin(2 * Math.PI * config.tempo * t) * 0.1;
      
      // Harmonic layers
      for (let harmonic = 1; harmonic <= 4; harmonic++) {
        const freq = config.baseFreq * harmonic;
        const amplitude = (1 / harmonic) * config.complexity;
        const phase = harmonic * Math.PI / 4;
        
        leftSample += Math.sin(2 * Math.PI * freq * t + phase) * amplitude;
        rightSample += Math.sin(2 * Math.PI * freq * t + phase + 0.1) * amplitude;
      }

      // Add intensity-specific elements
      if (intensity === 'action') {
        // Fast arpeggios
        const arpeggio = Math.sin(2 * Math.PI * config.baseFreq * 2 * t) * 
                        Math.sin(2 * Math.PI * 4 * t) * 0.2;
        leftSample += arpeggio;
        rightSample += arpeggio;
      } else if (intensity === 'tension') {
        // Dissonant intervals
        const dissonance = Math.sin(2 * Math.PI * config.baseFreq * 1.414 * t) * 0.15;
        leftSample += dissonance;
        rightSample -= dissonance; // Opposite phase for tension
      } else if (intensity === 'victory') {
        // Bright major chords
        const major = Math.sin(2 * Math.PI * config.baseFreq * 1.25 * t) * 0.2 +
                     Math.sin(2 * Math.PI * config.baseFreq * 1.5 * t) * 0.15;
        leftSample += major;
        rightSample += major;
      }

      // Apply envelope and normalization
      const envelope = Math.sin(Math.PI * t / duration); // Fade in/out
      leftSample = (leftSample + beat) * config.volume * envelope;
      rightSample = (rightSample + beat) * config.volume * envelope;

      // Prevent clipping
      leftChannel[i] = Math.max(-1, Math.min(1, leftSample));
      rightChannel[i] = Math.max(-1, Math.min(1, rightSample));
    }

    return audioBufferToWav(arrayBuffer);
  }, [audioBufferToWav]);

  // Calculate game intensity based on game state
  const calculateIntensity = useCallback((gameState: GameState, gameStatus: GameStatus): MusicIntensity => {
    if (gameStatus === 'human-won') return 'victory';
    if (gameStatus === 'ai-won') return 'defeat';
    if (gameStatus === 'draw') return 'ambient';

    const humanPos = gameState.players.human;
    const aiPos = gameState.players.ai;
    const treasures = gameState.treasures;

    // Calculate distances to treasures
    const humanMinDist = Math.min(...treasures.map(t => 
      Math.abs(humanPos.row - t.row) + Math.abs(humanPos.col - t.col)
    ));
    const aiMinDist = Math.min(...treasures.map(t => 
      Math.abs(aiPos.row - t.row) + Math.abs(aiPos.col - t.col)
    ));

    // Check if either player is close to winning
    const humanTreasures = gameState.playerResources.human.treasuresCollected;
    const aiTreasures = gameState.playerResources.ai.treasuresCollected;

    if (humanTreasures >= 1 || aiTreasures >= 1) {
      return 'action'; // High intensity when close to winning
    }

    // Check proximity to treasures
    if (humanMinDist <= 2 || aiMinDist <= 2) {
      return 'tension'; // Medium intensity when close to treasure
    }

    // Check if players are close to each other (competition)
    const playerDistance = Math.abs(humanPos.row - aiPos.row) + Math.abs(humanPos.col - aiPos.col);
    if (playerDistance <= 3) {
      return 'tension';
    }

    // Check recent events
    if (gameState.lastEvent) {
      switch (gameState.lastEvent.type) {
        case 'lightning':
        case 'earthquake':
          return 'action';
        case 'flood':
          return 'tension';
        default:
          return 'ambient';
      }
    }

    return 'ambient';
  }, []);

  // Update music based on game state
  const updateSoundtrack = useCallback((gameState: GameState, gameStatus: GameStatus) => {
    if (!soundConfig.enabled) return;

    // Use manual intensity if manual mode is enabled, otherwise calculate automatically
    const newIntensity = soundConfig.manualMode ? soundConfig.selectedIntensity : calculateIntensity(gameState, gameStatus);
    
    if (newIntensity !== currentIntensity) {
      setCurrentIntensity(newIntensity);
      
      // Fade out current track
      if (currentTrackRef.current) {
        const fadeOut = setInterval(() => {
          if (currentTrackRef.current && currentTrackRef.current.volume > 0.1) {
            currentTrackRef.current.volume = Math.max(0, currentTrackRef.current.volume - 0.1);
          } else {
            clearInterval(fadeOut);
            if (currentTrackRef.current) {
              currentTrackRef.current.pause();
            }
            
            // Start new track
            const newTrackData = generateBackgroundMusic(newIntensity);
            if (newTrackData) {
              const newTrack = new Audio(newTrackData);
              newTrack.loop = true;
              newTrack.volume = 0;
              newTrack.play().then(() => {
                // Fade in new track
                const fadeIn = setInterval(() => {
                  if (newTrack.volume < soundConfig.musicVolume * soundConfig.masterVolume) {
                    newTrack.volume = Math.min(
                      soundConfig.musicVolume * soundConfig.masterVolume,
                      newTrack.volume + 0.05
                    );
                  } else {
                    clearInterval(fadeIn);
                  }
                }, 100);
                currentTrackRef.current = newTrack;
              }).catch(() => {
                console.warn('Could not play background music');
              });
            }
          }
        }, 100);
      } else {
        // No current track, start immediately
        const newTrackData = generateBackgroundMusic(newIntensity);
        if (newTrackData) {
          const newTrack = new Audio(newTrackData);
          newTrack.loop = true;
          newTrack.volume = soundConfig.musicVolume * soundConfig.masterVolume;
          newTrack.play().then(() => {
            currentTrackRef.current = newTrack;
          }).catch(() => {
            console.warn('Could not play background music');
          });
        }
      }
    }
  }, [currentIntensity, soundConfig, calculateIntensity, generateBackgroundMusic]);

  // Play sound effect
  const playSoundEffect = useCallback((effect: SoundEffect) => {
    if (!soundConfig.enabled) return;

    const audio = soundEffectsRef.current.get(effect);
    if (audio) {
      audio.currentTime = 0;
      audio.volume = soundConfig.sfxVolume * soundConfig.masterVolume;
      audio.play().catch(() => {
        console.warn(`Could not play sound effect: ${effect}`);
      });
    }
  }, [soundConfig]);

  // Update sound configuration
  const updateSoundConfig = useCallback((newConfig: Partial<SoundConfig>) => {
    setSoundConfig(prev => ({ ...prev, ...newConfig }));
  }, []);

  // Initialize audio context on user interaction
  const initializeAudio = useCallback(() => {
    if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume();
    }
  }, []);

  // Manually change music type
  const changeMusicType = useCallback((intensity: MusicIntensity) => {
    updateSoundConfig({ 
      manualMode: true, 
      selectedIntensity: intensity 
    });
    
    // Force immediate music change
    setCurrentIntensity(intensity);
    
    // Generate and play new track immediately
    const newTrackData = generateBackgroundMusic(intensity);
    if (newTrackData && soundConfig.enabled) {
      // Stop current track
      if (currentTrackRef.current) {
        currentTrackRef.current.pause();
      }
      
      // Start new track
      const newTrack = new Audio(newTrackData);
      newTrack.loop = true;
      newTrack.volume = soundConfig.musicVolume * soundConfig.masterVolume;
      newTrack.play().then(() => {
        currentTrackRef.current = newTrack;
      }).catch(() => {
        console.warn('Could not play background music');
      });
    }
  }, [updateSoundConfig, generateBackgroundMusic, soundConfig.enabled, soundConfig.musicVolume, soundConfig.masterVolume]);

  return {
    currentIntensity,
    soundConfig,
    updateSoundtrack,
    playSoundEffect,
    updateSoundConfig,
    initializeAudio,
    changeMusicType
  };
};