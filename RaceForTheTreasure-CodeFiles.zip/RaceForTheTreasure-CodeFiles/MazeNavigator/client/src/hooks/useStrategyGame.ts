import { useState, useCallback, useEffect } from 'react';
import { GameState, GameAction, ActionType, Position, GameMode, TerrainType, AIResult } from '../lib/game/types';
import { initializeGame, checkWinCondition, canPlaceWall, canPlaceLadder, getNeighbors, isValidPosition, getTerrainCost, getManhattanDistance } from '../lib/game/utils';
import { AIAgent } from '../lib/game/ai';

export const useStrategyGame = () => {
  const [gameState, setGameState] = useState<GameState>(() => initializeGame(10));
  const [gameMode, setGameMode] = useState<GameMode>(GameMode.MOVE);
  const [selectedWallPositions, setSelectedWallPositions] = useState<Position[]>([]);
  const [wallDirection, setWallDirection] = useState<'horizontal' | 'vertical'>('horizontal');
  const [aiAgent] = useState(() => new AIAgent());
  const [lastAIResult, setLastAIResult] = useState<AIResult | null>(null);

  const resetGame = useCallback(() => {
    console.log('Resetting game...');
    const newGame = initializeGame(10);
    setGameState(newGame);
    setGameMode(GameMode.MOVE);
    setSelectedWallPositions([]);
    setLastAIResult(null);
    
    console.log('Game reset complete - players visible on grid');
  }, []);

  const executeAction = useCallback((action: GameAction) => {
    setGameState(prevState => {
      const newState = { ...prevState };
      const player = newState.players[action.playerId];

      switch (action.type) {
        case ActionType.MOVE:
          if (action.position && isValidMove(action.position, player.position, newState.grid)) {
            const targetCell = newState.grid[action.position.y][action.position.x];
            const terrainCost = getTerrainCost(targetCell.terrain);
            
            // Calculate move cost based on terrain and power-ups
            let moveCost = 1;
            if (terrainCost === 2 && player.powerUps.ignoreWaterCost > 0) {
              moveCost = 1; // Power-up ignores water cost
              player.powerUps.ignoreWaterCost--;
              console.log(`${action.playerId} used water immunity power-up!`);
            } else if (terrainCost === 2) {
              moveCost = 2; // Water/Mud costs 2 moves
            } else if (terrainCost === 3) {
              moveCost = 2; // Sand costs 2 moves (capped)
            } else if (terrainCost === 0.5) {
              moveCost = 0; // Ladder costs no moves (bonus)
            }
            
            // Check if player has enough moves remaining
            if (player.movesThisTurn + moveCost <= player.maxMovesPerTurn) {
              // Clear old position
              const oldPos = player.position;
              newState.grid[oldPos.y][oldPos.x].playerId = undefined;
              
              // Update player position
              player.position = action.position;
              player.movesThisTurn += moveCost;
              
              // Handle special terrain effects
              if (targetCell.terrain === TerrainType.TRAP) {
                player.stunned = 1; // Stun for 1 turn
                console.log(`${action.playerId} stepped on a trap and is stunned for 1 turn!`);
              } else if (targetCell.terrain === TerrainType.POWER_UP) {
                // Grant random power-up
                const powerUpTypes = ['extraMovement', 'ignoreWaterCost', 'extraWalls', 'extraLadders'];
                const randomPowerUp = powerUpTypes[Math.floor(Math.random() * powerUpTypes.length)];
                
                switch (randomPowerUp) {
                  case 'extraMovement':
                    player.powerUps.extraMovement += 2;
                    console.log(`${action.playerId} gained 2 extra movement power-ups!`);
                    break;
                  case 'ignoreWaterCost':
                    player.powerUps.ignoreWaterCost += 3;
                    console.log(`${action.playerId} gained 3 water immunity power-ups!`);
                    break;
                  case 'extraWalls':
                    player.powerUps.extraWalls += 1;
                    console.log(`${action.playerId} gained 1 extra wall!`);
                    break;
                  case 'extraLadders':
                    player.powerUps.extraLadders += 1;
                    console.log(`${action.playerId} gained 1 extra ladder!`);
                    break;
                }
                
                // Remove power-up from grid
                newState.grid[action.position.y][action.position.x].terrain = TerrainType.EMPTY;
                newState.grid[action.position.y][action.position.x].cost = 1;
              }
              
              // Set new position
              newState.grid[action.position.y][action.position.x].playerId = action.playerId;
              
              console.log(`Player ${action.playerId} moved from (${oldPos.x}, ${oldPos.y}) to (${action.position.x}, ${action.position.y}), cost: ${moveCost}, total moves: ${player.movesThisTurn}/${player.maxMovesPerTurn}`);
              
              // Check for ladder bonus
              if (targetCell.terrain === TerrainType.LADDER) {
                console.log(`${action.playerId} used ladder - gained free movement!`);
              }
            } else {
              console.log(`Cannot move: would exceed move limit. Cost: ${moveCost}, remaining: ${player.maxMovesPerTurn - player.movesThisTurn}`);
            }
          } else {
            console.log(`Invalid move attempted by ${action.playerId} to position:`, action.position);
          }
          break;

        case ActionType.PLACE_WALL:
          if (action.wallPositions && !player.wallUsed) {
            if (canPlaceWall(newState.grid, action.wallPositions, newState.players, newState.treasure)) {
              action.wallPositions.forEach(pos => {
                newState.grid[pos.y][pos.x].terrain = TerrainType.PLAYER_WALL;
                newState.grid[pos.y][pos.x].cost = Infinity;
              });
              player.wallUsed = true;
              player.movesThisTurn++;
            }
          }
          break;

        case ActionType.PLACE_LADDER:
          if (action.position && !player.ladderUsed) {
            if (canPlaceLadder(newState.grid, action.position, newState.players, newState.treasure)) {
              newState.grid[action.position.y][action.position.x].terrain = TerrainType.LADDER;
              newState.grid[action.position.y][action.position.x].cost = 0.5;
              player.ladderUsed = true;
              player.movesThisTurn++;
            }
          }
          break;

        case ActionType.END_TURN:
          // Reset moves and switch players
          player.movesThisTurn = 0;
          const nextPlayer = newState.currentPlayer === 'human' ? 'ai' : 'human';
          newState.currentPlayer = nextPlayer;
          
          // Reset next player's moves
          newState.players[nextPlayer].movesThisTurn = 0;
          
          if (nextPlayer === 'human') {
            newState.turnNumber++;
          }
          
          // Ensure AI thinking is reset
          if (nextPlayer === 'ai') {
            newState.aiThinking = false;
          }
          break;
      }

      // Add action to history
      newState.gameHistory.push(action);

      // Check win condition
      const winner = checkWinCondition(newState);
      if (winner) {
        newState.gameStatus = 'ended';
        newState.winner = winner;
      }

      return newState;
    });
  }, []);

  const isValidMove = (newPos: Position, currentPos: Position, grid: any[][]): boolean => {
    // Check bounds
    if (!isValidPosition(newPos, grid.length)) {
      console.log(`Move out of bounds: (${newPos.x}, ${newPos.y})`);
      return false;
    }
    
    // Check if adjacent (Manhattan distance = 1)
    const distance = Math.abs(newPos.x - currentPos.x) + Math.abs(newPos.y - currentPos.y);
    if (distance !== 1) {
      console.log(`Move not adjacent: distance ${distance} from (${currentPos.x}, ${currentPos.y}) to (${newPos.x}, ${newPos.y})`);
      return false;
    }
    
    // Check terrain - walls are impassable
    const targetCell = grid[newPos.y][newPos.x];
    if (targetCell.terrain === TerrainType.WALL || targetCell.terrain === TerrainType.PLAYER_WALL) {
      console.log(`Move blocked by wall at (${newPos.x}, ${newPos.y})`);
      return false;
    }
    
    // Cannot move to cell occupied by other player
    if (targetCell.playerId) {
      console.log(`Move blocked by player at (${newPos.x}, ${newPos.y})`);
      return false;
    }
    
    console.log(`Valid move from (${currentPos.x}, ${currentPos.y}) to (${newPos.x}, ${newPos.y})`);
    return true;
  };

  const handleCellClick = useCallback((x: number, y: number) => {
    if (gameState.gameStatus !== 'playing' || gameState.currentPlayer !== 'human') return;

    const position = { x, y };

    // Only handle obstacle placement through grid clicks
    switch (gameMode) {
      case GameMode.WALL_PLACEMENT:
        handleWallPlacement(position);
        break;

      case GameMode.LADDER_PLACEMENT:
        const ladderAction: GameAction = {
          type: ActionType.PLACE_LADDER,
          playerId: 'human',
          position
        };
        executeAction(ladderAction);
        setGameMode(GameMode.MOVE);
        break;
    }
  }, [gameState, gameMode, executeAction]);

  const handleMove = useCallback((direction: 'up' | 'down' | 'left' | 'right') => {
    if (gameState.gameStatus !== 'playing' || gameState.currentPlayer !== 'human') return;

    const currentPos = gameState.players.human.position;
    let newPos: Position;

    switch (direction) {
      case 'up':
        newPos = { x: currentPos.x, y: currentPos.y - 1 };
        break;
      case 'down':
        newPos = { x: currentPos.x, y: currentPos.y + 1 };
        break;
      case 'left':
        newPos = { x: currentPos.x - 1, y: currentPos.y };
        break;
      case 'right':
        newPos = { x: currentPos.x + 1, y: currentPos.y };
        break;
    }

    const action: GameAction = {
      type: ActionType.MOVE,
      playerId: 'human',
      position: newPos
    };
    executeAction(action);
  }, [gameState, executeAction]);

  const handleWallPlacement = useCallback((position: Position) => {
    if (selectedWallPositions.length === 0) {
      setSelectedWallPositions([position]);
    } else if (selectedWallPositions.length === 1) {
      const firstPos = selectedWallPositions[0];
      const positions = [firstPos, position];
      
      // Validate wall placement
      const isHorizontal = firstPos.y === position.y && Math.abs(firstPos.x - position.x) === 1;
      const isVertical = firstPos.x === position.x && Math.abs(firstPos.y - position.y) === 1;
      
      if (isHorizontal || isVertical) {
        const action: GameAction = {
          type: ActionType.PLACE_WALL,
          playerId: 'human',
          wallPositions: positions,
          direction: isHorizontal ? 'horizontal' : 'vertical'
        };
        executeAction(action);
        setSelectedWallPositions([]);
        setGameMode(GameMode.MOVE);
      } else {
        // Invalid placement, restart
        setSelectedWallPositions([position]);
      }
    }
  }, [selectedWallPositions, executeAction]);

  const endTurn = useCallback(() => {
    const action: GameAction = {
      type: ActionType.END_TURN,
      playerId: gameState.currentPlayer
    };
    executeAction(action);
  }, [gameState.currentPlayer, executeAction]);

  // AI turn handling
  useEffect(() => {
    if (gameState.currentPlayer === 'ai' && gameState.gameStatus === 'playing' && !gameState.aiThinking) {
      console.log('Starting AI turn');
      setGameState(prev => ({ ...prev, aiThinking: true }));
      
      const makeAIMove = async () => {
        try {
          // Wait a bit to show AI thinking
          await new Promise(resolve => setTimeout(resolve, 800));
          
          const result = await aiAgent.makeDecision(gameState);
          setLastAIResult(result);
          
          console.log('AI decision:', result.action);
          
          // Execute AI action
          executeAction(result.action);
          
          // Always end AI turn after one action to prevent infinite loops
          setTimeout(() => {
            console.log('Ending AI turn');
            executeAction({ type: ActionType.END_TURN, playerId: 'ai' });
            setGameState(prev => ({ ...prev, aiThinking: false }));
          }, 1000);
          
        } catch (error) {
          console.error('AI decision making failed:', error);
          setGameState(prev => ({ ...prev, aiThinking: false }));
          // Force end AI turn on error
          executeAction({ type: ActionType.END_TURN, playerId: 'ai' });
        }
      };

      makeAIMove();
    }
  }, [gameState.currentPlayer, gameState.gameStatus, gameState.aiThinking, gameState.turnNumber]);

  return {
    gameState,
    gameMode,
    setGameMode,
    selectedWallPositions,
    wallDirection,
    setWallDirection,
    lastAIResult,
    handleCellClick,
    handleMove,
    endTurn,
    resetGame,
    canUseWall: !gameState.players[gameState.currentPlayer]?.wallUsed,
    canUseLadder: !gameState.players[gameState.currentPlayer]?.ladderUsed,
    movesRemaining: gameState.players[gameState.currentPlayer]?.maxMovesPerTurn - 
                    gameState.players[gameState.currentPlayer]?.movesThisTurn || 0
  };
};