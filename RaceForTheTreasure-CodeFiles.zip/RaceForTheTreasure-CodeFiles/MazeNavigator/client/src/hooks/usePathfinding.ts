import { useState, useCallback, useRef } from 'react';
import { 
  GridState, 
  VisualizationState, 
  AlgorithmType, 
  Position, 
  EditMode,
  AlgorithmResult,
  AlgorithmStep
} from '../lib/pathfinding/types';
import { createEmptyGrid, resetGridVisualization } from '../lib/pathfinding/utils';
import { PathfindingAlgorithms } from '../lib/pathfinding/algorithms';

export const usePathfinding = (initialSize: number = 10) => {
  const [gridState, setGridState] = useState<GridState>(() => ({
    grid: createEmptyGrid(initialSize),
    size: initialSize,
    start: null,
    goal: null
  }));

  const [visualizationState, setVisualizationState] = useState<VisualizationState>({
    isRunning: false,
    currentAlgorithm: null,
    currentStep: 0,
    steps: [],
    results: new Map(),
    speed: 100 // milliseconds between steps
  });

  const [editMode, setEditMode] = useState<EditMode>(EditMode.WALL);
  const animationRef = useRef<number>();

  const setCell = useCallback((x: number, y: number, mode: EditMode) => {
    setGridState(prev => {
      const newGrid = prev.grid.map(row => [...row]);
      const cell = newGrid[y][x];

      // Reset cell properties
      cell.isWall = false;
      cell.isStart = false;
      cell.isGoal = false;
      cell.cost = 1;

      let newStart = prev.start;
      let newGoal = prev.goal;

      switch (mode) {
        case EditMode.WALL:
          cell.isWall = true;
          cell.type = 'wall' as any;
          break;
        case EditMode.START:
          // Remove previous start
          if (prev.start) {
            const oldStart = newGrid[prev.start.y][prev.start.x];
            oldStart.isStart = false;
            oldStart.type = 'empty' as any;
          }
          cell.isStart = true;
          cell.type = 'start' as any;
          newStart = { x, y };
          break;
        case EditMode.GOAL:
          // Remove previous goal
          if (prev.goal) {
            const oldGoal = newGrid[prev.goal.y][prev.goal.x];
            oldGoal.isGoal = false;
            oldGoal.type = 'goal' as any;
          }
          cell.isGoal = true;
          cell.type = 'goal' as any;
          newGoal = { x, y };
          break;
        case EditMode.MUD:
          cell.type = 'mud' as any;
          cell.cost = 3;
          break;
        case EditMode.SAND:
          cell.type = 'sand' as any;
          cell.cost = 2;
          break;
        case EditMode.WATER:
          cell.type = 'water' as any;
          cell.cost = 5;
          break;
        case EditMode.ERASE:
          cell.type = 'empty' as any;
          cell.cost = 1;
          break;
      }

      return {
        ...prev,
        grid: newGrid,
        start: newStart,
        goal: newGoal
      };
    });
  }, []);

  const clearGrid = useCallback(() => {
    setGridState(prev => ({
      ...prev,
      grid: createEmptyGrid(prev.size),
      start: null,
      goal: null
    }));
    setVisualizationState(prev => ({
      ...prev,
      results: new Map(),
      steps: [],
      currentStep: 0
    }));
  }, []);

  const clearVisualization = useCallback(() => {
    setGridState(prev => ({
      ...prev,
      grid: resetGridVisualization(prev.grid)
    }));
    setVisualizationState(prev => ({
      ...prev,
      results: new Map(),
      steps: [],
      currentStep: 0,
      isRunning: false
    }));
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
    }
  }, []);

  const runAlgorithm = useCallback(async (algorithm: AlgorithmType) => {
    if (!gridState.start || !gridState.goal) {
      alert('Please set both start and goal positions');
      return;
    }

    clearVisualization();
    
    setVisualizationState(prev => ({
      ...prev,
      isRunning: true,
      currentAlgorithm: algorithm
    }));

    const steps: AlgorithmStep[] = [];
    const onStep = (step: AlgorithmStep) => {
      steps.push(step);
    };

    let result: AlgorithmResult;
    
    try {
      switch (algorithm) {
        case AlgorithmType.BFS:
          result = await PathfindingAlgorithms.bfs(gridState.grid, gridState.start, gridState.goal, onStep);
          break;
        case AlgorithmType.DFS:
          result = await PathfindingAlgorithms.dfs(gridState.grid, gridState.start, gridState.goal, onStep);
          break;
        case AlgorithmType.UCS:
          result = await PathfindingAlgorithms.ucs(gridState.grid, gridState.start, gridState.goal, onStep);
          break;
        case AlgorithmType.ASTAR:
          result = await PathfindingAlgorithms.aStar(gridState.grid, gridState.start, gridState.goal, onStep);
          break;
        default:
          throw new Error('Unknown algorithm');
      }

      setVisualizationState(prev => {
        const newResults = new Map(prev.results);
        newResults.set(algorithm, result);
        return {
          ...prev,
          steps,
          results: newResults,
          isRunning: false
        };
      });

      // Start animation
      animateSteps(steps);
    } catch (error) {
      console.error('Algorithm execution failed:', error);
      setVisualizationState(prev => ({
        ...prev,
        isRunning: false
      }));
    }
  }, [gridState.grid, gridState.start, gridState.goal]);

  const animateSteps = useCallback((steps: AlgorithmStep[]) => {
    let stepIndex = 0;
    
    const animate = () => {
      if (stepIndex >= steps.length) {
        setVisualizationState(prev => ({ ...prev, isRunning: false }));
        return;
      }

      const step = steps[stepIndex];
      
      setGridState(prev => {
        const newGrid = resetGridVisualization(prev.grid);
        
        // Mark explored nodes
        step.explored.forEach(pos => {
          if (pos.x >= 0 && pos.x < newGrid[0].length && pos.y >= 0 && pos.y < newGrid.length) {
            newGrid[pos.y][pos.x].isExplored = true;
          }
        });
        
        // Mark queue nodes
        step.queue.forEach(pos => {
          if (pos.x >= 0 && pos.x < newGrid[0].length && pos.y >= 0 && pos.y < newGrid.length) {
            newGrid[pos.y][pos.x].isInQueue = true;
          }
        });
        
        // Mark path
        step.path.forEach(pos => {
          if (pos.x >= 0 && pos.x < newGrid[0].length && pos.y >= 0 && pos.y < newGrid.length) {
            newGrid[pos.y][pos.x].isPath = true;
          }
        });

        return { ...prev, grid: newGrid };
      });

      setVisualizationState(prev => ({ ...prev, currentStep: stepIndex }));
      stepIndex++;
      
      animationRef.current = requestAnimationFrame(() => {
        setTimeout(animate, visualizationState.speed);
      });
    };

    animate();
  }, [visualizationState.speed]);

  const runAllAlgorithms = useCallback(async () => {
    if (!gridState.start || !gridState.goal) {
      alert('Please set both start and goal positions');
      return;
    }

    clearVisualization();
    
    const algorithms = [AlgorithmType.BFS, AlgorithmType.DFS, AlgorithmType.UCS, AlgorithmType.ASTAR];
    const results = new Map<AlgorithmType, AlgorithmResult>();

    for (const algorithm of algorithms) {
      let result: AlgorithmResult;
      
      switch (algorithm) {
        case AlgorithmType.BFS:
          result = await PathfindingAlgorithms.bfs(gridState.grid, gridState.start, gridState.goal);
          break;
        case AlgorithmType.DFS:
          result = await PathfindingAlgorithms.dfs(gridState.grid, gridState.start, gridState.goal);
          break;
        case AlgorithmType.UCS:
          result = await PathfindingAlgorithms.ucs(gridState.grid, gridState.start, gridState.goal);
          break;
        case AlgorithmType.ASTAR:
          result = await PathfindingAlgorithms.aStar(gridState.grid, gridState.start, gridState.goal);
          break;
        default:
          continue;
      }
      
      results.set(algorithm, result);
    }

    setVisualizationState(prev => ({
      ...prev,
      results
    }));
  }, [gridState.grid, gridState.start, gridState.goal]);

  return {
    gridState,
    visualizationState,
    editMode,
    setEditMode,
    setCell,
    clearGrid,
    clearVisualization,
    runAlgorithm,
    runAllAlgorithms,
    setVisualizationSpeed: (speed: number) => 
      setVisualizationState(prev => ({ ...prev, speed }))
  };
};
