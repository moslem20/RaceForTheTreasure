# Algorithms and Metrics Documentation
## Treasure Quest Arena - Technical Implementation

### 🔍 Pathfinding Algorithms

#### 1. A* (A-Star) Algorithm
**Location**: `client/src/components/game/AdvancedAI.ts`
**Purpose**: Optimal pathfinding for AI agents

**Implementation Details**:
- **Cost Function**: `g(n) + h(n)` where g is actual cost, h is heuristic
- **Heuristic**: Manhattan distance `|x1-x2| + |y1-y2|`
- **Grid Size**: 10x10 game board
- **Terrain Costs**: 
  - Empty tiles: 1 point
  - Water/mud tiles: 2 points
  - Walls: Infinity (impassable)
- **Features**:
  - Open/closed set tracking with Map data structures
  - Path reconstruction with parent tracking
  - Energy cost calculation
  - Risk level assessment

```typescript
private calculateAStarPath(start: Position, goal: Position, gameState: GameState): PathAnalysis | null
```

#### 2. Breadth-First Search (BFS)
**Location**: `client/src/lib/pathfinding/algorithms.ts`, `client/src/components/game/DifficultyAI.ts`
**Purpose**: Simple pathfinding for Easy difficulty AI and general pathfinding visualization

**Implementation Details**:
- **Search Pattern**: Layer-by-layer exploration
- **Guarantees**: Shortest path by number of steps
- **Queue**: FIFO processing of positions
- **Termination**: First treasure found
- **Complexity**: O(V + E) where V = vertices, E = edges

#### 3. Depth-First Search (DFS)
**Location**: `client/src/lib/pathfinding/algorithms.ts`
**Purpose**: Alternative pathfinding algorithm for visualization comparison

**Implementation Details**:
- **Search Pattern**: Deep exploration before backtracking
- **Stack**: LIFO processing (recursive or explicit)
- **Completeness**: Not optimal for shortest path
- **Memory Efficient**: Lower space complexity than BFS

#### 4. Uniform Cost Search (UCS)
**Location**: `client/src/lib/pathfinding/algorithms.ts`, `client/src/components/game/DifficultyAI.ts`
**Purpose**: Cost-optimal pathfinding for Normal difficulty

**Implementation Details**:
- **Priority Queue**: Min-heap based on cumulative cost
- **Cost Calculation**: Terrain-aware movement costs
- **Optimality**: Guaranteed lowest-cost path
- **Complexity**: O(b^(C*/ε)) where C* is optimal cost, ε is minimum edge cost

### 📐 Mathematical Algorithms

#### 1. Manhattan Distance
**Location**: `client/src/components/game/AdvancedAI.ts`, `client/src/lib/game/ai.ts`
**Purpose**: Heuristic function for pathfinding algorithms

**Formula**: `|x₁ - x₂| + |y₁ - y₂|`
**Usage**:
- A* heuristic function
- Distance estimation for AI decision-making
- Cost calculation for pathfinding

```typescript
private manhattanDistance(a: Position, b: Position): number {
  return Math.abs(a.row - b.row) + Math.abs(a.col - b.col);
}
```

#### 2. Chebyshev Distance
**Location**: `client/src/lib/game/utils.ts`
**Purpose**: Alternative distance metric for diagonal movement

**Formula**: `max(|x₁ - x₂|, |y₁ - y₂|)`
**Usage**: Grid-based movement with diagonal allowed

#### 3. Obstacle Generation Algorithm
**Location**: `client/src/hooks/useGameState.ts`
**Purpose**: Procedural generation of game obstacles

**Implementation**:
```typescript
const generateObstacles = (treasure: Position, humanStart: Position, aiStart: Position) => {
  // Ensure equal distance constraint
  const manhattanDist = (pos1, pos2) => Math.abs(pos1.row - pos2.row) + Math.abs(pos1.col - pos2.col);
  
  // Strategic placement algorithms
  let wallPos: Position;
  let ladderPos: Position;
  let highCostPos: Position;
  let trapPos: Position;
  let powerUpPos: Position;
  
  // Random generation with constraints
  // ... placement logic
}
```

### 🤖 AI Decision-Making Algorithms

#### 1. Strategic Decision Tree
**Location**: `client/src/components/game/AdvancedAI.ts`
**Purpose**: Multi-factor AI decision making

**Decision Factors**:
```typescript
determineStrategy(gameState, aiPath, humanPath) {
  if (aiPath.requiresKey && keysCollected === 0) return 'collect_key';
  if (shouldUsePowerUp()) return 'use_powerup';
  if (timeDifference > 3) return 'rush';
  if (timeDifference < -2) return 'block';
  return 'balanced';
}
```

#### 2. Human Behavior Prediction
**Location**: `client/src/components/game/AdvancedAI.ts`
**Purpose**: Learn and predict human movement patterns

**Implementation**:
- **Pattern Storage**: Map of movement sequences
- **Frequency Tracking**: Count occurrences of specific moves
- **Prediction Logic**: Closest treasure heuristic with pattern weighting

```typescript
private analyzeHumanBehavior(gameState: GameState): void
private predictHumanTarget(gameState: GameState): Position
```

#### 3. Tool Optimization Algorithm
**Location**: `client/src/components/game/AdvancedAI.ts`
**Purpose**: Strategic placement of walls and ladders

**Cost-Benefit Analysis**:
```typescript
useToolIfStrategic(gameState, toolType, position) {
  const aiImprovement = currentPath.cost - newAiPath.cost;
  const humanHindrance = newHumanPath.cost - humanPath.cost;
  return (aiImprovement + humanHindrance) > 1;
}
```

### 📊 Performance Metrics System

#### 1. Real-Time Game Metrics
**Location**: `client/src/hooks/usePerformanceTracker.ts`
**Tracked Variables**:

```typescript
interface DetailedPerformanceMetrics {
  // Basic metrics
  totalGamesPlayed: number;
  winsByDifficulty: { easy: number; normal: number; hard: number };
  lossesByDifficulty: { easy: number; normal: number; hard: number };
  
  // Advanced gameplay metrics
  averageMovesPerGame: number;
  averageToolsUsedPerGame: number;
  averageGameDuration: number;
  treasureCollectionEfficiency: number;
  
  // Strategic metrics
  wallPlacementSuccess: number;
  ladderUsageOptimization: number;
  powerUpActivationTiming: number;
  
  // Decision-making metrics
  movesPerTurn: number;
  backtrackingRate: number;
  explorationCompleteness: number;
  
  // Adaptation metrics
  improvementTrend: number;
  difficultyProgression: ('easy' | 'normal' | 'hard')[];
  learningCurve: number;
  
  // Time-based metrics
  firstMoveTime: number;
  averageThinkingTime: number;
  gameSessionLength: number;
  
  // Contextual performance
  morningPerformance: number;
  afternoonPerformance: number;
  eveningPerformance: number;
}
```

#### 2. AI Confidence Scoring
**Location**: `client/src/components/game/AdvancedAI.ts`
**Purpose**: Quantify AI decision certainty

**Confidence Factors**:
- Path optimality (0.1 - 1.0)
- Risk assessment (0.0 - 1.0)
- Resource availability (0.0 - 1.0)
- Strategic positioning (0.0 - 1.0)

```typescript
interface AIDecision {
  action: ActionType;
  position: Position;
  confidence: number; // 0.0 - 1.0
  reasoning: string;
  alternativeActions?: AIDecision[];
}
```

#### 3. Difficulty Recommendation Algorithm
**Location**: `client/src/components/game/DifficultyAdvisor.tsx`
**Purpose**: Adaptive difficulty suggestions

**Recommendation Logic**:
```typescript
const recommendDifficulty = (performance: DetailedPerformanceMetrics) => {
  const overallWinRate = totalWins / totalGames;
  const recentWinRate = getWinRateForGames(performance, totalGames - 5, totalGames);
  
  if (recentWinRate > 0.7 && overallWinRate > 0.6) return 'increase';
  if (recentWinRate < 0.3 && overallWinRate < 0.4) return 'decrease';
  return 'maintain';
};
```

### 🎯 Game Mechanics Algorithms

#### 1. Energy Management System
**Location**: `client/src/hooks/useGameState.ts`
**Purpose**: Turn-based energy consumption and regeneration

**Energy Rules**:
- **Starting Energy**: 10 points per player
- **Movement Costs**:
  - Normal tiles: 1 energy
  - Water/mud: 2 energy
  - Sand: 3 energy
- **Regeneration**: +2 energy per turn (max 10)

#### 2. Collision Detection
**Location**: `client/src/hooks/useGameState.ts`
**Purpose**: Validate move legality

**Validation Checks**:
```typescript
const isValidMove = (from: Position, to: Position, state: GameState): boolean => {
  // Boundary checking
  if (to.row < 0 || to.row >= 10 || to.col < 0 || to.col >= 10) return false;
  
  // Wall collision
  if (walls.some(wall => wall.row === to.row && wall.col === to.col)) return false;
  
  // Movement range (adjacent tiles only)
  const distance = Math.abs(from.row - to.row) + Math.abs(from.col - to.col);
  return distance === 1;
};
```

#### 3. Win Condition Algorithm
**Location**: `client/src/hooks/useGameState.ts`
**Purpose**: Determine game outcome

**Win Logic**:
```typescript
const checkWinCondition = (state: GameState): GameStatus => {
  const humanTreasures = state.playerResources.human.treasuresCollected;
  const aiTreasures = state.playerResources.ai.treasuresCollected;
  
  if (humanTreasures >= 2 && aiTreasures >= 2) return 'draw';
  if (humanTreasures >= 2) return 'human-won';
  if (aiTreasures >= 2) return 'ai-won';
  return 'playing';
};
```

### 🔧 Data Structures Used

#### 1. Game State Management
```typescript
interface GameState {
  players: { human: Position; ai: Position };
  treasures: Position[];
  walls: Position[];
  ladders: Position[];
  // ... additional game objects
}
```

#### 2. Pathfinding Data Structures
- **Sets**: Open/closed lists for A* algorithm
- **Maps**: Score tracking (gScore, fScore, cameFrom)
- **Arrays**: Path reconstruction and neighbor generation
- **Priority Queues**: UCS implementation (implicit via sorting)

#### 3. Performance Tracking
- **Local Storage**: Persistent metrics across sessions
- **Maps**: Human behavior pattern tracking
- **Arrays**: Historical game data and trend analysis

### 🎲 Random Number Generation & Procedural Algorithms

#### 1. Weighted Random Selection
**Location**: `client/src/hooks/useGameState.ts`
**Purpose**: Fair distribution of game elements

**Implementation**:
- **Equal Distance Positioning**: Ensures balanced starting positions
- **Constraint-Based Placement**: Avoids overlapping obstacles
- **Fairness Algorithm**: Both players start equidistant from treasures

#### 2. Pseudo-Random Events
**Location**: Game state management
**Purpose**: Deterministic but unpredictable game events

**Features**:
- Random events every 5 turns
- Power-up spawning
- Obstacle distribution

### 📊 Statistical Algorithms

#### 1. Moving Average Calculation
**Location**: `client/src/hooks/usePerformanceTracker.ts`
**Purpose**: Smooth performance trend analysis

**Implementation**:
```typescript
const improvementTrend = getWinRateForGames(performance, totalGames - 5, totalGames);
```

#### 2. Percentile Calculations
**Purpose**: Performance ranking and comparison
**Usage**: Win rate analysis, difficulty recommendations

#### 3. Time-Based Performance Analysis
**Features**:
- Morning/afternoon/evening performance tracking
- Session length analysis
- Reaction time metrics

### 📈 Optimization Techniques

#### 1. Memoization
- **AI Decisions**: Cache pathfinding results for repeated calculations
- **Performance Metrics**: Incremental updates vs full recalculation
- **Path Caching**: Store previously calculated paths

#### 2. Early Termination
- **A* Algorithm**: Stop when goal reached
- **Decision Trees**: Short-circuit evaluation for obvious choices
- **Pruning**: Skip unnecessary calculations in game tree

#### 3. Lazy Evaluation
- **Neighbor Generation**: Only calculate when needed
- **Metrics Calculation**: Update on game events only
- **Visualization**: Render only visible elements

#### 4. Grid-Based Spatial Optimization
- **Boundary Checking**: O(1) validation for move legality
- **Neighbor Lookup**: Efficient adjacent cell access
- **Collision Detection**: Fast position-based collision checking

### 🎮 Game Balance Algorithms

#### 1. Dynamic Difficulty Adjustment
- **Performance Monitoring**: Track win rates over last 5 games
- **Threshold-Based Recommendations**: Suggest difficulty changes
- **Confidence Weighting**: Higher confidence for more data points

#### 2. Resource Balancing
- **Starting Resources**: 2 walls, 2 ladders per player
- **Energy Limits**: Maximum 10, minimum 0
- **Power-up Distribution**: Random but balanced placement

### 🔄 State Management Patterns

#### 1. Immutable Updates
```typescript
const newGameState: GameState = {
  ...currentState,
  players: {
    ...currentState.players,
    human: newPosition
  }
};
```

#### 2. Event-Driven Architecture
- **Action Dispatch**: Central action handler
- **State Validation**: Pre and post-action checks
- **Side Effects**: Automatic energy updates, win condition checks

### 🔍 Algorithm Complexity Analysis

#### Time Complexities
- **A* Algorithm**: O(b^d) where b = branching factor, d = depth
- **BFS**: O(V + E) where V = vertices, E = edges  
- **DFS**: O(V + E) for complete traversal
- **UCS**: O(b^(C*/ε)) where C* = optimal cost, ε = minimum edge cost
- **Manhattan Distance**: O(1) constant time
- **Win Condition Check**: O(1) constant time
- **Move Validation**: O(n) where n = number of obstacles

#### Space Complexities
- **A* Algorithm**: O(b^d) for storing open/closed sets
- **BFS**: O(b^d) for queue storage
- **DFS**: O(bd) for recursion stack
- **Game State**: O(n²) where n = grid size (10x10 = 100 cells)
- **Performance Metrics**: O(g) where g = number of games played

### 📋 Algorithm Summary

#### Pathfinding Algorithms (4 total)
1. **A*** - Optimal pathfinding with heuristics
2. **BFS** - Shortest path by number of steps
3. **DFS** - Deep exploration algorithm
4. **UCS** - Cost-optimal pathfinding

#### AI Decision Algorithms (6 total)
1. **Strategic Decision Tree** - Multi-factor decision making
2. **Human Behavior Prediction** - Pattern learning algorithm
3. **Tool Optimization** - Cost-benefit analysis
4. **Confidence Scoring** - Decision certainty quantification
5. **Difficulty Recommendation** - Adaptive challenge system
6. **Resource Management** - Energy and tool optimization

#### Mathematical Algorithms (3 total)
1. **Manhattan Distance** - Grid-based distance metric
2. **Chebyshev Distance** - Diagonal movement metric
3. **Obstacle Generation** - Procedural placement algorithm

#### Performance Metrics (25+ tracked variables)
- Real-time game statistics
- Historical performance data
- Time-based analytics
- Strategic performance indicators
- Learning curve analysis

#### Optimization Techniques (4 categories)
1. **Memoization** - Result caching
2. **Early Termination** - Computational pruning
3. **Lazy Evaluation** - On-demand calculation
4. **Spatial Optimization** - Grid-based efficiency

### 🎯 Technical Implementation Stats

- **Total Algorithms**: 13 major algorithms
- **Performance Metrics**: 25+ tracked variables
- **Data Structures**: Sets, Maps, Arrays, Priority Queues
- **Optimization Techniques**: 4 categories with multiple implementations
- **AI Personalities**: 3 distinct behavioral modes
- **Difficulty Levels**: 3 levels with different algorithmic approaches
- **Grid Size**: 10x10 (100 cells) with efficient spatial algorithms
- **Real-time Processing**: All algorithms optimized for interactive gameplay

This comprehensive system combines multiple algorithms and metrics to create an intelligent, adaptive, and engaging strategy game experience with sophisticated AI opponents and detailed performance analytics.